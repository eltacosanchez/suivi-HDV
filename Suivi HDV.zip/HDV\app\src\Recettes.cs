using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace SuiviHDV
{
    /// <summary>Ce que montre la fenêtre « Recettes » de Dofus : l'objet et son métier.</summary>
    public class RecetteLue
    {
        public string Nom, Metier;
        public int Niveau;
    }

    public class Ingredient
    {
        public string Nom, Categorie;
        public long Quantite, IconId;
    }

    /// <summary>Une recette telle que DofusDB la connaît (ou l'erreur rencontrée en la cherchant).</summary>
    public class Recette
    {
        public string Demande;          // le nom tel qu'il a été demandé (lu à l'écran ou tapé)
        public string Nom, Metier, Categorie, Erreur;
        public int Niveau;
        public long IconId;
        public List<Ingredient> Ingredients = new List<Ingredient>();
    }

    /// <summary>Le coût d'un ingrédient d'après le dernier relevé de prix.</summary>
    public class CoutIngredient
    {
        public Ingredient I;
        public Releve R;            // null : jamais relevé à l'HDV
        public int Lot;             // lot dont vient le prix unitaire
        public double PrixUnitaire;
        public long Cout { get { return (long)Math.Round(PrixUnitaire * I.Quantite); } }
    }

    public class CoutRecette
    {
        public Recette R;
        public List<CoutIngredient> Lignes = new List<CoutIngredient>();
        public long Total;          // somme des ingrédients dont le prix est connu
        public int SansPrix;        // ingrédients jamais relevés
        public Releve Objet;        // dernier relevé de l'objet lui-même à l'HDV, s'il y en a un
        /// <summary>Ce que coûte l'objet tout fait à l'HDV : l'offre la moins chère (sinon le prix moyen).</summary>
        public long? PrixAchat { get { return Objet != null ? Objet.P1 ?? Objet.Moy : null; } }
        /// <summary>Kamas économisés en fabriquant plutôt qu'en achetant (négatif : acheter revient moins cher).</summary>
        public long? Economie { get { return PrixAchat.HasValue ? PrixAchat.Value - Total : (long?)null; } }
    }

    /// <summary>
    /// Repère la fenêtre « Recettes » de Dofus (l'objet et la ligne « Cordonnier Niv. 177 » sous son nom) et calcule
    /// ce que coûtent les ingrédients d'après les prix relevés à l'HDV.
    /// </summary>
    public static class Recettes
    {
        static readonly Regex rxMetier = new Regex(@"^(?<m>\p{L}[\p{L}' ]{3,24}?)\s+Niv\.?\s*(?<n>\d{1,3})\s*$");
        static readonly Regex rxFenetre = new Regex(@"recette|ingr[ée]dient", RegexOptions.IgnoreCase);

        /// <summary>L'objet dont la recette est affichée, ou null si la fenêtre « Recettes » n'est pas à l'écran.</summary>
        public static RecetteLue Lire(List<LigneOcr> lignes)
        {
            if (!lignes.Any(l => rxFenetre.IsMatch(l.Texte))) return null;
            foreach (var l in lignes)
            {
                var m = rxMetier.Match(l.Texte.Trim());
                if (!m.Success) continue;
                string metier = m.Groups["m"].Value.Trim();
                if (metier.StartsWith("Niv", StringComparison.OrdinalIgnoreCase)) continue;
                double h = Math.Max(8, l.H);
                // Le nom de l'objet : la ligne juste au-dessus, alignée à gauche avec le métier.
                var nom = lignes.Where(x => x.Y < l.Y && x.Y > l.Y - 2.6 * h && Math.Abs(x.X - l.X) < 3 * h && x.Texte.Trim().Length >= 3)
                    .OrderByDescending(x => x.Y).FirstOrDefault();
                if (nom == null) continue;
                return new RecetteLue { Nom = nom.Texte.Trim(), Metier = metier, Niveau = int.Parse(m.Groups["n"].Value) };
            }
            return null;
        }

        /// <summary>
        /// Le coût de la recette. Pour chaque ingrédient, le prix unitaire est le moins cher des lots qu'on achèterait
        /// pour cette quantité (x1 pour 3 unités ; x1 ou x10 pour 44…), et le coût est quantité × prix unitaire.
        /// </summary>
        public static CoutRecette Calculer(Recette r, Dictionary<string, Releve> derniers)
        {
            var c = new CoutRecette { R = r };
            foreach (var i in r.Ingredients)
            {
                var ligne = new CoutIngredient { I = i, R = Trouver(i.Nom, derniers) };
                if (ligne.R != null)
                {
                    var possibles = LecteurHdv.Lots.Where(l => ligne.R.Prix(l).HasValue && (l <= i.Quantite || l == LecteurHdv.Lots.First(x => ligne.R.Prix(x).HasValue))).ToList();
                    if (possibles.Count > 0)
                    {
                        ligne.Lot = possibles.OrderBy(l => ligne.R.ParUnite(l).Value).First();
                        ligne.PrixUnitaire = ligne.R.ParUnite(ligne.Lot).Value;
                        c.Total += ligne.Cout;
                    }
                    else ligne.R = null;
                }
                if (ligne.R == null) c.SansPrix++;
                c.Lignes.Add(ligne);
            }
            c.Objet = Trouver(r.Nom, derniers);
            return c;
        }

        static Releve Trouver(string nom, Dictionary<string, Releve> derniers)
        {
            Releve r;
            string cle = Ecran.Normaliser(nom);
            if (derniers.TryGetValue(cle, out r)) return r;
            if (cle.Length < 6) return null;
            var proches = derniers.Where(kv => Ecran.Distance(kv.Key, cle) <= 1).ToList();
            return proches.Count == 1 ? proches[0].Value : null;
        }
    }
}
