using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;

namespace SuiviHDV
{
    /// <summary>Ce qu'une capture montre de la fiche d'une ressource ouverte à l'HDV.</summary>
    public class Fiche
    {
        public bool Ok;
        public bool Visible;        // une fiche HDV est à l'écran (boutons « ACHETER »), même si elle n'a pas pu être lue
        public bool HdvOuvert;      // la fenêtre « Hôtel de vente » semble ouverte
        public string Raison = "";
        public string Nom, Categorie;
        public long? P1, P10, P100, P1000, Moy;
        public RectangleF Zone;     // où se trouve la fiche dans l'image (quand elle est visible)
        public int Relu;            // nombre de cases qu'il a fallu relire autrement (chiffre isolé…)

        public long? Prix(int lot)
        {
            switch (lot) { case 1: return P1; case 10: return P10; case 100: return P100; case 1000: return P1000; }
            return null;
        }

        public void DefinirPrix(int lot, long v)
        {
            switch (lot) { case 1: P1 = v; break; case 10: P10 = v; break; case 100: P100 = v; break; case 1000: P1000 = v; break; }
        }

        /// <summary>Clé qui change dès que le nom ou un prix change : sert à confirmer une lecture vue deux fois pareil.</summary>
        public string Cle
        {
            get { return Ecran.Normaliser(Nom) + "|" + P1 + "|" + P10 + "|" + P100 + "|" + P1000 + "|" + Moy; }
        }
    }

    /// <summary>
    /// Retrouve la fiche d'une ressource ouverte à l'HDV de Dofus 3 : nom, catégorie, prix par lot et prix moyen.
    /// Les repères sont les boutons « ACHETER » (une ligne de prix chacun) et l'en-tête « Lot ».
    /// Au moindre doute, la lecture est refusée : mieux vaut ne rien enregistrer que d'inventer un prix.
    /// </summary>
    // Le chiffre 1 du niveau est parfois lu « l », « I » ou « | » (« Niv.l • Liquide ») : ces lettres sont acceptées.
    public static class LecteurHdv
    {
        public static readonly int[] Lots = { 1, 10, 100, 1000 };
        static readonly Regex rxNiv = new Regex(@"^Niv\.?\s*[\dIl|]+\s*[^\p{L}]*\s*(.+)$");

        /// <summary>
        /// Lit la fiche. Si elle n'est pas lisible, relit l'image agrandie quand une fiche est visible ou quand
        /// « insister » est vrai (capture F9 : on sait qu'une fiche est censée être à l'écran).
        /// </summary>
        public static Fiche Lire(Bitmap bmp, bool insister = false)
        {
            var lignes = Ocr.Lire(bmp);
            var f = Analyser(lignes, bmp);
            if (f.Ok) return f;
            f.HdvOuvert = lignes.Any(l => l.Texte.IndexOf("vente", StringComparison.OrdinalIgnoreCase) >= 0);
            if (!f.Visible && !insister) return f;
            // Deuxième essai avec l'image agrandie : plus lent, mais lit mieux les petits nombres.
            using (var grand = Ecran.Agrandir(bmp, 2))
            {
                var f2 = Analyser(Ocr.Lire(grand, 2), bmp);   // positions ramenées à l'image d'origine
                if (f2.Ok) { f2.HdvOuvert = true; return f2; }
                // Toujours illisible : on garde la lecture qui a au moins trouvé le nom.
                if (f2.Visible && (f2.Nom != null || f.Nom == null)) { f2.HdvOuvert = true; if (f2.Nom == null) f2.Nom = f.Nom; return f2; }
                if (f.Nom == null) f.Nom = f2.Nom;
                return f;
            }
        }

        // Montant en kamas écrit en groupes de chiffres (« 321 233 », « 2995 », « 2767* »). Null si douteux.
        static long? Nombre(IEnumerable<string> mots)
        {
            var groupes = new List<string>();
            foreach (string m in mots)
            {
                string t = m.TrimEnd('*', '✱');
                // Le symbole kamas collé au nombre est parfois lu « K » (« 1952K »).
                if (t.Length > 1 && t.EndsWith("K") && char.IsDigit(t[t.Length - 2])) t = t.Substring(0, t.Length - 1);
                if (t.Length == 0 || !t.All(char.IsDigit)) break;
                groupes.Add(t);
                if (t != m) break;
            }
            if (groupes.Count == 0) return null;
            if (groupes.Count > 1)
            {
                if (groupes[0].Length > 3) return null;
                for (int i = 1; i < groupes.Count; i++) if (groupes[i].Length != 3) return null;
            }
            long v;
            return long.TryParse(string.Concat(groupes), out v) ? v : (long?)null;
        }

        /// <summary>« image » (facultative) : l'image d'origine, pour relire autrement les cases illisibles.</summary>
        public static Fiche Analyser(List<LigneOcr> lignes, Bitmap image = null)
        {
            var f = new Fiche();
            var mots = lignes.SelectMany(l => l.Mots).ToList();

            // 1. Les lignes de prix : une par bouton « ACHETER », dans une même colonne.
            var boutons = mots.Where(m => m.T.StartsWith("ACHET")).OrderBy(m => m.Y).ToList();
            if (boutons.Count == 0) { f.Raison = "aucune fiche HDV à l'écran"; return f; }
            f.Visible = true;
            double x0 = boutons[0].X;
            double u = Math.Max(8, boutons.Max(b => b.H));   // unité de taille : hauteur du texte
            boutons = boutons.Where(b => Math.Abs(b.X - x0) < 4 * u).ToList();
            // L'écart entre deux lignes de prix est plus stable que la hauteur lue d'un mot : on s'en sert quand on peut.
            if (boutons.Count >= 2) u = Math.Max(8, (boutons[boutons.Count - 1].Y - boutons[0].Y) / (boutons.Count - 1) / 4.2);
            // La fiche entière (icône, nom, prix moyen, lignes de prix) tient autour des boutons « ACHETER ».
            var dernierBouton = boutons[boutons.Count - 1];
            f.Zone = RectangleF.FromLTRB((float)(x0 - 36 * u), (float)(boutons[0].Y - 38 * u), (float)(x0 + 12 * u), (float)(dernierBouton.Y + dernierBouton.H + 3 * u));

            var entete = mots.Where(m => m.T.StartsWith("Lot") && m.Y < boutons[0].Y && m.Y > boutons[0].Y - 12 * u && m.X < x0 && m.X > x0 - 50 * u)
                .OrderByDescending(m => m.Y).FirstOrDefault();
            if (entete == null) { f.Raison = "en-tête « Lot » introuvable"; return f; }
            double xLot = entete.X;
            double limite = xLot + (x0 - xLot) * 0.45;   // à gauche : la taille du lot ; à droite : le prix

            // Nom et catégorie d'abord : la ligne « Niv. 100 • Catégorie » et le nom juste au-dessus. Même si un prix
            // est illisible ensuite, le nom sert à ne pas garder deux fois la même fiche.
            var niv = lignes.Where(l => Regex.IsMatch(l.Texte, @"^Niv\.?\s*[\dIl|]+") && l.Y < entete.Y && l.Y > entete.Y - 30 * u && Math.Abs(l.X - xLot) < 10 * u)
                .OrderByDescending(l => l.Y).FirstOrDefault();
            LigneOcr nom = null;
            if (niv != null)
            {
                var mc = rxNiv.Match(niv.Texte);
                if (mc.Success) f.Categorie = mc.Groups[1].Value.Trim();
                nom = lignes.Where(l => l.Y < niv.Y && l.Y > niv.Y - 4 * u && Math.Abs(l.X - niv.X) < 3 * u).OrderByDescending(l => l.Y).FirstOrDefault();
                if (nom != null && nom.Texte.Trim().Length >= 2) f.Nom = nom.Texte.Trim();
            }

            var rangs = new List<long?[]>();   // { lot, prix }
            var voisins = new List<MotOcr>();  // un mot de chaque prix bien lu : sert à relire les cases difficiles
            var ecartsY = new List<double>();
            foreach (var b in boutons)
            {
                var bande = mots.Where(m => Math.Abs(m.CentreY - b.CentreY) < 1.3 * u && m.X >= xLot - 2 * u && m.Fin <= b.X).OrderBy(m => m.X).ToList();
                var motsPrix = bande.Where(m => m.X >= limite).ToList();
                long? prix = Nombre(motsPrix.Select(m => m.T));
                if (prix != null)
                {
                    var dernier = motsPrix.LastOrDefault(m => m.T.Length > 0 && char.IsDigit(m.T[0]));
                    if (dernier != null) { voisins.Add(dernier); ecartsY.Add(dernier.CentreY - b.CentreY); }
                }
                long? lot = Nombre(bande.Where(m => m.X < limite).Select(m => m.T));
                rangs.Add(new[] { lot, prix });
            }
            // Cases illisibles (souvent un prix d'un seul chiffre) : on les relit autrement, en plusieurs essais.
            for (int i = 0; i < rangs.Count; i++)
            {
                if (rangs[i][1] != null) continue;
                if (image != null)
                {
                    double dy = ecartsY.Count > 0 ? ecartsY.OrderBy(e => e).ElementAt(ecartsY.Count / 2) : 0;
                    rangs[i][1] = Relecture.Prix(image, boutons[i], limite, u, dy, voisins, Nombre);
                    if (rangs[i][1] != null) { f.Relu++; continue; }
                }
                f.Raison = "un prix est illisible";
                return f;
            }

            // 2. Tailles de lot : 1, 10, 100, 1000 dans l'ordre. Un « 1 » isolé échappe parfois à l'OCR :
            //    on ne le déduit que s'il n'y a qu'une seule possibilité.
            foreach (var r in rangs)
                if (r[0] != null && !Lots.Contains((int)Math.Min(int.MaxValue, r[0].Value))) { f.Raison = "taille de lot inattendue (" + r[0] + ")"; return f; }
            for (int i = 0; i < rangs.Count; i++)
            {
                if (rangs[i][0] != null) continue;
                int j = i;
                while (j < rangs.Count && rangs[j][0] == null) j++;
                long avant = i > 0 ? rangs[i - 1][0].Value : 0;
                long apres = j < rangs.Count ? rangs[j][0].Value : 10000;
                var possibles = Lots.Where(l => l > avant && l < apres).ToList();
                if (possibles.Count != j - i) { f.Raison = "taille de lot illisible"; return f; }
                for (int k = i; k < j; k++) rangs[k][0] = possibles[k - i];
            }
            for (int i = 1; i < rangs.Count; i++)
            {
                if (rangs[i][0] <= rangs[i - 1][0]) { f.Raison = "lots dans un ordre inattendu"; return f; }
                if (rangs[i][1] <= rangs[i - 1][1]) { f.Raison = "un gros lot coûte moins cher qu'un petit"; return f; }
            }
            foreach (var r in rangs) f.DefinirPrix((int)r[0].Value, r[1].Value);

            // 3. Le nom est obligatoire pour enregistrer.
            if (niv == null) { f.Raison = "fiche de la ressource introuvable"; return f; }
            if (f.Nom == null) { f.Raison = "nom introuvable"; return f; }

            // 4. Prix moyen (facultatif) : le nombre qui suit « Prix moyen : », sur la même ligne ou juste à droite.
            var pm = lignes.FirstOrDefault(l => l.Texte.StartsWith("Prix moyen", StringComparison.OrdinalIgnoreCase) && l.Y > niv.Y && l.Y < entete.Y && Math.Abs(l.X - niv.X) < 3 * u);
            if (pm != null)
            {
                var bande = mots.Where(m => Math.Abs(m.CentreY - pm.CentreY) < 1.3 * u && m.X >= pm.X && m.X < pm.X + 40 * u).OrderBy(m => m.X).Select(m => m.T).ToList();
                int debut = 0;
                for (int i = 0; i < bande.Count; i++) if (bande[i].EndsWith(":") || bande[i].StartsWith("moyen")) debut = i + 1;
                if (debut > 0 && debut < bande.Count) f.Moy = Nombre(bande.Skip(debut));
            }

            f.Ok = true;
            return f;
        }
    }
}
