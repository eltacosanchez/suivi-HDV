using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace SuiviHDV
{
    /// <summary>Ce qu'on affiche pour une ressource : prix par unité du lot de référence et ses variations.</summary>
    public class Vue
    {
        public Ressource R;
        public int Lot;              // lot utilisé (celui de référence, ou le plus petit disponible)
        public bool Substitue;       // le lot de référence manquait
        public double? PrixU, Veille, Periode;
        public List<KeyValuePair<DateTime, double>> Serie = new List<KeyValuePair<DateTime, double>>();
    }

    public static class Calculs
    {
        public static readonly CultureInfo Fr = CultureInfo.GetCultureInfo("fr-FR");

        public static DateTime DebutPeriode(int jours, DateTime tMax)
        {
            return jours <= 0 ? DateTime.MinValue : tMax.AddDays(-jours);
        }

        public static Vue Analyser(Ressource r, int lotRef, int periode, DateTime tMax)
        {
            var v = new Vue { R = r };
            var dernier = r.Dernier;
            if (dernier.Prix(lotRef).HasValue) v.Lot = lotRef;
            else
            {
                v.Lot = LecteurHdv.Lots.FirstOrDefault(l => dernier.Prix(l).HasValue);
                v.Substitue = v.Lot != 0;
            }
            if (v.Lot == 0) return v;
            var avec = r.Releves.Where(x => x.Prix(v.Lot).HasValue).ToList();
            var fin = avec[avec.Count - 1];
            v.PrixU = fin.ParUnite(v.Lot);
            var avant = avec.LastOrDefault(x => x.T.Date < fin.T.Date);
            if (avant != null) v.Veille = Variation(fin.Prix(v.Lot).Value, avant.Prix(v.Lot).Value);
            var debut = DebutPeriode(periode, tMax);
            var dans = avec.Where(x => x.T >= debut).ToList();
            if (dans.Count > 1) v.Periode = Variation(fin.Prix(v.Lot).Value, dans[0].Prix(v.Lot).Value);
            v.Serie = dans.Select(x => new KeyValuePair<DateTime, double>(x.T, x.ParUnite(v.Lot).Value)).ToList();
            return v;
        }

        public static double? Variation(long a, long b) { return b == 0 ? (double?)null : (a - b) / (double)b; }

        // L'espace insécable des milliers est presque invisible dans certaines polices : on met une espace normale.
        static string Espaces(string s) { return s.Replace(' ', ' ').Replace(' ', ' '); }

        public static string Kamas(long? v) { return v.HasValue ? Espaces(v.Value.ToString("N0", Fr)) : "—"; }

        public static string Unitaire(double? v)
        {
            if (!v.HasValue) return "—";
            double x = v.Value;
            return Espaces(x.ToString(x < 10 ? "0.##" : x < 100 ? "0.#" : "N0", Fr));
        }

        public static string Nombre(long v) { return Espaces(v.ToString("N0", Fr)); }

        public static string Pourcent(double? v)
        {
            if (!v.HasValue) return "—";
            double p = v.Value * 100;
            if (Math.Abs(p) < 0.05) return "= 0,0 %";
            return (p > 0 ? "▲ " : "▼ ") + Math.Abs(p).ToString("0.0", Fr) + " %";
        }

        public static string Date(DateTime t)
        {
            if (t.Date == DateTime.Today) return "aujourd'hui " + t.ToString("HH:mm", Fr);
            if (t.Date == DateTime.Today.AddDays(-1)) return "hier " + t.ToString("HH:mm", Fr);
            return t.ToString("d MMM HH:mm", Fr);
        }
    }
}
