using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SuiviHDV
{
    public class Fenetre : Form
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int RegisterWindowMessage(string nom);
        [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint vk);
        [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int v, int taille);
        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)] static extern int SetWindowTheme(IntPtr h, string app, string liste);
        public static readonly int MsgAfficher = RegisterWindowMessage("SuiviHDV_Afficher");
        const int WM_HOTKEY = 0x0312;

        static int S(int v) { return Theme.S(v); }

        readonly string dossierHdv;
        // Mises à jour depuis GitHub : numéro de version (version.txt) et bouton « Installer la v… ».
        readonly string version = "";
        readonly MiseAJour maj;
        readonly Bouton bMaj = new Bouton("Mise à jour") { Principal = true, Visible = false };
        readonly Donnees d;
        readonly Moteur moteur;

        // En-tête et interrupteurs
        readonly Surface entete = new Surface(), tuiles = new Surface();
        readonly Bouton bCapture = new Bouton("Capturer") { Principal = true, Glyphe = Theme.GCamera };
        readonly Interrupteur iAuto = new Interrupteur("Analyse automatique");
        readonly Interrupteur iNotif = new Interrupteur("Musique");
        readonly Panel pSon = new Panel { BackColor = Theme.Bg };
        readonly Bouton bEcouter = new Bouton("Écouter") { Glyphe = Theme.GSon };
        readonly Bouton bChangerSon = new Bouton("Changer de son") { Glyphe = Theme.GDossier };
        string dossierSons { get { return Path.Combine(dossierHdv, "sons"); } }
        readonly Bouton bAttente = new Bouton("");
        readonly Onglets onglets = new Onglets { Noms = new[] { "Prix", "Dépenses & gains", "Activité", "Consommation", "Options" } };
        // Calculateur de recette : à part, dans sa propre fenêtre (bouton à droite des onglets).
        readonly Bouton bCalc = new Bouton("Calculateur de recette") { Glyphe = Theme.GCalcul };
        Calculateur calculateur;
        Bitmap iconeEntete;
        // Serveurs de jeu : un onglet par serveur, chacun avec ses relevés et ses achats.
        readonly Onglets oServeurs = new Onglets();
        readonly Bouton bServeurPlus = new Bouton("+ Serveur"), bServeurNom = new Bouton("Renommer");
        const int PPrix = 0, PDepenses = 1, PActivite = 2, PConso = 3, POptions = 4;   // pages (onglets)

        // Page Prix
        readonly Champ chRecherche = new Champ("Rechercher une ressource…") { Glyphe = Theme.GRecherche };
        readonly Onglets oPeriode = new Onglets { Noms = new[] { "7 j", "30 j", "90 j", "Tout" } };
        readonly Onglets oLot = new Onglets { Noms = new[] { "x1", "x10", "x100", "x1000" } };
        readonly Bouton bGrouper = new Bouton("Par catégorie");
        readonly Puces puces = new Puces();
        readonly ListePrix liste = new ListePrix();

        // Détail d'une ressource
        readonly Bouton bRetour = new Bouton("Retour") { Glyphe = Theme.GRetour };
        readonly Surface detail = new Surface();
        readonly Graphique graphique = new Graphique();
        readonly Tableau tHisto = new Tableau();
        string ouverte;   // clé de la ressource affichée en détail

        // Captures en attente : on choisit lesquelles Claude doit relire
        readonly Bouton bRetourAtt = new Bouton("Retour") { Glyphe = Theme.GRetour };
        readonly Bouton bToutSel = new Bouton("Tout sélectionner");
        readonly Bouton bIgnorer = new Bouton("Ignorer la sélection");
        readonly Bouton bOcr = new Bouton("Réessayer avec l'OCR (gratuit)");
        readonly Bouton bRelire = new Bouton("Relire avec Claude") { Principal = true };
        readonly Surface infoAtt = new Surface();
        readonly Galerie galerie = new Galerie();
        bool vueAttente;

        // Autres pages
        readonly Tableau tActivite = new Tableau();
        readonly Bouton bDossier = new Bouton("Dossier des captures") { Glyphe = Theme.GDossier };
        readonly Surface conso = new Surface();
        readonly Tableau tConso = new Tableau();
        readonly Panel pOptions = new Panel { BackColor = Theme.Bg, AutoScroll = true };
        readonly Onglets oTouche = new Onglets { Noms = new[] { "F8", "F9", "F10", "F11", "F12" } };
        readonly Onglets oIntervalle = new Onglets { Noms = new[] { "1 s", "2 s", "3 s", "5 s" } };
        readonly Onglets oReReleve = new Onglets { Noms = new[] { "15 min", "30 min", "1 h", "2 h" } };
        readonly Onglets oModele = new Onglets { Noms = new[] { "Haiku", "Sonnet", "Opus" } };
        readonly Onglets oVolume = new Onglets { Noms = new[] { "1 %", "2 %", "5 %", "10 %", "25 %", "50 %" } };
        static readonly int[] Volumes = { 1, 2, 5, 10, 25, 50 };
        readonly Interrupteur iSon = new Interrupteur("Son à chaque relevé");
        readonly Interrupteur iEpingle = new Interrupteur("Garder la fenêtre au-dessus de Dofus");
        readonly Bouton bWeb = new Bouton("Ouvrir la page web") { Glyphe = Theme.GWeb };
        readonly Bouton bDossierHdv = new Bouton("Ouvrir le dossier HDV") { Glyphe = Theme.GDossier };
        readonly List<KeyValuePair<Control, string[]>> rangs = new List<KeyValuePair<Control, string[]>>();

        readonly Timer minuterie = new Timer { Interval = 400 };
        volatile bool aRafraichir = true, activiteAjour;
        string etat = "Démarrage…";
        List<Ressource> ressources = new List<Ressource>();
        List<Vue> vues = new List<Vue>();
        DateTime tMax = DateTime.Now;
        string categorie = "Toutes";
        bool toucheOk = true;

        static readonly int[] Periodes = { 7, 30, 90, 0 };
        static readonly int[] Intervalles = { 1, 2, 3, 5 };
        static readonly int[] ReReleves = { 15, 30, 60, 120 };
        static readonly string[] Modeles = { "haiku", "sonnet", "opus" };

        public Fenetre(string dossier)
        {
            dossierHdv = dossier;
            try { version = File.ReadAllText(Path.Combine(dossier, "version.txt")).Trim(); } catch { }
            maj = new MiseAJour(dossier, version);
            d = new Donnees(dossier);
            moteur = new Moteur(d, dossier);
            var R = d.Reglages;

            Text = "Suivi HDV";
            Icon = Icone.Charger(Path.Combine(dossier, @"app\app.ico"), 32);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            KeyPreview = true;
            DoubleBuffered = true;
            MinimumSize = new Size(S(1000), S(700));
            StartPosition = FormStartPosition.Manual;
            var ecran = Screen.PrimaryScreen.WorkingArea;
            var defaut = new Rectangle(0, 0, Math.Min(S(1240), ecran.Width - S(40)), Math.Min(S(860), ecran.Height - S(40)));
            defaut.Location = new Point(ecran.X + (ecran.Width - defaut.Width) / 2, ecran.Y + (ecran.Height - defaut.Height) / 2);
            var garde = new Rectangle(R.FenX, R.FenY, R.FenL, R.FenH);
            bool visible = R.FenX != int.MinValue && R.FenL > 0 && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(garde));
            Bounds = visible ? garde : defaut;
            TopMost = R.Epingle;

            entete.Paint += DessinerEntete;
            tuiles.Paint += DessinerTuiles;
            detail.Paint += DessinerDetail;
            conso.Paint += DessinerConso;
            detail.BackColor = Theme.Bg;

            liste.Vide = "Aucun relevé pour l'instant.\n\nOuvre l'Hôtel de vente dans Dofus et clique sur une ressource : avec l'analyse automatique, ses prix sont relevés tout seuls. Sinon, appuie sur " + R.Touche + ".";
            liste.Grouper = R.Grouper;
            liste.LotRef = R.Lot;
            // Le tri choisi est gardé d'une fois sur l'autre.
            liste.Tri = string.IsNullOrEmpty(R.Tri) ? "nom" : R.Tri;
            liste.Sens = R.Sens < 0 ? -1 : 1;
            liste.TriChange += delegate { R.Tri = liste.Tri; R.Sens = liste.Sens; Sauver(); };
            liste.Ouvrir += r => OuvrirDetail(r.Cle);
            tHisto.Colonnes.AddRange(new[] { new Colonne("Date", 1.6f), new Colonne("x1", 1, true), new Colonne("x10", 1, true), new Colonne("x100", 1.1f, true),
                new Colonne("x1000", 1.2f, true), new Colonne("Prix moyen", 1, true), new Colonne("Évolution", 1, true) });
            tActivite.Colonnes.AddRange(new[] { new Colonne("Heure", 0.9f), new Colonne("Source", 1.1f), new Colonne("Message", 6, false, true) });
            tActivite.Vide = "L'activité s'affiche ici : fiches lues, prix relevés, captures envoyées à Claude…";
            tConso.Colonnes.AddRange(new[] { new Colonne("Date", 1.4f), new Colonne("Lu par", 1), new Colonne("Captures", 0.8f, true), new Colonne("Tokens", 1, true, true), new Colonne("Équivalent API", 1.1f, true) });
            tConso.Vide = "Aucune lecture pour l'instant.";

            iAuto.Actif = R.Auto;
            iNotif.Actif = R.Notifs;
            iSon.Actif = R.Son;
            iEpingle.Actif = R.Epingle;
            bGrouper.Actif = R.Grouper;
            oPeriode.Index = Math.Max(0, Array.IndexOf(Periodes, R.Periode));
            oLot.Index = Math.Max(0, Array.IndexOf(LecteurHdv.Lots, R.Lot));
            oTouche.Index = Math.Max(0, Array.IndexOf(oTouche.Noms, R.Touche));
            oIntervalle.Index = Math.Max(0, Array.IndexOf(Intervalles, R.Intervalle));
            oReReleve.Index = Math.Max(0, Array.IndexOf(ReReleves, R.ReReleve));
            oModele.Index = Math.Max(0, Array.IndexOf(Modeles, R.Modele));
            oVolume.Index = Math.Max(0, Array.IndexOf(Volumes, R.Volume));
            Musique.VolumePourcent = R.Volume;
            puces.Choix = categorie;
            MajTextes();

            rangs.Add(new KeyValuePair<Control, string[]>(oTouche, new[] { "Touche de capture", "Capture la fenêtre Dofus et lit la fiche (utile quand l'analyse automatique est coupée)." }));
            rangs.Add(new KeyValuePair<Control, string[]>(oIntervalle, new[] { "Analyse automatique : fréquence", "Plus souvent = plus réactif, mais un peu plus de travail pour le PC." }));
            rangs.Add(new KeyValuePair<Control, string[]>(oReReleve, new[] { "Relever à nouveau une ressource inchangée après", "Une fiche restée ouverte n'est enregistrée qu'une fois, sauf si ses prix changent." }));
            rangs.Add(new KeyValuePair<Control, string[]>(oModele, new[] { "Modèle de Claude", "Haiku consomme le moins, Opus lit le mieux. Sonnet est un bon équilibre." }));
            rangs.Add(new KeyValuePair<Control, string[]>(pSon, new[] { "Musique de notification", "Les 6 premières secondes du MP3 du dossier HDV\\sons, jouées à chaque prix relevé." }));
            rangs.Add(new KeyValuePair<Control, string[]>(oVolume, new[] { "Volume de la musique", "En pour cent du volume de Windows. 2 % : on l'entend à peine." }));
            rangs.Add(new KeyValuePair<Control, string[]>(iEpingle, null));
            rangs.Add(new KeyValuePair<Control, string[]>(bWeb, new[] { "Page web", "L'ancienne page du tableau, toujours à jour avec les mêmes données." }));
            rangs.Add(new KeyValuePair<Control, string[]>(bDossierHdv, new[] { "Fichiers", "Relevés (donnees\\prix.js), captures et journal." }));
            foreach (var r in rangs)
            {
                pOptions.Controls.Add(r.Key);
                if (r.Value != null) { var lab = new Surface { Tag = r.Value }; lab.Paint += DessinerLibelle; pOptions.Controls.Add(lab); r.Key.Tag = lab; }
            }
            pOptions.Resize += delegate { PlacerOptions(); };
            // Barres de défilement sombres, comme dans Dofus Organizer.
            pOptions.HandleCreated += delegate { try { SetWindowTheme(pOptions.Handle, "DarkMode_Explorer", null); } catch { } };

            // Clic sur la tuile « plus forte hausse » ou « plus forte baisse » : ouvre la ressource.
            tuiles.MouseClick += (s, e) =>
            {
                int i = (int)(e.X / (tuiles.Width / 4f));
                var v = i == 2 ? PlusForte(true) : i == 3 ? PlusForte(false) : null;
                if (v != null) OuvrirDetail(v.R.Cle);
            };
            tuiles.MouseMove += (s, e) =>
            {
                int i = (int)(e.X / (tuiles.Width / 4f));
                tuiles.Cursor = (i == 2 && PlusForte(true) != null) || (i == 3 && PlusForte(false) != null) ? Cursors.Hand : Cursors.Default;
            };
            // Clic sur un relevé de l'historique : le supprimer s'il est faux.
            tHisto.Clic += l =>
            {
                var x = l.Etiquette as Releve;
                if (x == null) return;
                if (MessageBox.Show(this, "Supprimer ce relevé ?\n\n" + x.Nom + " · " + Calculs.Date(x.T) + "\n\nÀ faire seulement si ses prix sont faux.", "Suivi HDV",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    d.SupprimerReleve(x);
            };
            bMaj.Click += delegate { InstallerMiseAJour(); };
            PreparerDepenses();
            bCalc.Click += delegate { OuvrirCalculateur(null); };
            MajServeurs();
            oServeurs.Change += delegate { if (oServeurs.Index >= R.Serveurs.Count) return; ouverte = null; d.ChoisirServeur(R.Serveurs[oServeurs.Index]); Placer(); };
            bServeurPlus.Click += delegate
            {
                string nom = DemanderNom("Nouveau serveur", "Nom du serveur :", "");
                if (nom == null) return;
                if (!d.AjouterServeur(nom)) MessageBox.Show(this, "Ce nom est vide ou déjà pris.", "Suivi HDV", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MajServeurs(); Placer();
            };
            bServeurNom.Click += delegate
            {
                string nom = DemanderNom("Renommer le serveur", "Nom du serveur :", R.Serveur);
                if (nom == null || nom.Trim() == R.Serveur) return;
                if (!d.RenommerServeur(nom)) MessageBox.Show(this, "Ce nom est vide ou déjà pris.", "Suivi HDV", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MajServeurs();
            };
            moteur.RecetteVue += r => Sur(() => OuvrirCalculateur(r));
            Controls.AddRange(new Control[] { entete, bCapture, bMaj, iAuto, iNotif, bAttente, tuiles, onglets, bCalc, oServeurs, bServeurPlus, bServeurNom,
                chRecherche, oPeriode, oLot, bGrouper, puces, liste, bRetour, detail, graphique, tHisto,
                tActivite, bDossier, conso, tConso, pOptions, bRetourAtt, bToutSel, bIgnorer, bOcr, bRelire, infoAtt, galerie });

            galerie.Vide = "Aucune capture en attente.\n\nQuand l'OCR ne sait pas lire une fiche, la capture arrive ici. Elle est réessayée automatiquement toutes les 2 secondes, et supprimée si elle reste illisible 2 minutes ; tu peux aussi la faire lire par Claude.";
            infoAtt.Paint += (s, e) => TextRenderer.DrawText(e.Graphics,
                "Réessayées automatiquement toutes les 2 secondes, supprimées après 2 minutes si elles restent illisibles. « Réessayer avec l'OCR » refait une lecture complète ; Claude ne lit que ta sélection (double-clic pour agrandir).",
                Theme.F(9f), infoAtt.ClientRectangle, Theme.Dim, TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
            galerie.Change += MajTextes;
            galerie.Agrandir += f => Ouvrir(f);
            bRetourAtt.Click += delegate { vueAttente = false; Placer(); };
            bToutSel.Click += delegate
            {
                var libres = galerie.Fichiers.Where(f => !galerie.Envoyes.Contains(f)).ToList();
                if (libres.All(galerie.Choisis.Contains)) galerie.Choisis.Clear(); else galerie.Choisis.UnionWith(libres);
                galerie.Invalidate(); MajTextes();
            };
            bIgnorer.Click += delegate { var sel = galerie.Choisis.ToList(); galerie.Choisis.Clear(); moteur.Ignorer(sel); RemplirAttente(); };
            bOcr.Click += delegate { var sel = galerie.Choisis.ToList(); galerie.Choisis.Clear(); moteur.RelireOcr(sel); RemplirAttente(); };
            bRelire.Click += delegate
            {
                var sel = galerie.Choisis.ToList();
                if (sel.Count == 0) return;
                galerie.Envoyes.UnionWith(sel);
                galerie.Choisis.Clear();
                moteur.RelireFichiers(sel);
                galerie.Invalidate(); MajTextes();
            };

            // Réglages
            iAuto.Change += delegate { R.Auto = iAuto.Actif; Sauver(); MajTextes(); };
            iNotif.Change += delegate { R.Notifs = iNotif.Actif; Sauver(); MajTextes(); };
            iSon.Change += delegate { R.Son = iSon.Actif; Sauver(); };
            iEpingle.Change += delegate { R.Epingle = iEpingle.Actif; TopMost = R.Epingle; if (calculateur != null) calculateur.TopMost = R.Epingle; Sauver(); };
            oPeriode.Change += delegate { R.Periode = Periodes[oPeriode.Index]; Sauver(); Rafraichir(); };
            oLot.Change += delegate { R.Lot = LecteurHdv.Lots[oLot.Index]; liste.LotRef = R.Lot; Sauver(); Rafraichir(); };
            bGrouper.Click += delegate { R.Grouper = !R.Grouper; bGrouper.Actif = R.Grouper; liste.Grouper = R.Grouper; bGrouper.Invalidate(); Sauver(); Rafraichir(); };
            oTouche.Change += delegate { R.Touche = oTouche.Noms[oTouche.Index]; Sauver(); EnregistrerTouche(); MajTextes(); };
            oIntervalle.Change += delegate { R.Intervalle = Intervalles[oIntervalle.Index]; Sauver(); };
            oReReleve.Change += delegate { R.ReReleve = ReReleves[oReReleve.Index]; Sauver(); };
            oModele.Change += delegate { R.Modele = Modeles[oModele.Index]; Sauver(); };
            oVolume.Change += delegate
            {
                R.Volume = Volumes[oVolume.Index]; Musique.VolumePourcent = R.Volume; Sauver();
                Musique.Jouer(Musique.Fichier(dossierSons), 2500);   // un court extrait pour entendre le nouveau volume
            };

            // Actions
            bCapture.Click += delegate { moteur.CaptureF9(); };
            // Ce bouton ne lance jamais Claude : il ouvre la page où l'on choisit les captures à relire.
            bAttente.Click += delegate { vueAttente = true; RemplirAttente(); Placer(); };
            bDossier.Click += delegate { Ouvrir(moteur.DossierCaptures); };
            bWeb.Click += delegate { Ouvrir(Path.Combine(dossierHdv, "Tableau HDV.html")); };
            bDossierHdv.Click += delegate { Ouvrir(dossierHdv); };
            bRetour.Click += delegate { FermerDetail(); };
            chRecherche.Boite.TextChanged += delegate { Rafraichir(); };
            chRecherche.Boite.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Escape) { chRecherche.Boite.Text = ""; e.SuppressKeyPress = true; }
                if (e.KeyCode == Keys.Enter && vues.Count > 0) { e.SuppressKeyPress = true; var v = Filtrees().FirstOrDefault(); if (v != null) OuvrirDetail(v.R.Cle); }
            };
            puces.Change += delegate { categorie = puces.Choix; Rafraichir(); };
            onglets.Change += delegate { vueAttente = false; Placer(); Rafraichir(); };

            // Moteur (fils à part) -> fenêtre
            d.Change += delegate { aRafraichir = true; };
            moteur.Nouvelle += a => { activiteAjour = true; };
            moteur.Etat += s => { if (s == etat) return; etat = s; Sur(() => entete.Invalidate()); };
            moteur.Attente += () => Sur(() => { if (vueAttente) RemplirAttente(); MajTextes(); });

            // Notification sonore (une capture en attente finit par être lue par l'OCR) : les 6 premières secondes
            // du MP3 du dossier HDV\sons.
            // À chaque prix relevé (et quand une capture en attente finit par être lue) : la musique, jamais le son de
            // Windows. Si elle joue déjà, on la laisse finir au lieu de la relancer.
            Action musique = () => Sur(() => { if (d.Reglages.Notifs) Musique.Jouer(Musique.Fichier(dossierSons), Musique.DureeMs, false); });
            moteur.Releve += musique;
            // Le tableau remonte tout en haut : la ressource qu'on vient de relever y est affichée en premier.
            moteur.Releve += () => Sur(() => liste.HautDePage());
            moteur.Notification += (titre, texte) => musique();
            bEcouter.Click += delegate
            {
                if (!Musique.Jouer(Musique.Fichier(dossierSons)))
                    MessageBox.Show(this, "Aucun son lisible dans le dossier :\n" + dossierSons + "\n\nMets-y un fichier MP3, ou clique sur « Changer de son ».", "Suivi HDV", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            bChangerSon.Click += delegate { ChangerSon(); };
            pSon.Controls.AddRange(new Control[] { bEcouter, bChangerSon });
            pSon.Resize += delegate { int w2 = (pSon.Width - S(10)) / 2; bEcouter.SetBounds(0, 0, w2, pSon.Height); bChangerSon.SetBounds(w2 + S(10), 0, pSon.Width - w2 - S(10), pSon.Height); };
            minuterie.Tick += delegate
            {
                // Une fois par minute même sans nouveau relevé : le bloc « Relevées à l'instant » se vide tout seul.
                // Fenêtre réduite : rien à redessiner, ce sera fait quand elle reviendra.
                if (WindowState == FormWindowState.Minimized) return;
                if (aRafraichir || DateTime.Now - dernierRafraichi > TimeSpan.FromMinutes(1)) { aRafraichir = false; Rafraichir(); }
                if (activiteAjour) { activiteAjour = false; RemplirActivite(); entete.Invalidate(); }
            };

            Placer();
            Rafraichir();
        }

        void MajServeurs()
        {
            oServeurs.Noms = d.Reglages.Serveurs.ToArray();
            oServeurs.Index = Math.Max(0, d.Reglages.Serveurs.IndexOf(d.Reglages.Serveur));
            oServeurs.Invalidate();
        }

        /// <summary>Petite fenêtre pour taper un nom. Null si annulé.</summary>
        string DemanderNom(string titre, string question, string valeur)
        {
            using (var f = new Form { Text = titre, FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MinimizeBox = false, MaximizeBox = false,
                ClientSize = new Size(S(340), S(118)), BackColor = Theme.Bg, ForeColor = Theme.Text, Font = Theme.F(9.5f), TopMost = TopMost })
            {
                var l = new Label { Text = question, AutoSize = true, Location = new Point(S(14), S(14)) };
                var t = new TextBox { Text = valeur, Bounds = new Rectangle(S(14), S(40), S(312), S(26)), MaxLength = 30 };
                var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Bounds = new Rectangle(S(136), S(78), S(90), S(28)), ForeColor = Color.Black, BackColor = SystemColors.Control };
                var non = new Button { Text = "Annuler", DialogResult = DialogResult.Cancel, Bounds = new Rectangle(S(236), S(78), S(90), S(28)), ForeColor = Color.Black, BackColor = SystemColors.Control };
                f.Controls.AddRange(new Control[] { l, t, ok, non });
                f.AcceptButton = ok; f.CancelButton = non;
                return f.ShowDialog(this) == DialogResult.OK ? t.Text.Trim() : null;
            }
        }

        void Sur(Action a) { try { if (IsHandleCreated && !IsDisposed) BeginInvoke(a); } catch (InvalidOperationException) { } }
        void Sauver() { d.SauverReglages(); }
        static void Ouvrir(string chemin) { try { Process.Start(new ProcessStartInfo(chemin) { UseShellExecute = true }); } catch { } }

        // ---- Cycle de vie ----------------------------------------------------------------------------

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int v = 1; if (DwmSetWindowAttribute(Handle, 20, ref v, 4) != 0) DwmSetWindowAttribute(Handle, 19, ref v, 4); } catch { }
            EnregistrerTouche();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            moteur.Demarrer();
            minuterie.Start();
            // Nouvelle version sur GitHub ? On regarde quelques secondes après le démarrage, sans bloquer la fenêtre.
            if (maj.Active)
                new System.Threading.Thread(() =>
                {
                    System.Threading.Thread.Sleep(3000);
                    if (maj.Verifier() == null || !maj.Disponible) return;
                    Sur(() => { bMaj.Text = "Installer la v" + maj.Distante; bMaj.Visible = true; Placer(); });
                }) { IsBackground = true, Priority = System.Threading.ThreadPriority.Lowest }.Start();
        }

        /// <summary>Ouvre le calculateur (créé à la première demande) et lui montre une recette, s'il y en a une.</summary>
        void OuvrirCalculateur(Recette r)
        {
            if (calculateur == null)
            {
                calculateur = new Calculateur(d, moteur, Icon);
                calculateur.Ouvrir += nom => { OuvrirDetail(Ecran.Normaliser(nom)); Activate(); };
                d.Change += delegate { Sur(() => { if (calculateur.Visible) calculateur.Recalculer(); }); };
            }
            if (r != null) calculateur.Montrer(r);
            else if (!calculateur.Visible) calculateur.Show();
            else calculateur.Activate();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            moteur.Arreter();
            if (calculateur != null) calculateur.Memoriser();
            try { UnregisterHotKey(Handle, 1); } catch { }
            Musique.Arreter();
            var b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            d.Reglages.FenX = b.X; d.Reglages.FenY = b.Y; d.Reglages.FenL = b.Width; d.Reglages.FenH = b.Height;
            Sauver();
            base.OnFormClosing(e);
        }

        void EnregistrerTouche()
        {
            if (!IsHandleCreated) return;
            UnregisterHotKey(Handle, 1);
            Keys k;
            if (!Enum.TryParse(d.Reglages.Touche, out k)) k = Keys.F9;
            toucheOk = RegisterHotKey(Handle, 1, 0x4000 /* MOD_NOREPEAT */, (uint)k);
            entete.Invalidate();
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY) moteur.CaptureF9();
            else if (m.Msg == MsgAfficher)
            {
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                Activate();
            }
            base.WndProc(ref m);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape && ouverte != null) { FermerDetail(); e.Handled = true; }
            // Ctrl+1 à Ctrl+5 : les onglets.
            if (e.Control && e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D5) { onglets.Index = e.KeyCode - Keys.D1; e.Handled = true; e.SuppressKeyPress = true; }
            if (e.Control && e.KeyCode == Keys.F && onglets.Index == PPrix) { chRecherche.Boite.Visible = true; chRecherche.Boite.Focus(); e.Handled = true; }
            base.OnKeyDown(e);
        }

        protected override void OnResize(EventArgs e) { base.OnResize(e); Placer(); }

        // ---- Disposition -------------------------------------------------------------------------------

        void Placer()
        {
            if (onglets == null || liste == null) return;
            int m = S(16), w = ClientSize.Width - 2 * m, y = m;
            int lMaj = bMaj.Visible ? S(170) : 0;
            entete.SetBounds(m, y, w - S(190) - lMaj, S(52));
            bCapture.SetBounds(m + w - S(180), y + S(8), S(180), S(38));
            bMaj.SetBounds(m + w - S(180) - lMaj, y + S(8), S(160), S(38));
            y += S(52) + S(10);

            int hi = S(54), gap = S(10), li = (w - 2 * gap) / 3;
            iAuto.SetBounds(m, y, li, hi);
            iNotif.SetBounds(m + li + gap, y, li, hi);
            bAttente.SetBounds(m + 2 * (li + gap), y, w - 2 * (li + gap), hi);
            y += hi + S(12);

            oServeurs.SetBounds(m, y, Math.Min(w - S(250), S(160) * d.Reglages.Serveurs.Count), S(32));
            bServeurNom.SetBounds(m + w - S(110), y, S(110), S(32));
            bServeurPlus.SetBounds(m + w - S(110) - S(10) - S(120), y, S(120), S(32));
            y += S(32) + S(12);

            tuiles.SetBounds(m, y, w, S(76)); y += S(76) + S(12);
            onglets.SetBounds(m, y, Math.Min(w, S(660)), S(36));
            bCalc.SetBounds(m + w - S(230), y, S(230), S(36));
            y += S(36) + S(12);
            int bas = ClientSize.Height - m, h = bas - y;

            int page = vueAttente ? -1 : onglets.Index;   // -1 : page des captures en attente
            bool det = page == PPrix && ouverte != null;
            foreach (Control c in new Control[] { chRecherche, oPeriode, oLot, bGrouper, puces, liste }) c.Visible = page == PPrix && !det;
            foreach (Control c in new Control[] { bRetour, detail, graphique, tHisto }) c.Visible = det;
            tActivite.Visible = bDossier.Visible = page == PActivite;
            conso.Visible = tConso.Visible = page == PConso;
            foreach (Control c in PageKamas) c.Visible = page == PDepenses;
            pOptions.Visible = page == POptions;
            foreach (Control c in new Control[] { bRetourAtt, bToutSel, bIgnorer, bOcr, bRelire, infoAtt, galerie }) c.Visible = page == -1;

            if (page == -1)
            {
                int hb = S(36);
                bRetourAtt.SetBounds(m, y, S(100), hb);
                bToutSel.SetBounds(m + S(110), y, S(160), hb);
                bRelire.SetBounds(m + w - S(260), y, S(260), hb);
                bOcr.SetBounds(m + w - S(260) - S(10) - S(230), y, S(230), hb);
                bIgnorer.SetBounds(m + w - S(260) - S(10) - S(230) - S(10) - S(160), y, S(160), hb);
                infoAtt.SetBounds(m, y + hb + S(8), w, S(24));
                galerie.SetBounds(m, y + hb + S(40), w, bas - y - hb - S(40));
                galerie.Invalidate();
            }
            else if (page == PPrix && !det)
            {
                int hc = S(36), x = m;
                chRecherche.SetBounds(x, y, S(300), hc); x += S(300) + S(12);
                oPeriode.SetBounds(x, y, S(230), hc); x += S(230) + S(12);
                oLot.SetBounds(x, y, S(250), hc); x += S(250) + S(12);
                bGrouper.SetBounds(x, y, S(150), hc);
                int yy = y + hc + S(10);
                int hp = puces.Disposer(w);
                puces.SetBounds(m, yy, w, hp); puces.Invalidate();
                yy += hp + (hp > 0 ? S(10) : 0);
                liste.SetBounds(m, yy, w, bas - yy);
            }
            else if (det)
            {
                bRetour.SetBounds(m, y, S(110), S(34));
                detail.SetBounds(m, y + S(44), w, S(150));
                int yg = y + S(44) + S(150) + S(10);
                int hg = Math.Max(S(220), (int)((bas - yg) * 0.62));
                graphique.SetBounds(m, yg, w, hg);
                tHisto.SetBounds(m, yg + hg + S(10), w, Math.Max(S(60), bas - yg - hg - S(10)));
            }
            else if (page == PDepenses) PlacerDepenses(m, y, w, bas);
            else if (page == PActivite)
            {
                bDossier.SetBounds(m + w - S(220), y, S(220), S(34));
                tActivite.SetBounds(m, y + S(44), w, h - S(44));
            }
            else if (page == PConso)
            {
                conso.SetBounds(m, y, w, S(170));
                tConso.SetBounds(m, y + S(180), w, h - S(180));
            }
            else
            {
                pOptions.SetBounds(m, y, w, h);
                PlacerOptions();
            }
        }

        void PlacerOptions()
        {
            // Largeur sans la barre de défilement verticale (sinon une barre horizontale inutile apparaît).
            bool defile = rangs.Count * S(66) > pOptions.Height;
            int w = pOptions.Width - (defile ? SystemInformation.VerticalScrollBarWidth : 0) - S(4), y = 0, lc = Math.Min(S(420), w / 2);
            pOptions.AutoScrollPosition = Point.Empty;
            foreach (var r in rangs)
            {
                var lab = r.Key.Tag as Control;
                if (lab != null)
                {
                    lab.SetBounds(0, y, w - lc - S(16), S(56));
                    r.Key.SetBounds(w - lc, y + S(10), lc, S(36));
                }
                else r.Key.SetBounds(0, y, w, S(56));
                y += S(66);
            }
        }

        void DessinerLibelle(object sender, PaintEventArgs e)
        {
            var c = (Control)sender;
            var t = (string[])c.Tag;
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis;
            TextRenderer.DrawText(e.Graphics, t[0], Theme.F(10f, true), new Rectangle(0, S(6), c.Width, S(22)), Theme.Text, f);
            TextRenderer.DrawText(e.Graphics, t[1], Theme.F(8.5f), new Rectangle(0, S(30), c.Width, S(20)), Theme.Faint, f);
        }

        void MajTextes()
        {
            var R = d.Reglages;
            iAuto.Detail = R.Auto ? "Ouvre une ressource à l'HDV : ses prix sont relevés tout seuls" : "Coupée : appuie sur " + R.Touche + " pour capturer une fiche";
            iNotif.Detail = R.Notifs ? "Les 6 premières secondes de ton MP3 à chaque prix relevé" : "Coupée : les relevés se font en silence";
            bCapture.Text = "Capturer (" + R.Touche + ")";
            int n = moteur.NbAttente;
            if (moteur.ClaudeOccupe) { bAttente.Text = "Claude relit les captures…"; bAttente.Actif = true; }
            else if (n > 0) { bAttente.Text = n + " capture" + (n > 1 ? "s" : "") + " en attente · réessai auto 2 s, supprimée après 2 min"; bAttente.Actif = true; }
            else { bAttente.Text = "Aucune capture en attente"; bAttente.Actif = false; }
            bAttente.Glyphe = Theme.GDossier;
            int c = galerie.Choisis.Count;
            bRelire.Text = c > 0 ? "Relire avec Claude (" + c + " choisie" + (c > 1 ? "s" : "") + ")" : "Choisis des captures à relire";
            bRelire.Enabled = c > 0;
            bIgnorer.Enabled = c > 0;
            bOcr.Enabled = c > 0;
            var libres = galerie.Fichiers.Where(f => !galerie.Envoyes.Contains(f)).ToList();
            bToutSel.Text = libres.Count > 0 && libres.All(galerie.Choisis.Contains) ? "Tout désélectionner" : "Tout sélectionner";
            bToutSel.Enabled = libres.Count > 0;
            foreach (Control x in new Control[] { iAuto, iNotif, bAttente, bCapture, entete, bRelire, bIgnorer, bOcr, bToutSel }) x.Invalidate();
        }

        // ---- Données -> affichage ------------------------------------------------------------------------

        IEnumerable<Vue> Filtrees()
        {
            string q = Ecran.Normaliser(chRecherche.Boite.Text);
            return vues.Where(v => (categorie == "Toutes" || v.R.Cat == categorie) && Correspond(v.R.Nom, q));
        }

        /// <summary>
        /// La recherche (déjà simplifiée : sans accents ni majuscules) correspond au nom : elle y figure, ou à une faute
        /// de frappe près (deux pour une recherche d'au moins 7 lettres) : « tronknide » trouve « Tronknyde ».
        /// </summary>
        static bool Correspond(string nom, string q)
        {
            if (q == "") return true;
            string n = Ecran.Normaliser(nom);
            if (n.Contains(q)) return true;
            if (q.Length < 4 || n.Length < q.Length) return false;
            int tolerance = q.Length >= 7 ? 2 : 1;
            // Morceaux du nom de la même longueur que la recherche, ou une lettre de plus (lettre oubliée en tapant).
            for (int plus = 0; plus <= 1; plus++)
                for (int i = 0; i + q.Length + plus <= n.Length; i++)
                    if (Ecran.Distance(n.Substring(i, q.Length + plus), q) <= tolerance) return true;
            return false;
        }

        // Les deux ressources montrées par les tuiles « plus forte hausse » et « plus forte baisse ».
        Vue PlusForte(bool hausse)
        {
            var avec = vues.Where(v => v.Periode.HasValue);
            return hausse ? avec.Where(v => v.Periode >= 0.0005).OrderByDescending(v => v.Periode).FirstOrDefault()
                          : avec.Where(v => v.Periode <= -0.0005).OrderBy(v => v.Periode).FirstOrDefault();
        }

        DateTime dernierRafraichi = DateTime.Now;

        void Rafraichir()
        {
            dernierRafraichi = DateTime.Now;
            ressources = d.Ressources();
            tMax = ressources.Count > 0 ? ressources.Max(r => r.Dernier.T) : DateTime.Now;
            var R = d.Reglages;
            vues = ressources.Select(r => Calculs.Analyser(r, R.Lot, R.Periode, tMax)).ToList();

            string q = Ecran.Normaliser(chRecherche.Boite.Text);
            var trouvees = vues.Where(v => Correspond(v.R.Nom, q)).ToList();
            if (categorie != "Toutes" && !vues.Any(v => v.R.Cat == categorie)) categorie = "Toutes";
            puces.Elements = new List<KeyValuePair<string, int>> { new KeyValuePair<string, int>("Toutes", trouvees.Count) };
            puces.Elements.AddRange(vues.Select(v => v.R.Cat).Distinct().OrderBy(c => c, StringComparer.Create(Calculs.Fr, true))
                .Select(c => new KeyValuePair<string, int>(c, trouvees.Count(v => v.R.Cat == c))));
            puces.Choix = categorie;
            liste.TitrePeriode = R.Periode > 0 ? R.Periode + " j" : "Total";
            liste.Remplir(Filtrees().ToList());
            if (ressources.Count > 0 && chRecherche.Boite.Text != "")
                liste.Vide = "Aucune ressource ne correspond à « " + chRecherche.Boite.Text + " ».";
            else if (ressources.Count > 0) liste.Vide = "Aucune ressource dans cette catégorie.";
            if (ouverte != null) MajDetail();   // avant Placer : si la ressource ouverte n'existe plus, on revient au tableau
            Placer();
            tuiles.Invalidate();

            if (onglets.Index == PActivite) RemplirActivite();
            if (onglets.Index == PConso) RemplirConso();
            if (onglets.Index == PDepenses) RemplirDepenses();
        }

        /// <summary>Choisit un autre MP3 (ou WAV) : il est copié dans HDV\sons à la place de l'ancien.</summary>
        void ChangerSon()
        {
            using (var dlg = new OpenFileDialog { Title = "Choisir le son de notification", Filter = "Sons (*.mp3;*.wav)|*.mp3;*.wav" })
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                if (!Musique.Lisible(dlg.FileName))
                {
                    MessageBox.Show(this, "Windows n'arrive pas à lire ce fichier. Essaie un autre MP3.", "Suivi HDV", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                try
                {
                    Musique.Arreter();
                    Directory.CreateDirectory(dossierSons);
                    foreach (string f in Directory.GetFiles(dossierSons))
                    {
                        string ext = Path.GetExtension(f).ToLowerInvariant();
                        if (ext == ".mp3" || ext == ".wav") File.Delete(f);   // les copies faites par l'appli : l'original ne bouge pas
                    }
                    string cible = Path.Combine(dossierSons, "notification" + Path.GetExtension(dlg.FileName).ToLowerInvariant());
                    File.Copy(dlg.FileName, cible, true);
                    Musique.Jouer(cible);
                }
                catch (Exception ex) { MessageBox.Show(this, "Impossible de copier le son : " + ex.Message, "Suivi HDV", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            }
        }

        void RemplirAttente()
        {
            galerie.Remplir(moteur.ListeAttente());
            MajTextes();
        }

        void RemplirActivite()
        {
            var acts = moteur.Activites();
            acts.Reverse();
            tActivite.Remplir(acts.Select(a => new Ligne
            {
                Cellules = new[] { a.T.ToString("HH:mm:ss"), a.Source, a.Texte },
                Couleurs = new Color?[] { null, null, a.Niveau == Niveau.Ok ? Theme.Green : a.Niveau == Niveau.Alerte ? Theme.Accent : a.Niveau == Niveau.Erreur ? Theme.Red : (Color?)null },
                Info = a.Texte
            }).ToList());
        }

        void RemplirConso()
        {
            var c = d.Consos();
            c.Reverse();
            tConso.Remplir(c.Select(x => new Ligne
            {
                Cellules = new[] { Calculs.Date(x.T), x.EstOcr ? "OCR (gratuit)" : "Claude " + x.Modele, x.Captures.ToString(),
                    x.EstOcr ? "0" : x.Total.ToString("N0", Calculs.Fr).Replace('\u00A0', ' ').Replace('\u202F', ' '), x.EstOcr ? "—" : x.Usd.ToString("0.000", Calculs.Fr) + " $" },
                Discrete = x.EstOcr
            }).ToList());
            conso.Invalidate();
        }

        // ---- Détail d'une ressource ----------------------------------------------------------------------

        void OuvrirDetail(string cle)
        {
            ouverte = cle;
            onglets.Index = PPrix;
            MajDetail();
            Placer();
        }

        // ---- Dépenses & gains (achats et ventes à l'HDV lus dans le chat) --------------------------------

        readonly Onglets oPerKamas = new Onglets { Noms = new[] { "Aujourd'hui", "Cette semaine", "Ce mois", "Cette année" } };
        readonly Surface bilan = new Surface();
        readonly Surface carteDep = new Surface(), carteGain = new Surface();
        readonly Onglets oVueDep = new Onglets { Noms = new[] { "Achats", "Par ressource" } };
        readonly Onglets oVueGain = new Onglets { Noms = new[] { "Ventes", "Par ressource" } };
        readonly Tableau tAchats = new Tableau(), tVentes = new Tableau();
        static readonly string[] NomsPeriodes = { "Aujourd'hui", "Cette semaine", "Ce mois", "Cette année" };
        static readonly string[] DesPeriodes = { "d'aujourd'hui", "de la semaine", "du mois", "de l'année" };

        Control[] PageKamas { get { return new Control[] { oPerKamas, bilan, carteDep, carteGain, oVueDep, oVueGain, tAchats, tVentes }; } }

        static DateTime DebutPeriodeDep(int i)
        {
            var auj = DateTime.Today;
            switch (i)
            {
                case 0: return auj;
                case 1: return auj.AddDays(-(((int)auj.DayOfWeek + 6) % 7));   // depuis lundi
                case 2: return new DateTime(auj.Year, auj.Month, 1);
                default: return new DateTime(auj.Year, 1, 1);
            }
        }

        void PreparerDepenses()
        {
            oPerKamas.Index = 1;
            oPerKamas.Change += delegate { RemplirDepenses(); };
            oVueDep.Change += delegate { RemplirDepenses(); };
            oVueGain.Change += delegate { RemplirDepenses(); };
            bilan.Paint += DessinerBilan;
            carteDep.Paint += (s, e) => DessinerCarte(e.Graphics, carteDep, false);
            carteGain.Paint += (s, e) => DessinerCarte(e.Graphics, carteGain, true);
            tAchats.Vide = "Aucun achat sur cette période.\n\nAchète à l'HDV avec l'analyse automatique activée et le chat visible : la ligne « 100 x [Ressource] (… kamas) » est lue toute seule.";
            tVentes.Vide = "Aucune vente sur cette période.\n\nQuand un objet que tu as mis à l'HDV est vendu, la ligne « Banque : + … Kamas (vente : …) » du chat est lue toute seule.";
            Action<Ligne> supprimer = l =>
            {
                var a = l.Etiquette as Achat;
                if (a == null) return;
                string quoi = a.Vente ? "cette vente" : "cet achat";
                if (MessageBox.Show(this, "Supprimer " + quoi + " ?\n\n" + a.Quantite + " x " + a.Nom + (a.Vente ? ", +" : " pour ") + Calculs.Kamas(a.Prix) + " kamas\n(" +
                    Calculs.Date(a.T) + ")\n\nÀ faire seulement s'il a été mal lu.", "Suivi HDV", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                    d.SupprimerAchat(a);
            };
            tAchats.Clic += supprimer;
            tVentes.Clic += supprimer;
            Controls.AddRange(PageKamas);
        }

        void PlacerDepenses(int m, int y, int w, int bas)
        {
            oPerKamas.SetBounds(m, y, S(520), S(36));
            bilan.SetBounds(m + S(530), y, w - S(530), S(36));
            int yc = y + S(46), lc = (w - S(14)) / 2, xg = m + lc + S(14), ld = w - lc - S(14);
            carteDep.SetBounds(m, yc, lc, S(118));
            carteGain.SetBounds(xg, yc, ld, S(118));
            int yo = yc + S(128);
            oVueDep.SetBounds(m, yo, S(260), S(32));
            oVueGain.SetBounds(xg, yo, S(260), S(32));
            int yt = yo + S(40);
            tAchats.SetBounds(m, yt, lc, bas - yt);
            tVentes.SetBounds(xg, yt, ld, bas - yt);
        }

        void RemplirDepenses()
        {
            var debut = DebutPeriodeDep(oPerKamas.Index);
            var tout = d.Achats().Where(a => a.T >= debut).ToList();
            RemplirKamas(tAchats, tout.Where(a => !a.Vente).ToList(), oVueDep.Index == 1, false);
            RemplirKamas(tVentes, tout.Where(a => a.Vente).ToList(), oVueGain.Index == 1, true);
            bilan.Invalidate(); carteDep.Invalidate(); carteGain.Invalidate();
        }

        void RemplirKamas(Tableau t, List<Achat> liste, bool parRessource, bool vente)
        {
            Color couleur = vente ? Theme.Green : Theme.Red;
            string signe = vente ? "+ " : "- ";
            t.Colonnes.Clear();
            if (!parRessource)
            {
                t.Colonnes.AddRange(new[] { new Colonne("Date", 1.3f), new Colonne("Ressource", 2.4f, false, true), new Colonne("Qté", 0.7f, true),
                    new Colonne(vente ? "Gagné" : "Payé", 1.2f, true, true), new Colonne("Prix/u", 0.9f, true) });
                t.Remplir(liste.OrderByDescending(a => a.T).Select(a => new Ligne
                {
                    Cellules = new[] { Calculs.Date(a.T), a.Nom, Calculs.Kamas(a.Quantite), signe + Calculs.Kamas(a.Prix) + " k", Calculs.Unitaire(a.ParUnite) },
                    Couleurs = new Color?[] { null, null, null, couleur, null },
                    Info = "Clic : supprimer s'il a été mal lu", Icone = Images.Charger(d.IconeDe(a.Nom)),
                    Etiquette = a
                }).ToList());
            }
            else
            {
                t.Colonnes.AddRange(new[] { new Colonne("Ressource", 2.4f, false, true), new Colonne(vente ? "Ventes" : "Achats", 0.8f, true),
                    new Colonne("Qté", 0.9f, true), new Colonne("Total", 1.2f, true, true) });
                t.Remplir(liste.GroupBy(a => Ecran.Normaliser(a.Nom)).Select(g => new
                {
                    Nom = g.OrderByDescending(a => a.T).First().Nom, Nb = g.Count(), Q = g.Sum(a => a.Quantite), K = g.Sum(a => a.Prix)
                }).OrderByDescending(x => x.K).Select(x => new Ligne
                {
                    Cellules = new[] { x.Nom, x.Nb.ToString(), Calculs.Kamas(x.Q), signe + Calculs.Kamas(x.K) + " k" }, Icone = Images.Charger(d.IconeDe(x.Nom)),
                    Couleurs = new Color?[] { null, null, null, couleur }
                }).ToList());
            }
        }

        // Le bilan de la période : ce qui a été gagné moins ce qui a été dépensé.
        void DessinerBilan(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            var debut = DebutPeriodeDep(oPerKamas.Index);
            var tout = d.Achats().Where(a => a.T >= debut).ToList();
            long gains = tout.Where(a => a.Vente).Sum(a => a.Prix), dep = tout.Where(a => !a.Vente).Sum(a => a.Prix), net = gains - dep;
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.Right;
            string valeur = (net > 0 ? "+ " : net < 0 ? "- " : "") + Calculs.Kamas(Math.Abs(net)) + " k";
            Color c = net > 0 ? Theme.Green : net < 0 ? Theme.Red : Theme.Dim;
            int lv = TextRenderer.MeasureText(g, valeur, Theme.F(13f, true), Size.Empty, f).Width;
            TextRenderer.DrawText(g, valeur, Theme.F(13f, true), new Rectangle(0, 0, bilan.Width, bilan.Height), c, f);
            TextRenderer.DrawText(g, "Bilan " + DesPeriodes[oPerKamas.Index] + " (gains - dépenses)", Theme.F(9f),
                new Rectangle(0, 0, bilan.Width - lv - S(10), bilan.Height), Theme.Dim, f);
        }

        // Une colonne : Dépenses (à gauche) ou Gains (à droite), avec le total de la période choisie et le rappel des autres.
        void DessinerCarte(Graphics g, Control c, bool vente)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new RectangleF(0, 0, c.Width - 1, c.Height - 1);
            Theme.Remplir(g, Theme.Card, r, Theme.Sf(10));
            Color couleur = vente ? Theme.Green : Theme.Red;
            Theme.Remplir(g, couleur, new RectangleF(0, Theme.Sf(14), Theme.Sf(4), r.Height - Theme.Sf(28)), Theme.Sf(2));
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            var tous = d.Achats().Where(a => a.Vente == vente).ToList();
            int p = oPerKamas.Index;
            var periode = tous.Where(a => a.T >= DebutPeriodeDep(p)).ToList();
            int x = S(18), w = c.Width - S(30);
            TextRenderer.DrawText(g, vente ? "GAINS (VENTES)" : "DÉPENSES (ACHATS)", Theme.F(8.5f, true), new Rectangle(x, S(8), w, S(20)), couleur, f);
            TextRenderer.DrawText(g, (vente ? "+ " : "- ") + Calculs.Kamas(periode.Sum(a => a.Prix)) + " k", Theme.F(18f, true), new Rectangle(x, S(28), w, S(38)), Theme.Text, f);
            string nb = periode.Count == 0 ? (vente ? "aucune vente" : "aucun achat") : periode.Count + (vente ? " vente" : " achat") + (periode.Count > 1 ? "s" : "");
            TextRenderer.DrawText(g, nb + " " + DesPeriodes[p], Theme.F(9f), new Rectangle(x, S(66), w, S(20)), Theme.Dim, f);
            var rappel = new List<string>();
            for (int i = 0; i < 4; i++)
                rappel.Add(new[] { "Jour", "Semaine", "Mois", "Année" }[i] + " " + Calculs.Kamas(tous.Where(a => a.T >= DebutPeriodeDep(i)).Sum(a => a.Prix)) + " k");
            TextRenderer.DrawText(g, string.Join("   ·   ", rappel), Theme.F(8.5f), new Rectangle(x, S(90), w, S(20)), Theme.Faint, f);
        }
        void FermerDetail() { ouverte = null; Placer(); liste.Focus(); }

        Ressource Ouverte { get { return ressources.FirstOrDefault(r => r.Cle == ouverte); } }

        void MajDetail()
        {
            var r = Ouverte;
            if (r == null) { ouverte = null; return; }
            graphique.Afficher(r, Calculs.DebutPeriode(d.Reglages.Periode, tMax));
            var l = new List<Ligne>();
            for (int i = r.Releves.Count - 1; i >= 0; i--)
            {
                var x = r.Releves[i];
                // Évolution par rapport au relevé d'avant, sur le plus gros lot que les deux ont en commun.
                double? evo = null;
                if (i > 0)
                    foreach (int lot in new[] { 100, 10, 1, 1000 })
                    {
                        var a = r.Releves[i - 1].Prix(lot); var n = x.Prix(lot);
                        if (a.HasValue && n.HasValue) { evo = Calculs.Variation(n.Value, a.Value); break; }
                    }
                Color? ce = !evo.HasValue || Math.Abs(evo.Value) < 0.0005 ? Theme.Faint : evo.Value > 0 ? Theme.Green : Theme.Red;
                l.Add(new Ligne
                {
                    Cellules = new[] { x.T.ToString("dddd d MMM yyyy, HH:mm", Calculs.Fr), Calculs.Kamas(x.P1), Calculs.Kamas(x.P10), Calculs.Kamas(x.P100), Calculs.Kamas(x.P1000), Calculs.Kamas(x.Moy), Calculs.Pourcent(evo) },
                    Couleurs = new Color?[] { null, null, null, null, null, null, ce },
                    Info = "Clic : supprimer ce relevé s'il est faux",
                    Etiquette = x
                });
            }
            tHisto.Remplir(l);
            detail.Invalidate();
        }

        void DessinerDetail(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = Ouverte;
            if (r == null) return;
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            Images.Dessiner(g, r, new RectangleF(0, S(2), S(56), S(56)));
            TextRenderer.DrawText(g, r.Nom, Theme.F(16f, true), new Rectangle(S(70), 0, detail.Width - S(70), S(34)), Theme.Text, f);
            string sous = r.Cat + " · dernier relevé " + Calculs.Date(r.Dernier.T) + " · " + r.Releves.Count + " relevé" + (r.Releves.Count > 1 ? "s" : "");
            // Sur 30 jours (au moins 3 relevés) : du plus bas au plus haut à l'unité, et où se situe le prix du moment.
            var vue = vues.FirstOrDefault(x => x.R == r);
            if (vue != null && vue.Lot > 0)
            {
                var mois = r.Releves.Where(x => x.T >= DateTime.Now.AddDays(-30) && x.Prix(vue.Lot).HasValue).Select(x => x.ParUnite(vue.Lot).Value).ToList();
                if (mois.Count >= 3)
                {
                    double moyenne = mois.Average(), actuel = mois[mois.Count - 1];
                    sous += " · sur 30 jours : de " + Calculs.Unitaire(mois.Min()) + " à " + Calculs.Unitaire(mois.Max()) + " k/u, en ce moment prix "
                        + (actuel <= moyenne * 0.9 ? "bas" : actuel >= moyenne * 1.1 ? "haut" : "normal");
                }
            }
            TextRenderer.DrawText(g, sous, Theme.F(9f), new Rectangle(S(70), S(34), detail.Width - S(70), S(22)), Theme.Dim, f);

            // Une carte par lot : prix du dernier relevé et variation depuis la veille.
            var der = r.Dernier;
            var cartes = new List<Tuple<string, long, int, Color, int>>();   // titre, prix, lot, couleur, index
            for (int i = 0; i < 4; i++) { int lot = LecteurHdv.Lots[i]; if (der.Prix(lot).HasValue) cartes.Add(Tuple.Create("Lot x" + lot, der.Prix(lot).Value, lot, Theme.Series[i], i)); }
            if (der.Moy.HasValue) cartes.Add(Tuple.Create("Prix moyen (par unité)", der.Moy.Value, 0, Theme.Series[4], 4));
            if (cartes.Count == 0) return;
            float y = S(70), h = S(76), gap = S(10);
            float lc = Math.Min(S(240), (detail.Width - gap * (cartes.Count - 1)) / cartes.Count);
            for (int i = 0; i < cartes.Count; i++)
            {
                var c = cartes[i];
                var zone = new RectangleF(i * (lc + gap), y, lc, h);
                Theme.Remplir(g, Theme.Card, zone, Theme.Sf(10));
                Theme.Remplir(g, c.Item4, new RectangleF(zone.X + S(12), zone.Y + S(14), S(9), S(9)), Theme.Sf(2.5f));
                TextRenderer.DrawText(g, c.Item1, Theme.F(8.5f), new Rectangle((int)zone.X + S(26), (int)zone.Y + S(8), (int)lc - S(34), S(20)), Theme.Dim, f);
                TextRenderer.DrawText(g, Calculs.Kamas(c.Item2) + " k", Theme.F(13f, true), new Rectangle((int)zone.X + S(12), (int)zone.Y + S(28), (int)lc - S(20), S(26)), Theme.Kamas, f);
                // Variation depuis le dernier relevé d'un autre jour.
                Func<Releve, long?> val = x => c.Item3 == 0 ? x.Moy : x.Prix(c.Item3);
                var avant = r.Releves.LastOrDefault(x => x.T.Date < der.T.Date && val(x).HasValue);
                double? v = avant != null ? Calculs.Variation(c.Item2, val(avant).Value) : null;
                string bas = c.Item3 > 1 ? Calculs.Unitaire(c.Item2 / (double)c.Item3) + " /u" : "";
                var zb = new Rectangle((int)zone.X + S(12), (int)zone.Y + S(54), (int)lc - S(24), S(18));
                TextRenderer.DrawText(g, bas, Theme.F(8.5f), zb, Theme.Faint, f);
                // La variation depuis la veille, à droite de la carte.
                Color cv = !v.HasValue || Math.Abs(v.Value) < 0.0005 ? Theme.Faint : v.Value > 0 ? Theme.Green : Theme.Red;
                TextRenderer.DrawText(g, v.HasValue ? "veille " + Calculs.Pourcent(v) : "veille —", Theme.F(8.5f, v.HasValue), zb, cv, f | TextFormatFlags.Right);
            }
        }

        // ---- Dessins ---------------------------------------------------------------------------------------

        // Télécharge la nouvelle version sur GitHub, l'installe (les relevés restent) et relance le Suivi HDV.
        void InstallerMiseAJour()
        {
            if (MessageBox.Show(this, "Installer la version " + maj.Distante + " (tu as la " + (version != "" ? version : "1.0") + ") ?\n\n" +
                "Le Suivi HDV va se fermer puis se rouvrir. Tes relevés de prix sont gardés.",
                "Suivi HDV", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            bMaj.Enabled = false;
            bMaj.Text = "Installation…";
            Sauver();
            new System.Threading.Thread(() =>
            {
                try
                {
                    maj.Installer();
                    Sur(() =>
                    {
                        // Relance un peu plus tard, une fois cette fenêtre fermée (une seule à la fois).
                        string vbs = Path.Combine(dossierHdv, "Suivi HDV.vbs").Replace("'", "''");
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("powershell.exe",
                            "-NoProfile -WindowStyle Hidden -Command \"Start-Sleep -Seconds 3; Start-Process wscript.exe -ArgumentList '\\\"" + vbs + "\\\"'\"")
                            { UseShellExecute = false, CreateNoWindow = true });
                        Close();
                    });
                }
                catch (Exception ex)
                {
                    Sur(() =>
                    {
                        bMaj.Enabled = true;
                        bMaj.Text = "Installer la v" + maj.Distante;
                        MessageBox.Show(this, "La mise à jour n'a pas pu être installée :\n\n" + ex.Message, "Suivi HDV", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    });
                }
            }) { IsBackground = true }.Start();
        }

        void DessinerEntete(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            if (iconeEntete == null) iconeEntete = Icone.Rendu(S(40));   // dessinée une fois, pas à chaque rafraîchissement
            g.DrawImage(iconeEntete, 0, S(6));
            TextRenderer.DrawText(g, "Suivi HDV", Theme.F(15f, true), new Rectangle(S(52), 0, entete.Width - S(52), S(30)), Theme.Text, f);
            if (version != "")
            {
                int lt = TextRenderer.MeasureText(g, "Suivi HDV", Theme.F(15f, true)).Width;
                TextRenderer.DrawText(g, "v" + version, Theme.F(8f), new Rectangle(S(52) + lt, S(4), S(60), S(24)), Theme.Faint, f);
            }
            string ligne = etat;
            Color c = Theme.Dim;
            if (!toucheOk) { ligne = "La touche " + d.Reglages.Touche + " est déjà prise (ferme l'ancienne fenêtre « Capture HDV », ou change de touche dans Options) · " + etat; c = Theme.Accent; }
            var der = moteur.Activites().LastOrDefault(a => a.Niveau == Niveau.Ok);
            if (der != null) ligne += "   ·   dernier relevé : " + der.Texte + " à " + der.T.ToString("HH:mm");
            TextRenderer.DrawText(g, ligne, Theme.F(9f), new Rectangle(S(52), S(28), entete.Width - S(52), S(22)), c, f);
        }

        void Tuile(Graphics g, RectangleF r, string titre, string valeur, string detailTxt, Color couleur)
        {
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            Theme.Remplir(g, Theme.Card, r, Theme.Sf(10));
            int x = (int)r.X + S(14), w = (int)r.Width - S(28);
            TextRenderer.DrawText(g, titre, Theme.F(8.5f), new Rectangle(x, (int)r.Y + S(6), w, S(20)), Theme.Dim, f);
            TextRenderer.DrawText(g, valeur, Theme.F(14f, true), new Rectangle(x, (int)r.Y + S(24), w, S(28)), couleur, f);
            TextRenderer.DrawText(g, detailTxt, Theme.F(8.5f), new Rectangle(x, (int)r.Y + S(52), w, S(20)), Theme.Faint, f);
        }

        void DessinerTuiles(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            float gap = S(10), lw = (tuiles.Width - 3 * gap) / 4f, h = tuiles.Height;
            string per = d.Reglages.Periode > 0 ? "sur " + d.Reglages.Periode + " jours" : "depuis le début";
            int auj = ressources.Count(r => r.Dernier.T.Date == DateTime.Today);
            Tuile(g, new RectangleF(0, 0, lw, h), "Ressources suivies", ressources.Count.ToString(), d.NbReleves + " relevés au total", Theme.Text);
            Tuile(g, new RectangleF(lw + gap, 0, lw, h), "Relevées aujourd'hui", auj.ToString(), auj > 0 ? "sur " + ressources.Count + " ressources" : "rien encore aujourd'hui", Theme.Text);
            Vue hausse = PlusForte(true), baisse = PlusForte(false);
            Tuile(g, new RectangleF(2 * (lw + gap), 0, lw, h), "Plus forte hausse " + per, hausse != null ? Calculs.Pourcent(hausse.Periode) : "—",
                hausse != null ? hausse.R.Nom + " · " + Calculs.Unitaire(hausse.PrixU) + " k/u" : "pas assez de relevés", hausse != null ? Theme.Green : Theme.Faint);
            Tuile(g, new RectangleF(3 * (lw + gap), 0, lw, h), "Plus forte baisse " + per, baisse != null ? Calculs.Pourcent(baisse.Periode) : "—",
                baisse != null ? baisse.R.Nom + " · " + Calculs.Unitaire(baisse.PrixU) + " k/u" : "pas assez de relevés", baisse != null ? Theme.Red : Theme.Faint);
        }

        void DessinerConso(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var c = d.Consos();
            Func<IEnumerable<Conso>, long> tok = l => l.Where(x => !x.EstOcr).Sum(x => x.Total);
            var auj = c.Where(x => x.T.Date == DateTime.Today).ToList();
            var sept = c.Where(x => x.T >= DateTime.Now.AddDays(-7)).ToList();
            int ocr = c.Where(x => x.EstOcr).Sum(x => x.Captures), cl = c.Where(x => !x.EstOcr).Sum(x => x.Captures);
            float gap = S(10), lw = (conso.Width - 3 * gap) / 4f, h = S(78);
            Tuile(g, new RectangleF(0, 0, lw, h), "Tokens aujourd'hui", tok(auj).ToString("N0", Calculs.Fr).Replace('\u00A0', ' ').Replace('\u202F', ' '), auj.Where(x => !x.EstOcr).Sum(x => x.Captures) + " capture(s) lue(s) par Claude", Theme.Text);
            Tuile(g, new RectangleF(lw + gap, 0, lw, h), "Tokens sur 7 jours", tok(sept).ToString("N0", Calculs.Fr).Replace('\u00A0', ' ').Replace('\u202F', ' '), sept.Count(x => !x.EstOcr) + " appel(s) à Claude", Theme.Text);
            Tuile(g, new RectangleF(2 * (lw + gap), 0, lw, h), "Tokens au total", tok(c).ToString("N0", Calculs.Fr).Replace('\u00A0', ' ').Replace('\u202F', ' '),
                "équivalent API : " + c.Sum(x => x.Usd).ToString("0.00", Calculs.Fr) + " $ (pas facturé)", Theme.Text);
            string part = ocr + cl > 0 ? (ocr * 100 / (ocr + cl)) + " %" : "—";
            Tuile(g, new RectangleF(3 * (lw + gap), 0, lw, h), "Lues gratuitement par l'OCR", part, ocr + " par l'OCR · " + cl + " par Claude", Theme.Green);
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.WordBreak;
            TextRenderer.DrawText(g, "Les tokens de Claude comptent dans les limites de ton abonnement Claude ; ils ne sont pas facturés en plus. " +
                "Tout est lu par l'OCR de Windows, gratuitement. Claude n'est utilisé que si tu le demandes, depuis les captures en attente.",
                Theme.F(9f), new Rectangle(0, (int)h + S(16), conso.Width, S(60)), Theme.Faint, f);
        }
    }
}
