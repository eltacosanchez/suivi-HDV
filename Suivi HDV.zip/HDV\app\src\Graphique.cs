using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace SuiviHDV
{
    /// <summary>
    /// Évolution du prix par unité d'une ressource : une courbe par taille de lot, plus le prix moyen en pointillés.
    /// Clic sur la légende pour masquer une courbe ; au survol, une ligne verticale et le détail du relevé.
    /// </summary>
    public class Graphique : Surface
    {
        class Serie { public string Cle, Nom; public int Lot; public Color Couleur; public bool Pointille; public List<KeyValuePair<DateTime, double>> Pts; public List<long> Bruts; }

        Ressource res;
        DateTime debut = DateTime.MinValue;
        readonly HashSet<string> masques = new HashSet<string>();
        List<Serie> series = new List<Serie>();
        List<RectangleF> legende = new List<RectangleF>();
        Point? souris;

        public Graphique() { BackColor = Theme.Card; }

        public void Afficher(Ressource r, DateTime depuis)
        {
            res = r; debut = depuis;
            Construire();
            Invalidate();
        }

        void Construire()
        {
            series = new List<Serie>();
            if (res == null) return;
            var rel = res.Releves.Where(x => x.T >= debut).ToList();
            for (int i = 0; i < 4; i++)
            {
                int lot = LecteurHdv.Lots[i];
                var avec = rel.Where(x => x.Prix(lot).HasValue).ToList();
                if (avec.Count == 0 && !res.Releves.Any(x => x.Prix(lot).HasValue)) continue;
                series.Add(new Serie
                {
                    Cle = "x" + lot, Nom = "x" + lot, Lot = lot, Couleur = Theme.Series[i],
                    Pts = avec.Select(x => new KeyValuePair<DateTime, double>(x.T, x.ParUnite(lot).Value)).ToList(),
                    Bruts = avec.Select(x => x.Prix(lot).Value).ToList()
                });
            }
            var moy = rel.Where(x => x.Moy.HasValue).ToList();
            if (moy.Count > 0 || res.Releves.Any(x => x.Moy.HasValue))
                series.Add(new Serie
                {
                    Cle = "moy", Nom = "Prix moyen", Lot = 1, Couleur = Theme.Series[4], Pointille = true,
                    Pts = moy.Select(x => new KeyValuePair<DateTime, double>(x.T, x.Moy.Value)).ToList(),
                    Bruts = moy.Select(x => x.Moy.Value).ToList()
                });
        }

        protected override void OnMouseMove(MouseEventArgs e) { souris = e.Location; Cursor = legende.Any(r => r.Contains(e.Location)) ? Cursors.Hand : Cursors.Default; Invalidate(); base.OnMouseMove(e); }
        protected override void OnMouseLeave(EventArgs e) { souris = null; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            for (int i = 0; i < legende.Count && i < series.Count; i++)
                if (legende[i].Contains(e.Location))
                {
                    string c = series[i].Cle;
                    if (!masques.Remove(c)) masques.Add(c);
                    Invalidate();
                }
            base.OnMouseClick(e);
        }

        static double[] Graduations(double min, double max, int n)
        {
            if (max <= min) { double d = Math.Abs(min) * 0.1 + 1; min -= d; max += d; }
            double brut = (max - min) / n;
            double mag = Math.Pow(10, Math.Floor(Math.Log10(brut)));
            double pas = new[] { 1, 2, 2.5, 5, 10 }.Select(m => m * mag).First(p => p >= brut);
            double lo = Math.Floor(min / pas) * pas, hi = Math.Ceiling(max / pas) * pas;
            var t = new List<double>();
            for (double v = lo; v <= hi + pas / 2; v += pas) t.Add(Math.Round(v, 6));
            return t.ToArray();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            const TextFormatFlags f = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;

            // Légende cliquable.
            legende = new List<RectangleF>();
            float lx = Theme.Sf(12), ly = Theme.Sf(10), lh = Theme.Sf(26);
            foreach (var s in series)
            {
                string t = s.Cle == "moy" ? s.Nom : s.Nom + " (par unité)";
                float w = TextRenderer.MeasureText(g, t, Theme.F(8.5f)).Width + Theme.Sf(32);
                var r = new RectangleF(lx, ly, w, lh);
                legende.Add(r);
                bool cache = masques.Contains(s.Cle);
                Theme.Remplir(g, r.Contains(souris ?? Point.Empty) ? Theme.Hover : Theme.Card2, r, lh / 2);
                var pastille = new RectangleF(r.X + Theme.Sf(10), r.Y + (lh - Theme.Sf(10)) / 2, Theme.Sf(10), Theme.Sf(10));
                if (cache) Theme.Contour(g, Theme.Faint, pastille, Theme.Sf(3)); else Theme.Remplir(g, s.Couleur, pastille, Theme.Sf(3));
                TextRenderer.DrawText(g, t, Theme.F(8.5f), new Rectangle((int)(r.X + Theme.Sf(26)), (int)r.Y, (int)(r.Width - Theme.Sf(26)), (int)lh), cache ? Theme.Faint : Theme.Dim, f);
                lx += w + Theme.Sf(6);
            }

            var visibles = series.Where(s => !masques.Contains(s.Cle) && s.Pts.Count > 0).ToList();
            var zone = new RectangleF(Theme.Sf(64), ly + lh + Theme.Sf(16), Width - Theme.Sf(64) - Theme.Sf(78), Height - (ly + lh + Theme.Sf(16)) - Theme.Sf(30));
            if (zone.Width < 50 || zone.Height < 40) return;
            if (visibles.Count == 0)
            {
                TextRenderer.DrawText(g, "Aucun relevé sur cette période", Theme.F(9.5f), Rectangle.Round(zone), Theme.Faint, f | TextFormatFlags.HorizontalCenter);
                return;
            }

            var temps = visibles.SelectMany(s => s.Pts.Select(p => p.Key)).Distinct().OrderBy(t => t).ToList();
            double t0 = temps[0].Ticks, t1 = temps[temps.Count - 1].Ticks;
            if (t1 - t0 < TimeSpan.TicksPerHour) { t0 -= TimeSpan.TicksPerHour * 12; t1 += TimeSpan.TicksPerHour * 12; }
            var grad = Graduations(visibles.Min(s => s.Pts.Min(p => p.Value)), visibles.Max(s => s.Pts.Max(p => p.Value)), 5);
            double lo = grad[0], hi = grad[grad.Length - 1];
            Func<double, float> X = t => zone.X + (float)((t - t0) / (t1 - t0)) * zone.Width;
            Func<double, float> Y = v => zone.Bottom - (float)((v - lo) / Math.Max(1e-9, hi - lo)) * zone.Height;

            using (var grille = new Pen(Theme.Border))
                foreach (double v in grad)
                {
                    g.DrawLine(grille, zone.X, Y(v), zone.Right, Y(v));
                    TextRenderer.DrawText(g, Calculs.Unitaire(v), Theme.F(8f), new Rectangle(0, (int)(Y(v) - Theme.Sf(10)), (int)(zone.X - Theme.Sf(8)), (int)Theme.Sf(20)), Theme.Faint, f | TextFormatFlags.Right);
                }
            int nbDates = Math.Max(2, Math.Min(7, (int)(zone.Width / Theme.Sf(90))));
            for (int i = 0; i < nbDates; i++)
            {
                double t = t0 + (t1 - t0) * i / (nbDates - 1);
                string txt = new DateTime((long)t).ToString(t1 - t0 < TimeSpan.TicksPerDay * 2 ? "d MMM HH:mm" : "d MMM", Calculs.Fr);
                var flags = f | (i == 0 ? TextFormatFlags.Left : i == nbDates - 1 ? TextFormatFlags.Right : TextFormatFlags.HorizontalCenter);
                float w = Theme.Sf(90);
                float x = i == 0 ? X(t) : i == nbDates - 1 ? X(t) - w : X(t) - w / 2;
                TextRenderer.DrawText(g, txt, Theme.F(8f), new Rectangle((int)x, (int)(zone.Bottom + Theme.Sf(6)), (int)w, (int)Theme.Sf(20)), Theme.Faint, flags);
            }

            bool points = temps.Count <= 40;
            foreach (var s in visibles)
            {
                var pts = s.Pts.Select(p => new PointF(X(p.Key.Ticks), Y(p.Value))).ToArray();
                using (var pen = new Pen(s.Couleur, Theme.Sf(2)) { LineJoin = LineJoin.Round })
                {
                    if (s.Pointille) pen.DashPattern = new[] { 3f, 2.5f };
                    if (pts.Length > 1) g.DrawLines(pen, pts);
                }
                if (points || pts.Length == 1)
                    foreach (var p in pts) Pastille(g, p, s.Couleur, Theme.Sf(3));
            }

            // Étiquettes en bout de courbe, écartées pour ne pas se chevaucher.
            var etiq = visibles.Select(s => new { S = s, Y = Y(s.Pts[s.Pts.Count - 1].Value) }).OrderBy(x => x.Y).ToList();
            var ys = etiq.Select(x => x.Y).ToList();
            for (int i = 1; i < ys.Count; i++) if (ys[i] - ys[i - 1] < Theme.Sf(15)) ys[i] = ys[i - 1] + Theme.Sf(15);
            for (int i = 0; i < etiq.Count; i++)
            {
                using (var pen = new Pen(etiq[i].S.Couleur, Theme.Sf(2))) g.DrawLine(pen, zone.Right + Theme.Sf(6), ys[i], zone.Right + Theme.Sf(16), ys[i]);
                TextRenderer.DrawText(g, etiq[i].S.Cle == "moy" ? "moyen" : etiq[i].S.Nom, Theme.F(8.5f), new Rectangle((int)(zone.Right + Theme.Sf(20)), (int)(ys[i] - Theme.Sf(10)), (int)Theme.Sf(60), (int)Theme.Sf(20)), Theme.Dim, f);
            }

            // Survol : relevé le plus proche.
            if (souris.HasValue && zone.Contains(souris.Value))
            {
                var plus = temps.OrderBy(t => Math.Abs(X(t.Ticks) - souris.Value.X)).First();
                float cx = X(plus.Ticks);
                using (var pen = new Pen(Theme.Faint)) g.DrawLine(pen, cx, zone.Y, cx, zone.Bottom);
                var lignes = new List<KeyValuePair<Serie, int>>();
                foreach (var s in visibles)
                {
                    int i = s.Pts.FindIndex(p => p.Key == plus);
                    if (i < 0) continue;
                    lignes.Add(new KeyValuePair<Serie, int>(s, i));
                    Pastille(g, new PointF(cx, Y(s.Pts[i].Value)), s.Couleur, Theme.Sf(4.5f));
                }
                float bw = Theme.Sf(210), bh = Theme.Sf(28) + lignes.Count * Theme.Sf(20);
                float bx = cx + Theme.Sf(14) + bw > Width ? cx - Theme.Sf(14) - bw : cx + Theme.Sf(14);
                float by = Math.Max(zone.Y, Math.Min(souris.Value.Y - bh / 2, zone.Bottom - bh));
                var boite = new RectangleF(bx, by, bw, bh);
                Theme.Remplir(g, Theme.Card2, boite, Theme.Sf(8));
                Theme.Contour(g, Theme.Border, boite, Theme.Sf(8));
                TextRenderer.DrawText(g, plus.ToString("dddd d MMM, HH:mm", Calculs.Fr), Theme.F(8.5f, true),
                    new Rectangle((int)(bx + Theme.Sf(10)), (int)(by + Theme.Sf(4)), (int)(bw - Theme.Sf(20)), (int)Theme.Sf(22)), Theme.Text, f);
                float yy = by + Theme.Sf(26);
                foreach (var l in lignes)
                {
                    var s = l.Key;
                    Theme.Remplir(g, s.Couleur, new RectangleF(bx + Theme.Sf(10), yy + Theme.Sf(5), Theme.Sf(9), Theme.Sf(9)), Theme.Sf(2.5f));
                    string gauche = s.Cle == "moy" ? "Moyen" : s.Nom;
                    string droite = Calculs.Unitaire(s.Pts[l.Value].Value) + " /u" + (s.Lot > 1 ? "  (" + Calculs.Kamas(s.Bruts[l.Value]) + ")" : "");
                    var zl = new Rectangle((int)(bx + Theme.Sf(26)), (int)yy, (int)(bw - Theme.Sf(36)), (int)Theme.Sf(20));
                    TextRenderer.DrawText(g, gauche, Theme.F(8.5f), zl, Theme.Dim, f);
                    TextRenderer.DrawText(g, droite, Theme.F(8.5f), zl, Theme.Text, f | TextFormatFlags.Right);
                    yy += Theme.Sf(20);
                }
            }
        }

        static void Pastille(Graphics g, PointF p, Color c, float r)
        {
            using (var b = new SolidBrush(c)) g.FillEllipse(b, p.X - r, p.Y - r, 2 * r, 2 * r);
            using (var pen = new Pen(Theme.Card, Theme.Sf(1.5f))) g.DrawEllipse(pen, p.X - r, p.Y - r, 2 * r, 2 * r);
        }
    }
}
