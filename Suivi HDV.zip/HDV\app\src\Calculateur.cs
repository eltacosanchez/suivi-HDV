using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace SuiviHDV
{
    /// <summary>
    /// Calculateur de recette, dans sa propre fenêtre : ce que coûtent les ingrédients d'un objet d'après les prix
    /// relevés à l'HDV. S'ouvre tout seul quand la fenêtre « Recettes » de Dofus montre un objet, ou sur un nom tapé.
    /// </summary>
    public class Calculateur : Form
    {
        readonly Donnees d;
        readonly Moteur moteur;
        readonly Champ chNom = new Champ("Nom d'un objet à fabriquer (ex. Ceinture du Tengu Givrefoux)…") { Glyphe = Theme.GRecherche };
        readonly Bouton bCalculer = new Bouton("Calculer") { Principal = true };
        readonly Surface entete = new Surface { BackColor = Theme.Card };
        readonly Tableau table = new Tableau();
        readonly Surface pied = new Surface();
        Recette recette;          // la dernière recette reçue (ou son erreur)
        CoutRecette cout;
        string attente;           // nom en cours de recherche sur DofusDB

        static int S(int v) { return Theme.S(v); }

        public Calculateur(Donnees donnees, Moteur m, Icon icone)
        {
            d = donnees; moteur = m;
            Text = "Calculateur de recette";
            Icon = icone;
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
            Font = Theme.F(9f);
            DoubleBuffered = true;
            MinimumSize = new Size(S(640), S(420));
            ShowInTaskbar = true;
            TopMost = d.Reglages.Epingle;

            var R = d.Reglages;
            var garde = new Rectangle(R.CalcX, R.CalcY, R.CalcL, R.CalcH);
            if (R.CalcX != int.MinValue && R.CalcL > 0 && Screen.AllScreens.Any(s => s.WorkingArea.IntersectsWith(garde)))
            {
                StartPosition = FormStartPosition.Manual;
                Bounds = garde;
            }
            else
            {
                StartPosition = FormStartPosition.CenterScreen;
                Size = new Size(S(820), S(560));
            }

            table.Colonnes.AddRange(new[]
            {
                new Colonne("Ingrédient", 3.2f, false, true),
                new Colonne("Quantité", 1f, true),
                new Colonne("Prix / unité", 1.3f, true),
                new Colonne("D'après le lot", 1.2f, true),
                new Colonne("Coût", 1.4f, true, true),
                new Colonne("Prix relevé le", 1.5f, true),
            });
            table.Vide = "Ouvre la fenêtre « Recettes » dans Dofus sur un objet, ou tape son nom ci-dessus : ses ingrédients et leur coût à l'HDV s'affichent ici.";
            table.Clic += l =>
            {
                var c = l.Etiquette as CoutIngredient;
                if (c != null) { var o = Ouvrir; if (o != null) o(c.I.Nom); }
            };
            entete.Paint += DessinerEntete;
            pied.Paint += DessinerPied;
            bCalculer.Click += delegate { Chercher(chNom.Boite.Text); };
            chNom.Boite.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { Chercher(chNom.Boite.Text); e.Handled = true; e.SuppressKeyPress = true; } };
            Controls.AddRange(new Control[] { chNom, bCalculer, entete, table, pied });
            Placer();
        }

        /// <summary>Clic sur un ingrédient : la fenêtre principale ouvre sa fiche de prix.</summary>
        public event Action<string> Ouvrir;

        // La fenêtre s'ouvre sans prendre le dessus sur Dofus.
        protected override bool ShowWithoutActivation { get { return true; } }

        protected override void OnResize(EventArgs e) { base.OnResize(e); Placer(); }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            // Fermée par l'utilisateur : on la cache seulement, pour la rouvrir à la prochaine recette.
            if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; Hide(); }
            Memoriser();
            base.OnFormClosing(e);
        }

        public void Memoriser()
        {
            var b = WindowState == FormWindowState.Normal ? Bounds : RestoreBounds;
            d.Reglages.CalcX = b.X; d.Reglages.CalcY = b.Y; d.Reglages.CalcL = b.Width; d.Reglages.CalcH = b.Height;
        }

        void Placer()
        {
            if (table == null) return;
            int m = S(16), w = ClientSize.Width - 2 * m, y = m;
            chNom.SetBounds(m, y, w - S(130), S(36));
            bCalculer.SetBounds(m + w - S(120), y, S(120), S(36));
            y += S(36) + S(12);
            entete.SetBounds(m, y, w, S(100)); y += S(100) + S(12);
            int hp = S(24);
            table.SetBounds(m, y, w, ClientSize.Height - m - hp - S(8) - y);
            pied.SetBounds(m, ClientSize.Height - m - hp, w, hp);
        }

        /// <summary>Cherche la recette d'un nom tapé.</summary>
        void Chercher(string nom)
        {
            nom = (nom ?? "").Trim();
            if (nom == "") return;
            attente = nom;
            entete.Invalidate();
            moteur.ChercherRecette(nom, "calculateur");
        }

        /// <summary>Une recette (ou une erreur) arrive du moteur : on l'affiche.</summary>
        public void Montrer(Recette r)
        {
            recette = r;
            attente = null;
            if (r.Erreur == null) chNom.Boite.Text = r.Nom;
            Recalculer();
            if (!Visible) Show();
            else if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        }

        /// <summary>Les prix ont changé (nouveau relevé) : le coût est recalculé avec les mêmes ingrédients.</summary>
        public void Recalculer()
        {
            var lignes = new List<Ligne>();
            cout = null;
            Text = "Calculateur de recette · " + d.Reglages.Serveur;
            if (recette != null && recette.Erreur == null)
            {
                cout = Recettes.Calculer(recette, d.Derniers());
                foreach (var c in cout.Lignes)
                {
                    var l = new Ligne { Etiquette = c, Icone = Images.Charger(d.IconeDe(c.I.Nom)) };
                    if (c.R == null)
                    {
                        l.Cellules = new[] { c.I.Nom, Calculs.Nombre(c.I.Quantite), "prix inconnu", "", "—", "ouvre sa fiche à l'HDV" };
                        l.Couleurs = new Color?[] { null, null, Theme.Red, null, null, Theme.Accent };
                        l.Info = "Jamais relevé. Ouvre la fiche « " + c.I.Nom + " » à l'HDV : son prix sera pris en compte tout seul.";
                    }
                    else
                    {
                        l.Cellules = new[] { c.I.Nom, Calculs.Nombre(c.I.Quantite), Calculs.Unitaire(c.PrixUnitaire), "x" + c.Lot, Calculs.Kamas(c.Cout), Calculs.Date(c.R.T) };
                        l.Couleurs = new Color?[] { null, null, null, Theme.Faint, Theme.Kamas, Ancien(c.R.T) ? Theme.Accent : (Color?)null };
                        l.Info = c.I.Categorie + " · lots relevés : " + string.Join(", ", LecteurHdv.Lots.Where(x => c.R.Prix(x).HasValue).Select(x => "x" + x + " = " + Calculs.Kamas(c.R.Prix(x))))
                            + (Ancien(c.R.T) ? "\nRelevé il y a plus de 7 jours : le prix a pu changer." : "") + "\nClic : ouvrir sa fiche de prix.";
                    }
                    lignes.Add(l);
                }
            }
            table.Remplir(lignes);
            entete.Invalidate();
            pied.Invalidate();
        }

        static bool Ancien(DateTime t) { return (DateTime.Now - t).TotalDays > 7; }

        void DessinerEntete(object sender, PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Theme.Remplir(g, Theme.Card, new RectangleF(0, 0, entete.Width - 1, entete.Height - 1), Theme.Sf(10));
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            int x = S(14), w = entete.Width - S(28);
            if (attente != null)
            {
                TextRenderer.DrawText(g, "Recherche de la recette de « " + attente + " » sur DofusDB…", Theme.F(10f), new Rectangle(x, 0, w, entete.Height), Theme.Dim, f);
                return;
            }
            if (recette == null)
            {
                TextRenderer.DrawText(g, "Calculateur de recette", Theme.F(13f, true), new Rectangle(x, S(10), w, S(28)), Theme.Text, f);
                TextRenderer.DrawText(g, "Combien coûtent les ingrédients d'un objet d'après tes relevés de prix à l'HDV, et s'il revient moins cher de le fabriquer ou de l'acheter.", Theme.F(9f), new Rectangle(x, S(38), w, S(24)), Theme.Dim, f);
                TextRenderer.DrawText(g, "Pour comparer avec l'achat, ouvre aussi la fiche de l'objet à l'HDV : ses 5 offres les moins chères sont relevées.", Theme.F(9f), new Rectangle(x, S(62), w, S(24)), Theme.Faint, f);
                return;
            }
            if (recette.Erreur != null)
            {
                TextRenderer.DrawText(g, recette.Demande, Theme.F(13f, true), new Rectangle(x, S(10), w, S(28)), Theme.Text, f);
                TextRenderer.DrawText(g, recette.Erreur, Theme.F(9f), new Rectangle(x, S(38), w, S(24)), Theme.Red, f);
                return;
            }
            var ic = Images.Charger(d.IconeDe(recette.Nom));
            if (ic != null) { g.DrawImage(ic, new Rectangle(x, S(14), S(48), S(48))); x += S(48) + S(12); w -= S(48) + S(12); }
            int lTotal = S(300);
            TextRenderer.DrawText(g, recette.Nom, Theme.F(13f, true), new Rectangle(x, S(8), w - lTotal, S(28)), Theme.Text, f);
            string sous = recette.Metier + " · niveau " + recette.Niveau + " · " + recette.Ingredients.Count + " ingrédient" + (recette.Ingredients.Count > 1 ? "s" : "")
                + " · " + Calculs.Nombre(recette.Ingredients.Sum(i => i.Quantite)) + " ressources";
            TextRenderer.DrawText(g, sous, Theme.F(9f), new Rectangle(x, S(34), w - lTotal, S(22)), Theme.Dim, f);
            // Ce que coûte l'objet tout fait à l'HDV (ses 5 offres les moins chères, relevées sur sa fiche).
            string hdv; Color ch = Theme.Dim;
            if (cout == null || cout.Objet == null) { hdv = "Prix à l'HDV inconnu : ouvre la fiche de l'objet à l'HDV pour comparer avec l'achat."; ch = Theme.Faint; }
            else
            {
                var o = cout.Objet;
                hdv = "À l'HDV : " + (o.Offres != null ? string.Join(" · ", o.Offres.Select(p => Calculs.Kamas(p))) + " k" : Calculs.Kamas(cout.PrixAchat) + " k")
                    + (o.Moy.HasValue ? " · prix moyen " + Calculs.Kamas(o.Moy) : "") + " · relevé " + Calculs.Date(o.T);
            }
            TextRenderer.DrawText(g, hdv, Theme.F(9f), new Rectangle(S(14), S(70), entete.Width - S(28), S(22)), ch, f);
            // À droite : le coût de fabrication, puis fabriquer ou acheter.
            var zt = new Rectangle(entete.Width - S(14) - lTotal, S(6), lTotal, S(18));
            TextRenderer.DrawText(g, "Fabriquer (ingrédients)", Theme.F(8.5f), zt, Theme.Dim, f | TextFormatFlags.Right);
            if (cout != null)
            {
                string total = Calculs.Kamas(cout.Total) + " k";
                if (cout.SansPrix > 0) total = "≥ " + total;
                TextRenderer.DrawText(g, total, Theme.F(16f, true), new Rectangle(zt.X, S(20), zt.Width, S(30)), Theme.Kamas, f | TextFormatFlags.Right);
                string detail; Color c;
                var eco = cout.Economie;
                if (eco.HasValue && (cout.SansPrix == 0 || eco.Value < 0))
                {
                    // Même sans tous les prix, si fabriquer coûte déjà plus cher qu'acheter, le verdict est sûr.
                    if (eco.Value > 0) { detail = "Fabriquer : " + Calculs.Kamas(eco.Value) + " k moins cher qu'acheter"; c = Theme.Green; }
                    else if (eco.Value < 0) { detail = "Acheter (" + Calculs.Kamas(cout.PrixAchat) + " k) : " + Calculs.Kamas(-eco.Value) + " k moins cher" + (cout.SansPrix > 0 ? ", même sans tous les prix" : ""); c = Theme.Red; }
                    else { detail = "Fabriquer ou acheter : même prix"; c = Theme.Dim; }
                }
                else if (cout.SansPrix > 0) { detail = cout.SansPrix + " ingrédient" + (cout.SansPrix > 1 ? "s" : "") + " sans prix relevé"; c = Theme.Red; }
                else { detail = "Tous les ingrédients ont un prix"; c = Theme.Green; }
                TextRenderer.DrawText(g, detail, Theme.F(9f, true), new Rectangle(zt.X - S(160), S(50), zt.Width + S(160), S(20)), c, f | TextFormatFlags.Right);
            }
        }

        void DessinerPied(object sender, PaintEventArgs e)
        {
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            string t = "Prix tirés de tes relevés : pour un ingrédient sans prix, ouvre sa fiche à l'HDV, le calcul se met à jour tout seul. Clic sur un ingrédient : sa fiche de prix.";
            TextRenderer.DrawText(e.Graphics, t, Theme.F(8.5f), new Rectangle(0, 0, pied.Width, pied.Height), Theme.Faint, f);
        }
    }
}
