using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace SuiviHDV
{
    public class ObjetDofus { public string Nom, Categorie; public long Id, IconId; }

    /// <summary>
    /// DofusDB (base de données publique des objets de Dofus) : confirme qu'un nom lu par l'OCR existe vraiment,
    /// donne sa catégorie, et fournit l'icône de la ressource.
    /// </summary>
    public static class DofusDB
    {
        static readonly Dictionary<string, ObjetDofus> cache = new Dictionary<string, ObjetDofus>();

        static DofusDB()
        {
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
        }

        static string Telecharger(string url)
        {
            using (var wc = new WebClient { Encoding = Encoding.UTF8 })
            {
                wc.Headers[HttpRequestHeader.UserAgent] = "SuiviHDV";
                return wc.DownloadString(url);
            }
        }

        static object Champ(object o, params string[] chemin)
        {
            foreach (string k in chemin)
            {
                var d = o as IDictionary;
                if (d == null || !d.Contains(k)) return null;
                o = d[k];
            }
            return o;
        }

        /// <summary>Cherche un objet par son nom exact, sinon sans tenir compte des majuscules. Null s'il n'existe pas.
        /// Lève une exception si DofusDB ne répond pas.</summary>
        public static ObjetDofus Chercher(string nom)
        {
            nom = (nom ?? "").Trim();
            if (nom == "") return null;
            lock (cache) { ObjetDofus deja; if (cache.TryGetValue(nom, out deja)) return deja; }
            ObjetDofus trouve = null;
            foreach (string champ in new[] { "name.fr", "slug.fr" })
            {
                string valeur = champ == "slug.fr" ? nom.ToLowerInvariant() : nom;
                string json = Telecharger("https://api.dofusdb.fr/items?" + champ + "=" + Uri.EscapeDataString(valeur) + "&$limit=1");
                var data = Champ(new JavaScriptSerializer().DeserializeObject(json), "data") as IEnumerable;
                if (data == null) continue;
                foreach (object o in data)
                {
                    trouve = Objet(o);
                    break;
                }
                if (trouve != null) break;
            }
            lock (cache) cache[nom] = trouve;
            return trouve;
        }

        static ObjetDofus Objet(object o)
        {
            return new ObjetDofus
            {
                Id = Convert.ToInt64(Champ(o, "id") ?? 0L),
                Nom = Convert.ToString(Champ(o, "name", "fr")),
                Categorie = Convert.ToString(Champ(o, "type", "name", "fr")),
                IconId = Convert.ToInt64(Champ(o, "iconId") ?? 0L)
            };
        }

        static readonly Dictionary<string, Recette> recettes = new Dictionary<string, Recette>();

        /// <summary>
        /// La recette d'un objet : d'abord par son nom exact, sinon par le nom corrigé par DofusDB (l'OCR peut se
        /// tromper d'une majuscule ou d'un accent). Null si l'objet n'a pas de recette. Lève une exception si
        /// DofusDB ne répond pas.
        /// </summary>
        public static Recette Recette(string nom)
        {
            nom = (nom ?? "").Trim();
            if (nom == "") return null;
            string cle = Ecran.Normaliser(nom);
            lock (recettes) { Recette deja; if (recettes.TryGetValue(cle, out deja)) return deja; }
            var data = Donnees_("https://api.dofusdb.fr/recipes?resultName.fr=" + Uri.EscapeDataString(nom) + "&$limit=1");
            if (data == null)
            {
                var o = Chercher(nom);
                if (o != null && o.Id > 0) data = Donnees_("https://api.dofusdb.fr/recipes?resultId=" + o.Id + "&$limit=1");
            }
            Recette r = null;
            if (data != null)
            {
                r = new Recette
                {
                    Nom = Convert.ToString(Champ(data, "result", "name", "fr")),
                    Categorie = Convert.ToString(Champ(data, "result", "type", "name", "fr")),
                    IconId = Convert.ToInt64(Champ(data, "result", "iconId") ?? 0L),
                    Metier = Convert.ToString(Champ(data, "job", "name", "fr")),
                    Niveau = Convert.ToInt32(Champ(data, "resultLevel") ?? 0)
                };
                var ingredients = Champ(data, "ingredients") as IList;
                var quantites = Champ(data, "quantities") as IList;
                var ids = Champ(data, "ingredientIds") as IList;
                if (ingredients != null && quantites != null)
                    for (int i = 0; i < ingredients.Count && i < quantites.Count; i++)
                    {
                        object ing = ingredients[i];
                        // Les ingrédients ne sont pas toujours dans l'ordre des quantités : on se fie à l'id.
                        int k = i;
                        if (ids != null)
                        {
                            long id = Convert.ToInt64(Champ(ing, "id") ?? -1L);
                            for (int j = 0; j < ids.Count; j++) if (Convert.ToInt64(ids[j]) == id) { k = j; break; }
                        }
                        r.Ingredients.Add(new Ingredient
                        {
                            Nom = Convert.ToString(Champ(ing, "name", "fr")),
                            Categorie = Convert.ToString(Champ(ing, "type", "name", "fr")),
                            IconId = Convert.ToInt64(Champ(ing, "iconId") ?? 0L),
                            Quantite = k < quantites.Count ? Convert.ToInt64(quantites[k]) : 1
                        });
                    }
                if (string.IsNullOrEmpty(r.Nom) || r.Ingredients.Count == 0) r = null;
            }
            lock (recettes) recettes[cle] = r;
            return r;
        }

        // Le premier élément de « data » de la réponse, ou null s'il n'y en a pas.
        static object Donnees_(string url)
        {
            var data = Champ(new JavaScriptSerializer().DeserializeObject(Telecharger(url)), "data") as IEnumerable;
            if (data == null) return null;
            foreach (object o in data) return o;
            return null;
        }

        /// <summary>Télécharge l'icône d'une ressource (une seule fois) et la note dans les données.</summary>
        public static void Icone(Donnees d, string nom)
        {
            if (d.AIcone(nom)) return;
            ObjetDofus o;
            try { o = Chercher(nom); } catch { return; }   // réseau indisponible : on réessaiera plus tard
            Icone(d, nom, o == null ? 0 : o.IconId);
        }

        /// <summary>Même chose quand on connaît déjà le numéro de l'icône (ingrédients d'une recette).</summary>
        public static void Icone(Donnees d, string nom, long iconId)
        {
            if (d.AIcone(nom)) return;
            if (iconId <= 0) { d.AjouterIcone(nom, null); return; }
            string fichier = iconId + ".png";
            string dest = Path.Combine(d.Dossier, "icones", fichier);
            try
            {
                if (!File.Exists(dest))
                {
                    byte[] octets;
                    using (var wc = new WebClient()) { wc.Headers[HttpRequestHeader.UserAgent] = "SuiviHDV"; octets = wc.DownloadData("https://api.dofusdb.fr/img/items/" + fichier); }
                    // On ne garde que de vraies images PNG.
                    if (octets.Length < 8 || octets[0] != 137 || octets[1] != 80 || octets[2] != 78 || octets[3] != 71) return;
                    File.WriteAllBytes(dest, octets);
                }
                d.AjouterIcone(nom, "icones/" + fichier);
            }
            catch { }
        }
    }
}
