using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace SuiviHDV
{
    public class ObjetDofus { public string Nom, Categorie; public long IconId; }

    /// <summary>
    /// DofusDB (base de données publique des objets de Dofus) : confirme qu'un nom lu par l'OCR existe vraiment,
    /// donne sa catégorie, et fournit l'icône de la ressource.
    /// </summary>
    public static class DofusDB
    {
        static readonly Dictionary<string, ObjetDofus> cache = new Dictionary<string, ObjetDofus>();

        static DofusDB()
        {
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
        }

        static string Telecharger(string url)
        {
            using (var wc = new WebClient { Encoding = Encoding.UTF8 })
            {
                wc.Headers[HttpRequestHeader.UserAgent] = "SuiviHDV";
                return wc.DownloadString(url);
            }
        }

        static object Champ(object o, params string[] chemin)
        {
            foreach (string k in chemin)
            {
                var d = o as IDictionary;
                if (d == null || !d.Contains(k)) return null;
                o = d[k];
            }
            return o;
        }

        /// <summary>Cherche un objet par son nom exact, sinon sans tenir compte des majuscules. Null s'il n'existe pas.
        /// Lève une exception si DofusDB ne répond pas.</summary>
        public static ObjetDofus Chercher(string nom)
        {
            nom = (nom ?? "").Trim();
            if (nom == "") return null;
            lock (cache) { ObjetDofus deja; if (cache.TryGetValue(nom, out deja)) return deja; }
            ObjetDofus trouve = null;
            foreach (string champ in new[] { "name.fr", "slug.fr" })
            {
                string valeur = champ == "slug.fr" ? nom.ToLowerInvariant() : nom;
                string json = Telecharger("https://api.dofusdb.fr/items?" + champ + "=" + Uri.EscapeDataString(valeur) + "&$limit=1");
                var data = Champ(new JavaScriptSerializer().DeserializeObject(json), "data") as IEnumerable;
                if (data == null) continue;
                foreach (object o in data)
                {
                    trouve = new ObjetDofus
                    {
                        Nom = Convert.ToString(Champ(o, "name", "fr")),
                        Categorie = Convert.ToString(Champ(o, "type", "name", "fr")),
                        IconId = Convert.ToInt64(Champ(o, "iconId") ?? 0L)
                    };
                    break;
                }
                if (trouve != null) break;
            }
            lock (cache) cache[nom] = trouve;
            return trouve;
        }

        /// <summary>Télécharge l'icône d'une ressource (une seule fois) et la note dans les données.</summary>
        public static void Icone(Donnees d, string nom)
        {
            if (d.AIcone(nom)) return;
            ObjetDofus o;
            try { o = Chercher(nom); } catch { return; }   // réseau indisponible : on réessaiera plus tard
            if (o == null || o.IconId <= 0) { d.AjouterIcone(nom, null); return; }
            string fichier = o.IconId + ".png";
            string dest = Path.Combine(d.Dossier, "icones", fichier);
            try
            {
                if (!File.Exists(dest))
                {
                    byte[] octets;
                    using (var wc = new WebClient()) { wc.Headers[HttpRequestHeader.UserAgent] = "SuiviHDV"; octets = wc.DownloadData("https://api.dofusdb.fr/img/items/" + fichier); }
                    // On ne garde que de vraies images PNG.
                    if (octets.Length < 8 || octets[0] != 137 || octets[1] != 80 || octets[2] != 78 || octets[3] != 71) return;
                    File.WriteAllBytes(dest, octets);
                }
                d.AjouterIcone(nom, "icones/" + fichier);
            }
            catch { }
        }
    }
}
