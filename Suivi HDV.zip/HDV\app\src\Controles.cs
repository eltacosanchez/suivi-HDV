using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace SuiviHDV
{
    /// <summary>Zone dessinée à la main (sans scintillement).</summary>
    public class Surface : Control
    {
        public Surface()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer |
                ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Theme.Bg;
            ForeColor = Theme.Text;
        }
    }

    public class Bouton : Surface
    {
        public string Glyphe;        // icône Segoe MDL2 à côté du texte (ou seule si pas de texte)
        public bool Principal;       // bouton doré
        public bool Actif;           // bouton bascule enfoncé
        bool survol, appui;

        public Bouton(string texte) { Text = texte; Cursor = Cursors.Hand; TabStop = false; }

        protected override void OnMouseEnter(EventArgs e) { survol = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { survol = false; appui = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { appui = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { appui = false; Invalidate(); base.OnMouseUp(e); }
        protected override void OnTextChanged(EventArgs e) { Invalidate(); base.OnTextChanged(e); }
        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Color fond, texte;
            if (Principal) { fond = survol ? Theme.Mix(Theme.Accent, Color.White, 0.12f) : Theme.Accent; texte = Theme.OnAccent; }
            else if (Actif) { fond = Theme.Mix(Theme.Accent, Theme.Card2, 0.75f); texte = Theme.Accent; }
            else { fond = survol ? Theme.Hover : Theme.Card2; texte = Theme.Text; }
            if (appui) fond = Theme.Mix(fond, Color.Black, 0.15f);
            if (!Enabled) { fond = Theme.Card; texte = Theme.Faint; }
            Theme.Remplir(g, fond, new RectangleF(0, 0, Width - 1, Height - 1), Theme.Sf(7));
            const TextFormatFlags f = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;
            if (Glyphe != null && string.IsNullOrEmpty(Text))
            {
                TextRenderer.DrawText(g, Glyphe, Theme.Icones(10.5f), ClientRectangle, texte, f | TextFormatFlags.HorizontalCenter);
                return;
            }
            var police = Theme.F(9.5f, Principal);
            if (Glyphe == null)
            {
                TextRenderer.DrawText(g, Text, police, ClientRectangle, texte, f | TextFormatFlags.HorizontalCenter);
                return;
            }
            // Icône + texte, centrés ensemble.
            int lg = Theme.S(16), esp = Theme.S(6);
            int lt = TextRenderer.MeasureText(g, Text, police, Size.Empty, f).Width;
            int x = Math.Max(Theme.S(6), (Width - lg - esp - lt) / 2);
            TextRenderer.DrawText(g, Glyphe, Theme.Icones(10f), new Rectangle(x, 0, lg, Height), texte, f | TextFormatFlags.HorizontalCenter);
            TextRenderer.DrawText(g, Text, police, new Rectangle(x + lg + esp, 0, Width - x - lg - esp, Height), texte, f | TextFormatFlags.EndEllipsis);
        }
    }

    /// <summary>Interrupteur on/off avec son libellé (et une ligne d'explication facultative).</summary>
    public class Interrupteur : Surface
    {
        bool actif, survol;
        public string Detail;
        public event Action Change;

        public bool Actif
        {
            get { return actif; }
            set { if (value == actif) return; actif = value; Invalidate(); }
        }

        public Interrupteur(string texte) { Text = texte; Cursor = Cursors.Hand; BackColor = Theme.Card; }

        protected override void OnMouseEnter(EventArgs e) { survol = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { survol = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            actif = !actif; Invalidate();
            var c = Change; if (c != null) c();
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Theme.Remplir(g, survol ? Theme.Mix(Theme.Card, Theme.Hover, 0.5f) : Theme.Card, new RectangleF(0, 0, Width - 1, Height - 1), Theme.Sf(8));
            float lw = Theme.Sf(36), lh = Theme.Sf(20);
            var piste = new RectangleF(Width - lw - Theme.Sf(10), (Height - lh) / 2f, lw, lh);
            Theme.Remplir(g, actif ? Theme.Accent : Theme.Border, piste, lh / 2);
            float d = lh - Theme.Sf(6);
            var rond = new RectangleF(actif ? piste.Right - d - Theme.Sf(3) : piste.X + Theme.Sf(3), piste.Y + Theme.Sf(3), d, d);
            using (var b = new SolidBrush(actif ? Theme.OnAccent : Theme.Dim)) g.FillEllipse(b, rond);

            int x = Theme.S(10), w = (int)(piste.X - x - Theme.S(8));
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis;
            if (string.IsNullOrEmpty(Detail))
                TextRenderer.DrawText(g, Text, Theme.F(9.5f, true), new Rectangle(x, 0, w, Height), Theme.Text, f | TextFormatFlags.VerticalCenter);
            else
            {
                TextRenderer.DrawText(g, Text, Theme.F(9.5f, true), new Rectangle(x, Height / 2 - Theme.S(18), w, Theme.S(18)), Theme.Text, f | TextFormatFlags.Bottom);
                TextRenderer.DrawText(g, Detail, Theme.F(8f), new Rectangle(x, Height / 2, w, Theme.S(16)), actif ? Theme.Dim : Theme.Faint, f);
            }
        }
    }

    /// <summary>Barre d'onglets façon segments.</summary>
    public class Onglets : Surface
    {
        public string[] Noms = new string[0];
        int index, survol = -1;
        public event Action Change;

        public int Index
        {
            get { return index; }
            set { if (value == index) return; index = value; Invalidate(); var c = Change; if (c != null) c(); }
        }

        public Onglets() { Cursor = Cursors.Hand; }

        RectangleF Case(int i)
        {
            float l = (Width - 1f) / Math.Max(1, Noms.Length);
            return new RectangleF(i * l, 0, l, Height - 1);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = (int)(e.X / ((Width - 1f) / Math.Max(1, Noms.Length)));
            if (s != survol) { survol = s; Invalidate(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseLeave(EventArgs e) { survol = -1; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            int s = (int)(e.X / ((Width - 1f) / Math.Max(1, Noms.Length)));
            if (s >= 0 && s < Noms.Length) Index = s;
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Theme.Remplir(g, Theme.Card, new RectangleF(0, 0, Width - 1, Height - 1), Theme.Sf(8));
            for (int i = 0; i < Noms.Length; i++)
            {
                var r = Case(i);
                var interieur = RectangleF.Inflate(r, -Theme.Sf(3), -Theme.Sf(3));
                if (i == index) Theme.Remplir(g, Theme.Card2, interieur, Theme.Sf(6));
                else if (i == survol) Theme.Remplir(g, Theme.Mix(Theme.Card, Theme.Card2, 0.5f), interieur, Theme.Sf(6));
                TextRenderer.DrawText(g, Noms[i], Theme.F(9f, i == index), Rectangle.Round(r), i == index ? Theme.Accent : Theme.Dim,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
            }
        }
    }

    /// <summary>Pastilles cliquables qui passent à la ligne : les catégories de ressources.</summary>
    public class Puces : Surface
    {
        public List<KeyValuePair<string, int>> Elements = new List<KeyValuePair<string, int>>();
        public string Choix = "";
        public event Action Change;
        int survol = -1;
        List<RectangleF> cases = new List<RectangleF>();

        public Puces() { Cursor = Cursors.Hand; }

        /// <summary>Calcule la place des pastilles et renvoie la hauteur nécessaire pour la largeur donnée.</summary>
        public int Disposer(int largeur)
        {
            cases = new List<RectangleF>();
            float x = 0, y = 0, h = Theme.Sf(28), esp = Theme.Sf(6);
            using (var g = CreateGraphics())
                foreach (var el in Elements)
                {
                    float w = TextRenderer.MeasureText(g, Libelle(el), Theme.F(9f)).Width + Theme.Sf(22);
                    if (x > 0 && x + w > largeur) { x = 0; y += h + esp; }
                    cases.Add(new RectangleF(x, y, w, h));
                    x += w + esp;
                }
            return Elements.Count == 0 ? 0 : (int)(y + h + 1);
        }

        static string Libelle(KeyValuePair<string, int> el) { return el.Key + "  " + el.Value; }

        int Sous(Point p)
        {
            for (int i = 0; i < cases.Count; i++) if (cases[i].Contains(p)) return i;
            return -1;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = Sous(e.Location);
            if (s != survol) { survol = s; Invalidate(); }
            base.OnMouseMove(e);
        }
        protected override void OnMouseLeave(EventArgs e) { survol = -1; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            int s = Sous(e.Location);
            if (s >= 0 && Elements[s].Key != Choix) { Choix = Elements[s].Key; Invalidate(); var c = Change; if (c != null) c(); }
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            for (int i = 0; i < cases.Count && i < Elements.Count; i++)
            {
                var r = cases[i];
                bool choisi = Elements[i].Key == Choix;
                Color fond = choisi ? Theme.Accent : (i == survol ? Theme.Hover : Theme.Card2);
                Theme.Remplir(g, fond, r, r.Height / 2);
                var rr = Rectangle.Round(r);
                string nom = Elements[i].Key, nb = Elements[i].Value.ToString();
                const TextFormatFlags f = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;
                int ln = TextRenderer.MeasureText(g, nom, Theme.F(9f), Size.Empty, f).Width;
                int lb = TextRenderer.MeasureText(g, nb, Theme.F(9f), Size.Empty, f).Width;
                int x = rr.X + (rr.Width - ln - lb - Theme.S(2)) / 2;
                TextRenderer.DrawText(g, nom, Theme.F(9f), new Rectangle(x, rr.Y, ln, rr.Height), choisi ? Theme.OnAccent : Theme.Text, f);
                TextRenderer.DrawText(g, nb, Theme.F(9f), new Rectangle(x + ln + Theme.S(2), rr.Y, lb, rr.Height),
                    choisi ? Theme.Mix(Theme.OnAccent, Theme.Accent, 0.4f) : Theme.Faint, f);
            }
        }
    }

    /// <summary>Champ de saisie sombre aux coins arrondis, avec un texte gris tant qu'il est vide.</summary>
    public class Champ : Surface
    {
        public readonly TextBox Boite = new TextBox();
        string indice;
        public string Glyphe;

        public string Indice
        {
            get { return indice; }
            set { if (indice == value) return; indice = value; Invalidate(); }
        }

        public Champ(string indice)
        {
            this.indice = indice;
            Boite.BorderStyle = BorderStyle.None;
            Boite.BackColor = Theme.Card2;
            Boite.ForeColor = Theme.Text;
            Boite.Font = Theme.F(10f);
            Controls.Add(Boite);
            Cursor = Cursors.IBeam;
            // La boîte est cachée quand elle est vide et sans le focus : le champ dessine alors l'indice à sa place.
            Boite.GotFocus += delegate { Invalidate(); };
            Boite.LostFocus += delegate { MajIndice(); Invalidate(); };
            Boite.TextChanged += delegate { if (!Boite.Focused) MajIndice(); };
            MajIndice();
        }

        void MajIndice() { Boite.Visible = Boite.Focused || Boite.Text.Length > 0; Invalidate(); }

        protected override void OnClick(EventArgs e)
        {
            Boite.Visible = true;
            Boite.Focus();
            base.OnClick(e);
        }

        int Gauche { get { return Glyphe != null ? Theme.S(32) : Theme.S(10); } }

        protected override void OnLayout(LayoutEventArgs e)
        {
            int m = Gauche;
            Boite.SetBounds(m, (Height - Boite.PreferredHeight) / 2, Width - m - Theme.S(10), Boite.PreferredHeight);
            base.OnLayout(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new RectangleF(0, 0, Width - 1, Height - 1);
            Theme.Remplir(g, Theme.Card2, r, Theme.Sf(7));
            Theme.Contour(g, Boite.Focused ? Theme.Accent : Theme.Border, r, Theme.Sf(7));
            if (Glyphe != null)
                TextRenderer.DrawText(g, Glyphe, Theme.Icones(10f), new Rectangle(Theme.S(8), 0, Theme.S(20), Height), Theme.Faint,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter);
            if (!Boite.Visible)
                TextRenderer.DrawText(g, indice, Boite.Font, new Rectangle(Gauche, 0, Width - Gauche - Theme.S(10), Height), Theme.Faint,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }

    public class Colonne
    {
        public string Titre;
        public float Poids = 1;
        public bool Droite;
        public bool Gras;
        public Colonne(string titre, float poids, bool droite = false, bool gras = false) { Titre = titre; Poids = poids; Droite = droite; Gras = gras; }
    }

    public class Ligne
    {
        public string[] Cellules;
        public Color?[] Couleurs;    // couleur particulière d'une cellule (hausse / baisse…)
        public string Info;          // texte de l'infobulle
        public object Etiquette;
        public bool Discrete;        // texte grisé
        public Image Icone;          // petite image devant la première cellule
    }

    /// <summary>Tableau dessiné : en-tête, lignes, défilement à la molette.</summary>
    public class Tableau : Surface
    {
        public List<Colonne> Colonnes = new List<Colonne>();
        public string Vide = "";
        public event Action<Ligne> Clic;

        List<Ligne> lignes = new List<Ligne>();
        int premier, survol = -1;
        readonly ToolTip bulle = new ToolTip { InitialDelay = 300, ReshowDelay = 100 };
        string bulleTexte;

        int HLigne { get { return Theme.S(30); } }
        int HEntete { get { return Theme.S(26); } }
        int Visibles { get { return Math.Max(1, (Height - HEntete) / HLigne); } }

        public Tableau() { BackColor = Theme.Card; }

        public void Remplir(List<Ligne> l)
        {
            lignes = l ?? new List<Ligne>();
            premier = Math.Max(0, Math.Min(premier, lignes.Count - Visibles));
            Invalidate();
        }

        float[] Bords()
        {
            float total = Colonnes.Sum(c => c.Poids);
            float largeur = Width - Theme.S(16);
            var b = new float[Colonnes.Count + 1];
            b[0] = Theme.S(8);
            for (int i = 0; i < Colonnes.Count; i++) b[i + 1] = b[i] + largeur * Colonnes[i].Poids / total;
            return b;
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            int max = Math.Max(0, lignes.Count - Visibles);
            premier = Math.Max(0, Math.Min(max, premier - Math.Sign(e.Delta) * 3));
            Invalidate();
            base.OnMouseWheel(e);
        }

        protected override void OnMouseEnter(EventArgs e) { Focus(); base.OnMouseEnter(e); }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = e.Y < HEntete ? -1 : premier + (e.Y - HEntete) / HLigne;
            if (s >= lignes.Count) s = -1;
            if (s != survol) { survol = s; Invalidate(); }
            Cursor = s >= 0 && Clic != null ? Cursors.Hand : Cursors.Default;
            string info = s >= 0 ? lignes[s].Info : null;
            if (info != bulleTexte) { bulleTexte = info; bulle.SetToolTip(this, info ?? ""); }
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { survol = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (survol >= 0 && survol < lignes.Count) { var c = Clic; if (c != null) c(lignes[survol]); }
            base.OnMouseClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var b = Bords();
            const TextFormatFlags base_ = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine;

            for (int i = 0; i < Colonnes.Count; i++)
            {
                var r = new Rectangle((int)b[i] + Theme.S(4), 0, (int)(b[i + 1] - b[i]) - Theme.S(8), HEntete);
                TextRenderer.DrawText(g, Colonnes[i].Titre, Theme.F(8f), r, Theme.Faint, base_ | (Colonnes[i].Droite ? TextFormatFlags.Right : 0));
            }
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, Theme.S(8), HEntete - 1, Width - Theme.S(8), HEntete - 1);

            if (lignes.Count == 0)
            {
                var r = new Rectangle(Theme.S(12), HEntete + Theme.S(8), Width - Theme.S(24), Height - HEntete - Theme.S(16));
                TextRenderer.DrawText(g, Vide, Theme.F(9f), r, Theme.Faint, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix);
                return;
            }

            int y = HEntete;
            for (int k = premier; k < lignes.Count && y < Height; k++, y += HLigne)
            {
                var l = lignes[k];
                if (k == survol) Theme.Remplir(g, Theme.Hover, new RectangleF(Theme.S(4), y + 1, Width - Theme.S(8), HLigne - 2), Theme.Sf(6));
                for (int i = 0; i < Colonnes.Count && i < l.Cellules.Length; i++)
                {
                    var c = Colonnes[i];
                    var r = new Rectangle((int)b[i] + Theme.S(4), y, (int)(b[i + 1] - b[i]) - Theme.S(8), HLigne);
                    if (i == 0 && l.Icone != null)
                    {
                        int ic = HLigne - Theme.S(6);
                        g.DrawImage(l.Icone, new Rectangle(r.X, y + Theme.S(3), ic, ic));
                        r.X += ic + Theme.S(6); r.Width -= ic + Theme.S(6);
                    }
                    Color couleur = l.Discrete ? Theme.Faint : (c.Gras ? Theme.Text : Theme.Dim);
                    if (l.Couleurs != null && i < l.Couleurs.Length && l.Couleurs[i].HasValue) couleur = l.Couleurs[i].Value;
                    TextRenderer.DrawText(g, l.Cellules[i], Theme.F(9f, c.Gras && !l.Discrete), r, couleur, base_ | (c.Droite ? TextFormatFlags.Right : 0));
                }
            }

            int vis = Visibles;
            if (lignes.Count > vis)
            {
                float h = Height - HEntete - Theme.S(8);
                float lg = Math.Max(Theme.S(20), h * vis / lignes.Count);
                float pos = HEntete + Theme.S(4) + (h - lg) * premier / Math.Max(1, lignes.Count - vis);
                Theme.Remplir(g, Theme.Border, new RectangleF(Width - Theme.S(5), pos, Theme.S(3), lg), Theme.Sf(1.5f));
            }
        }
    }
}
