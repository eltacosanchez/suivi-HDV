using System;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace SuiviHDV
{
    /// <summary>
    /// Son de notification : le début d'un MP3 (ou WAV) du dossier HDV\sons, joué avec le lecteur intégré à Windows
    /// (MCI), sans rien installer.
    /// </summary>
    public static class Musique
    {
        [DllImport("winmm.dll", CharSet = CharSet.Unicode)] static extern int mciSendString(string commande, StringBuilder retour, int taille, IntPtr rappel);

        public const int DureeMs = 6000;
        static readonly string[] Extensions = { ".mp3", ".wav" };

        static int Mci(string commande) { return mciSendString(commande, null, 0, IntPtr.Zero); }

        /// <summary>Le son choisi : le premier MP3 ou WAV du dossier des sons, ou null.</summary>
        public static string Fichier(string dossierSons)
        {
            try
            {
                return Directory.GetFiles(dossierSons).Where(f => Extensions.Contains(Path.GetExtension(f).ToLowerInvariant()))
                    .OrderBy(f => f, StringComparer.OrdinalIgnoreCase).FirstOrDefault();
            }
            catch { return null; }
        }

        /// <summary>Vrai si la musique est en train de jouer.</summary>
        public static bool EnCours
        {
            get
            {
                var sb = new StringBuilder(32);
                return mciSendString("status suivihdv_son mode", sb, sb.Capacity, IntPtr.Zero) == 0 && sb.ToString() == "playing";
            }
        }

        /// <summary>
        /// Joue les premières secondes du fichier. Faux si Windows n'a pas pu l'ouvrir.
        /// « recommencer » faux : si la musique joue déjà, on la laisse finir au lieu de la relancer.
        /// </summary>
        public static bool Jouer(string fichier, int dureeMs = DureeMs, bool recommencer = true)
        {
            if (!recommencer && EnCours) return true;
            Arreter();
            if (string.IsNullOrEmpty(fichier) || !File.Exists(fichier)) return false;
            if (Mci("open \"" + fichier + "\" type mpegvideo alias suivihdv_son") != 0) return false;
            Mci("set suivihdv_son time format milliseconds");
            // Volume réglé avant de jouer (MCI : de 0 à 1000).
            Mci("setaudio suivihdv_son volume to " + Math.Max(0, Math.Min(100, VolumePourcent)) * 10);
            return Mci("play suivihdv_son from 0 to " + dureeMs) == 0;
        }

        /// <summary>Volume de la musique, en pour cent du volume de Windows (2 % : à peine audible).</summary>
        public static int VolumePourcent = 2;

        /// <summary>Vrai si Windows sait lire ce fichier (sans le jouer).</summary>
        public static bool Lisible(string fichier)
        {
            if (string.IsNullOrEmpty(fichier) || !File.Exists(fichier)) return false;
            const string alias = "suivihdv_test";
            if (Mci("open \"" + fichier + "\" type mpegvideo alias " + alias) != 0) return false;
            var sb = new StringBuilder(64);
            Mci("set " + alias + " time format milliseconds");
            bool ok = mciSendString("status " + alias + " length", sb, sb.Capacity, IntPtr.Zero) == 0 && sb.Length > 0;
            Mci("close " + alias);
            return ok;
        }

        public static void Arreter() { Mci("close suivihdv_son"); }
    }
}
