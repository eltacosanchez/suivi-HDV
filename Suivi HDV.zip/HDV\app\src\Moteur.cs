using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace SuiviHDV
{
    public enum Niveau { Info, Ok, Alerte, Erreur }

    public class Activite
    {
        public DateTime T = DateTime.Now;
        public string Texte;
        public Niveau Niveau;
        public string Source = "";   // « auto », « F9 », « Claude »…
    }

    /// <summary>
    /// Le moteur de l'appli, dans deux fils à part pour ne jamais figer la fenêtre :
    /// - l'analyse automatique lit les fenêtres Dofus toutes les quelques secondes ; une fiche HDV lue deux fois
    ///   pareil est enregistrée (sauf si elle vient déjà d'être relevée avec les mêmes prix) ;
    /// - la file des captures (F9, ou fiches que l'analyse n'a pas su lire) : OCR d'abord, puis Claude en secours
    ///   s'il est activé, sinon la capture est mise en attente.
    /// </summary>
    public class Moteur
    {
        readonly Donnees d;
        readonly string aTraiter, traitees, enAttente, aVerifier, journal;
        public event Action<Activite> Nouvelle;
        public event Action<string> Etat;
        public event Action Attente;

        Thread filAnalyse, filFile;
        volatile bool arret;
        readonly List<string> demandesClaude = new List<string>();   // captures en attente choisies par l'utilisateur
        readonly string ignorees;
        // Noms des fiches illisibles gardées récemment, pour ne pas garder deux fois la même.
        readonly List<KeyValuePair<DateTime, string>> recentes = new List<KeyValuePair<DateTime, string>>();
        readonly AutoResetEvent reveil = new AutoResetEvent(false);
        readonly List<Activite> activites = new List<Activite>();
        public volatile bool ClaudeOccupe;

        class SuiviFenetre { public string Cle; public int Vu; public int Illisible; public bool Gardee, Hdv; public string Signale; }
        readonly Dictionary<IntPtr, SuiviFenetre> fenetres = new Dictionary<IntPtr, SuiviFenetre>();

        public Moteur(Donnees donnees, string dossierHdv)
        {
            d = donnees;
            aTraiter = Path.Combine(dossierHdv, @"captures\a_traiter");
            traitees = Path.Combine(dossierHdv, @"captures\traitees");
            enAttente = Path.Combine(dossierHdv, @"captures\en_attente");
            aVerifier = Path.Combine(dossierHdv, @"captures\a_verifier");
            journal = Path.Combine(dossierHdv, "journal.txt");
            ignorees = Path.Combine(dossierHdv, @"captures\ignorees");
            foreach (string dossier in new[] { aTraiter, traitees, enAttente, aVerifier, ignorees }) Directory.CreateDirectory(dossier);
        }

        /// <summary>Les captures en attente, de la plus ancienne à la plus récente.</summary>
        public List<string> ListeAttente()
        {
            try { return Directory.GetFiles(enAttente, "*.png").OrderBy(f => f).ToList(); } catch { return new List<string>(); }
        }

        /// <summary>Fait relire par Claude les captures choisies (même si Claude est coupé : c'est une demande explicite).</summary>
        public void RelireFichiers(IEnumerable<string> fichiers)
        {
            lock (demandesClaude) demandesClaude.AddRange(fichiers.Where(f => !demandesClaude.Contains(f)));
            reveil.Set();
        }

        // Captures renvoyées à l'OCR par l'utilisateur : si l'OCR échoue encore, elles retournent en attente (jamais à Claude).
        readonly HashSet<string> ocrSeulement = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        /// <summary>Fait relire les captures choisies par l'OCR (gratuit) ; celles qui restent illisibles retournent en attente.</summary>
        public void RelireOcr(IEnumerable<string> fichiers)
        {
            foreach (string f in fichiers)
                try
                {
                    if (!File.Exists(f)) continue;
                    string cible = Deplacer(f, aTraiter);
                    File.SetLastWriteTime(cible, DateTime.Now.AddSeconds(-5));
                    lock (ocrSeulement) ocrSeulement.Add(Path.GetFileName(cible));
                }
                catch { }
            SignalerAttente();
            reveil.Set();
        }

        /// <summary>Met de côté les captures choisies (dossier captures\ignorees) sans les faire lire.</summary>
        public void Ignorer(IEnumerable<string> fichiers)
        {
            int n = 0;
            foreach (string f in fichiers)
                try { if (File.Exists(f)) { Deplacer(f, ignorees); n++; } } catch { }
            if (n > 0) Noter(n + " capture" + (n > 1 ? "s" : "") + " ignorée" + (n > 1 ? "s" : "") + " (rangée" + (n > 1 ? "s" : "") + " dans captures\\ignorees)", Niveau.Info, "attente");
            SignalerAttente();
        }

        // ---- Fiches illisibles : ne garder qu'une fois la même --------------------------------------------

        /// <summary>Le nom de la ressource écrit dans le nom du fichier (« HDV_…_auto - Champignon.png »), ou null.</summary>
        public static string NomDansFichier(string f)
        {
            var m = Regex.Match(Path.GetFileNameWithoutExtension(f), @" - (.+?)(_\d+)?$");
            return m.Success ? m.Groups[1].Value : null;
        }

        static string PourFichier(string nom)
        {
            foreach (char c in Path.GetInvalidFileNameChars()) nom = nom.Replace(c, ' ');
            return nom.Trim();
        }

        static bool MemeNom(string a, string b)
        {
            if (a == null || b == null) return false;
            string x = Ecran.Normaliser(a), y = Ecran.Normaliser(b);
            return x == y || (x.Length >= 6 && Ecran.Distance(x, y) <= 1);
        }

        /// <summary>
        /// Vrai si une fiche du même nom est déjà en attente, ou a été gardée il y a moins de 30 minutes.
        /// (Comparer les images ne marche pas : toutes les fiches HDV ont la même mise en page.)
        /// Sans nom lisible, on garde toujours la capture : mieux vaut un doublon qu'une fiche perdue.
        /// </summary>
        bool DejaGardee(string nom)
        {
            if (nom == null) return false;
            lock (recentes)
            {
                recentes.RemoveAll(r => r.Key < DateTime.Now.AddMinutes(-30));
                if (recentes.Any(r => MemeNom(r.Value, nom))) return true;
            }
            var fichiers = new List<string>();
            try { fichiers.AddRange(Directory.GetFiles(enAttente, "*.png")); fichiers.AddRange(Directory.GetFiles(aTraiter, "*.png")); } catch { }
            return fichiers.Any(f => MemeNom(NomDansFichier(f), nom));
        }

        static Bitmap Recadrer(Bitmap src, RectangleF zone)
        {
            var r = Rectangle.Round(zone);
            r.Intersect(new Rectangle(0, 0, src.Width, src.Height));
            if (r.Width < 50 || r.Height < 50) return new Bitmap(src);
            return src.Clone(r, PixelFormat.Format32bppArgb);
        }

        public string DossierAttente { get { return enAttente; } }
        public string DossierCaptures { get { return Path.GetDirectoryName(aTraiter); } }
        public int NbAttente { get { try { return Directory.GetFiles(enAttente, "*.png").Length; } catch { return 0; } } }
        public List<Activite> Activites() { lock (activites) return activites.ToList(); }

        public void Demarrer()
        {
            filAnalyse = new Thread(BoucleAnalyse) { IsBackground = true, Name = "Analyse HDV" };
            filAnalyse.SetApartmentState(ApartmentState.MTA);
            filAnalyse.Start();
            filFile = new Thread(BoucleFile) { IsBackground = true, Name = "Captures HDV" };
            filFile.SetApartmentState(ApartmentState.MTA);
            filFile.Start();
        }

        public void Arreter() { arret = true; reveil.Set(); }

        void Noter(string texte, Niveau n, string source)
        {
            var a = new Activite { Texte = texte, Niveau = n, Source = source };
            lock (activites) { activites.Add(a); if (activites.Count > 500) activites.RemoveRange(0, 100); }
            try { File.AppendAllText(journal, a.T.ToString("yyyy-MM-dd HH:mm:ss") + "  [" + source + "] " + texte + "\r\n", new UTF8Encoding(false)); } catch { }
            var e = Nouvelle; if (e != null) e(a);
        }

        void SignalerEtat(string s) { var e = Etat; if (e != null) e(s); }
        void SignalerAttente() { var e = Attente; if (e != null) e(); }

        static string Deplacer(string fichier, string vers)
        {
            string cible = Path.Combine(vers, Path.GetFileName(fichier));
            if (File.Exists(cible)) cible = Path.Combine(vers, Path.GetFileNameWithoutExtension(fichier) + "_" + DateTime.Now.Ticks % 100000 + Path.GetExtension(fichier));
            File.Move(fichier, cible);
            return cible;
        }

        static string NouveauFichier(string dossier, DateTime t, string suffixe = "")
        {
            string nom = "HDV_" + t.ToString("yyyy-MM-dd_HH-mm-ss", CultureInfo.InvariantCulture) + suffixe;
            string chemin = Path.Combine(dossier, nom + ".png");
            for (int i = 2; File.Exists(chemin); i++) chemin = Path.Combine(dossier, nom + "_" + i + ".png");
            return chemin;
        }

        /// <summary>Pour la galerie : le nom de la ressource si on a pu le lire.</summary>
        public static string Titre(string f) { return NomDansFichier(f); }

        static DateTime DateFichier(string fichier)
        {
            var m = Regex.Match(Path.GetFileName(fichier), @"(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})");
            DateTime t;
            if (m.Success && DateTime.TryParseExact(m.Groups[1].Value + " " + m.Groups[2].Value + ":" + m.Groups[3].Value + ":" + m.Groups[4].Value,
                "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out t)) return t;
            return File.GetLastWriteTime(fichier);
        }

        static Bitmap Charger(string fichier)
        {
            using (var fs = new FileStream(fichier, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var img = Image.FromStream(fs))
                return new Bitmap(img);
        }

        // ---- Décision : la lecture est-elle assez sûre pour être enregistrée ? -----------------------------

        class Resolution { public bool Ok; public string Raison = ""; public Releve Releve, Avant; public bool GrosChangement; }

        static string Majuscule(string s) { return string.IsNullOrEmpty(s) ? s : char.ToUpper(s[0]) + s.Substring(1); }

        Resolution Resoudre(Fiche f, Dictionary<string, Releve> derniers, DateTime t)
        {
            var res = new Resolution();
            string cle = Ecran.Normaliser(f.Nom);
            Releve avant;
            derniers.TryGetValue(cle, out avant);
            if (avant == null && cle.Length >= 6)
            {
                // L'OCR peut se tromper d'une ou deux lettres : on rattache à la ressource déjà suivie la plus proche.
                var proches = derniers.Where(kv => Ecran.Distance(kv.Key, cle) <= 2).ToList();
                if (proches.Count == 1) avant = proches[0].Value;
            }
            string nom, cat;
            if (avant != null) { nom = avant.Nom; cat = avant.Cat; }
            else
            {
                // Ressource jamais vue : le nom doit exister sur DofusDB (qui donne aussi la bonne catégorie).
                ObjetDofus o;
                try { o = DofusDB.Chercher(f.Nom); }
                catch { res.Raison = "DofusDB ne répond pas, impossible de confirmer le nom « " + f.Nom + " »"; return res; }
                if (o == null) { res.Raison = "nom « " + f.Nom + " » non reconnu"; return res; }
                nom = o.Nom; cat = string.IsNullOrEmpty(o.Categorie) ? Majuscule(f.Categorie ?? "Autre") : o.Categorie;
            }
            var r = new Releve { T = t, Nom = nom, Cat = cat, P1 = f.P1, P10 = f.P10, P100 = f.P100, P1000 = f.P1000, Moy = f.Moy };
            // Prix moyen invraisemblable par rapport aux lots : on préfère le laisser vide.
            int dernierLot = LecteurHdv.Lots.LastOrDefault(l => r.Prix(l).HasValue);
            if (r.Moy.HasValue && dernierLot > 0)
            {
                double pu = r.ParUnite(dernierLot).Value;
                if (r.Moy.Value > 10 * pu || r.Moy.Value < pu / 10) r.Moy = null;
            }
            if (avant != null)
                foreach (int l in LecteurHdv.Lots)
                {
                    var a = avant.Prix(l); var n = r.Prix(l);
                    if (a.HasValue && n.HasValue && (n.Value > 3 * a.Value || n.Value * 3 < a.Value)) res.GrosChangement = true;
                }
            res.Ok = true; res.Releve = r; res.Avant = avant;
            return res;
        }

        public static string Variation(Releve avant, Releve r)
        {
            if (avant == null) return "nouvelle";
            foreach (int l in new[] { 100, 10, 1, 1000 })
            {
                var a = avant.Prix(l); var n = r.Prix(l);
                if (a.HasValue && n.HasValue && a.Value > 0)
                {
                    double pct = (n.Value / (double)a.Value - 1) * 100;
                    return (pct >= 0 ? "+" : "") + pct.ToString("0.0", CultureInfo.GetCultureInfo("fr-FR")) + " % sur x" + l;
                }
            }
            return "mis à jour";
        }

        void Enregistrer(Releve r, Releve avant, string source, bool ocr)
        {
            DofusDB.Icone(d, r.Nom);   // l'icône d'abord, pour que le tableau l'affiche tout de suite
            d.AjouterReleve(r);
            if (ocr) d.AjouterConso(new Conso { T = DateTime.Now, Captures = 1, Modele = "ocr" });
            Noter(r.Nom + " relevée (" + Variation(avant, r) + ")", Niveau.Ok, source);
            var s = Releve; if (s != null) s();   // la fenêtre joue la musique (pas de son Windows)
        }

        /// <summary>Un prix vient d'être enregistré (pour la musique de notification).</summary>
        public event Action Releve;

        // ---- Analyse automatique de l'écran -----------------------------------------------------------

        void BoucleAnalyse()
        {
            if (!Ocr.Initialiser()) { Noter(Ocr.Erreur, Niveau.Erreur, "OCR"); SignalerEtat(Ocr.Erreur); return; }
            int tour = 0;
            while (!arret)
            {
                var sw = Stopwatch.StartNew();
                try
                {
                    if (d.Reglages.Auto) Analyser(tour);
                    else SignalerEtat("Analyse automatique coupée · " + d.Reglages.Touche + " pour capturer une fiche");
                }
                catch (Exception ex) { Noter("Erreur pendant l'analyse : " + ex.Message, Niveau.Erreur, "auto"); }
                tour++;
                while (!arret && sw.ElapsedMilliseconds < Math.Max(1, d.Reglages.Intervalle) * 1000) Thread.Sleep(100);
            }
        }

        void Analyser(int tour)
        {
            var sw = Stopwatch.StartNew();
            var liste = Ecran.Fenetres();
            if (liste.Count == 0) { SignalerEtat("En attente de Dofus · aucune fenêtre de jeu ouverte"); return; }
            foreach (var h in fenetres.Keys.Where(h => !liste.Any(f => f.Hwnd == h)).ToList()) fenetres.Remove(h);
            // On ne lit que la fenêtre Dofus au premier plan (et celles où l'HDV était ouvert) : bien moins de travail pour le PC.
            var premier = Ecran.DofusAuPremierPlan();
            var aLire = liste.Where(f => (premier != null && f.Hwnd == premier.Hwnd) || (fenetres.ContainsKey(f.Hwnd) && fenetres[f.Hwnd].Hdv)).ToList();
            string nb = liste.Count + " fenêtre" + (liste.Count > 1 ? "s" : "") + " Dofus";
            if (aLire.Count == 0) { SignalerEtat("Analyse active · " + nb + " · en pause tant que Dofus n'est pas au premier plan"); return; }
            bool hdv = false, fiche = false;
            foreach (var f in aLire)
            {
                if (arret) return;
                SuiviFenetre s;
                if (!fenetres.TryGetValue(f.Hwnd, out s)) { s = new SuiviFenetre(); fenetres[f.Hwnd] = s; }
                using (var bmp = Ecran.Capturer(f.Hwnd))
                {
                    if (bmp == null) continue;
                    // Quand l'HDV est ouvert sans fiche lisible, on relit de temps en temps l'image agrandie.
                    var lu = LecteurHdv.Lire(bmp, s.Hdv && tour % 3 == 0);
                    s.Hdv = lu.HdvOuvert || lu.Visible;
                    hdv |= s.Hdv;
                    fiche |= lu.Visible;
                    if (lu.Ok) { s.Illisible = 0; s.Gardee = false; Confirmer(f, s, lu); }
                    else if (lu.Visible)
                    {
                        s.Cle = null;
                        // Fiche à l'écran mais illisible plusieurs fois de suite : on garde la zone de la fiche pour Claude
                        // (ou en attente), sauf si la même fiche a déjà été gardée.
                        if (++s.Illisible >= 3 && !s.Gardee)
                        {
                            s.Gardee = true;
                            using (var zoneFiche = Recadrer(bmp, RectangleF.Inflate(lu.Zone, 4, 4)))
                            {
                                string laFiche = lu.Nom != null ? "« " + lu.Nom + " »" : "Fiche";
                                if (DejaGardee(lu.Nom))
                                    Noter(laFiche + " illisible, mais déjà gardée : pas de deuxième capture", Niveau.Info, "auto");
                                else
                                {
                                    string chemin = NouveauFichier(aTraiter, DateTime.Now, "_auto" + (lu.Nom != null ? " - " + PourFichier(lu.Nom) : ""));
                                    zoneFiche.Save(chemin, ImageFormat.Png);
                                    if (lu.Nom != null) lock (recentes) recentes.Add(new KeyValuePair<DateTime, string>(DateTime.Now, lu.Nom));
                                    Noter(laFiche + " illisible pour l'OCR (" + lu.Raison + ") : capture gardée", Niveau.Alerte, "auto");
                                    reveil.Set();
                                }
                            }
                        }
                    }
                    else { s.Cle = null; s.Illisible = 0; s.Gardee = false; }
                }
            }
            string quoi = fiche ? "fiche HDV visible" : hdv ? "HDV ouvert, clique sur une ressource" : "ouvre l'HDV dans Dofus";
            SignalerEtat("Analyse active · " + nb + " · " + quoi + " · " + sw.ElapsedMilliseconds + " ms");
        }

        void Confirmer(FenetreDofus f, SuiviFenetre s, Fiche lu)
        {
            if (lu.Cle == s.Cle) s.Vu++; else { s.Cle = lu.Cle; s.Vu = 1; s.Signale = null; }
            if (s.Vu < 2) return;   // une fiche n'est prise en compte que lue deux fois pareil de suite

            var derniers = d.Derniers();
            var res = Resoudre(lu, derniers, DateTime.Now);
            if (!res.Ok)
            {
                if (s.Signale != s.Cle) { s.Signale = s.Cle; Noter(res.Raison + " : rien enregistré", Niveau.Alerte, "auto"); }
                return;
            }
            var a = res.Avant;
            // Déjà relevée il y a peu avec les mêmes prix : rien à faire.
            if (a != null && a.ClePrix == res.Releve.ClePrix && (DateTime.Now - a.T).TotalMinutes < d.Reglages.ReReleve) return;
            // Prix qui change énormément : on attend de l'avoir lu quatre fois pareil pour être sûr.
            if (res.GrosChangement && s.Vu < 4) return;
            if (res.GrosChangement) Noter(res.Releve.Nom + " : prix très différent du dernier relevé, vérifie-le", Niveau.Alerte, "auto");
            Enregistrer(res.Releve, a, "auto", true);
        }

        // ---- Captures (F9 et fiches gardées) ------------------------------------------------------------

        /// <summary>Capture la fenêtre au premier plan (touche F9) et la met dans la file.</summary>
        public void CaptureF9()
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    using (var bmp = Ecran.CapturerPremierPlan())
                    {
                        string f = NouveauFichier(aTraiter, DateTime.Now);
                        bmp.Save(f, ImageFormat.Png);
                    }
                    Noter("Capture enregistrée", Niveau.Info, d.Reglages.Touche);
                    reveil.Set();
                }
                catch (Exception ex) { Noter("Capture impossible : " + ex.Message, Niveau.Erreur, d.Reglages.Touche); }
            });
        }

        /// <summary>Notification Windows à montrer : titre et texte.</summary>
        public event Action<string, string> Notification;
        void Notifier(string titre, string texte) { var n = Notification; if (n != null) n(titre, texte); }

        // Les captures en attente sont réessayées toutes les 2 secondes.
        DateTime prochainReessai = DateTime.Now.AddSeconds(2);
        public static readonly TimeSpan IntervalleReessai = TimeSpan.FromSeconds(2);
        public DateTime ProchainReessai { get { return prochainReessai; } }

        // La même image redonne toujours la même lecture OCR : on la garde (par fichier) au lieu de refaire l'OCR
        // toutes les 2 secondes. Ce qui peut changer d'un essai à l'autre, c'est la reconnaissance du nom (une
        // ressource ajoutée entre-temps, DofusDB qui répond de nouveau) : ça, on le refait à chaque fois.
        readonly Dictionary<string, Fiche> lectures = new Dictionary<string, Fiche>(StringComparer.OrdinalIgnoreCase);
        DateTime dofusDbPauseJusqua = DateTime.MinValue;   // après une panne de DofusDB, on attend un peu avant de redemander

        void BoucleFile()
        {
            Ocr.Initialiser();
            while (!arret)
            {
                reveil.WaitOne(1000);
                if (arret) return;
                try
                {
                    TraiterFile();
                    // Claude ne lit que ce que l'utilisateur a choisi dans les captures en attente.
                    List<string> choisies;
                    lock (demandesClaude) { choisies = demandesClaude.Where(File.Exists).ToList(); demandesClaude.Clear(); }
                    for (int i = 0; i < choisies.Count; i += 8) RelireAvecClaude(choisies.Skip(i).Take(8).ToList());
                    if (DateTime.Now >= prochainReessai) { prochainReessai = DateTime.Now + IntervalleReessai; ReessayerAttente(); }
                }
                catch (Exception ex) { Noter("Erreur pendant le traitement des captures : " + ex.Message, Niveau.Erreur, "captures"); }
            }
        }

        /// <summary>
        /// Relit chaque capture en attente avec l'OCR, sans rien signaler si elle reste illisible.
        /// Celles qui passent sont enregistrées, avec une notification.
        /// </summary>
        void ReessayerAttente()
        {
            if (ClaudeOccupe) return;
            List<string> reservees;
            lock (demandesClaude) reservees = demandesClaude.ToList();
            var lues = new List<string>();
            var attente = ListeAttente();
            foreach (var k in lectures.Keys.Where(k => !attente.Contains(k, StringComparer.OrdinalIgnoreCase)).ToList()) lectures.Remove(k);
            foreach (string f in attente)
            {
                if (arret) return;
                if (reservees.Contains(f, StringComparer.OrdinalIgnoreCase)) continue;
                try
                {
                    Fiche lu;
                    if (!lectures.TryGetValue(f, out lu))
                    {
                        using (var bmp = Charger(f)) lu = LecteurHdv.Lire(bmp, true);   // l'OCR, une seule fois par image
                        lectures[f] = lu;
                    }
                    if (!lu.Ok) continue;
                    if (DateTime.Now < dofusDbPauseJusqua) continue;
                    var res = Resoudre(lu, d.Derniers(), DateFichier(f));
                    if (!res.Ok)
                    {
                        if (res.Raison.StartsWith("DofusDB")) dofusDbPauseJusqua = DateTime.Now.AddSeconds(30);
                        continue;
                    }
                    lectures.Remove(f);
                    Deplacer(f, traitees);
                    if (res.GrosChangement) Noter(res.Releve.Nom + " : prix très différent du dernier relevé, vérifie-le", Niveau.Alerte, "réessai OCR");
                    Enregistrer(res.Releve, res.Avant, "réessai OCR", true);
                    lues.Add(res.Releve.Nom);
                }
                catch { }
            }
            if (lues.Count == 0) return;
            SignalerAttente();
            Notifier(lues.Count == 1 ? "Capture en attente lue" : lues.Count + " captures en attente lues",
                "L'OCR a fini par lire : " + string.Join(", ", lues) + ".");
        }

        void TraiterFile()
        {
            var fichiers = Directory.GetFiles(aTraiter, "*.png").Where(f => File.GetLastWriteTime(f) < DateTime.Now.AddSeconds(-1)).OrderBy(f => f).ToList();
            if (fichiers.Count == 0) return;
            var lues = new List<string>();
            foreach (string f in fichiers)
            {
                if (arret) return;
                string source = Path.GetFileName(f).Contains("_auto") ? "auto" : d.Reglages.Touche;
                bool reessai;   // renvoyée depuis les captures en attente (bouton « Réessayer avec l'OCR »)
                lock (ocrSeulement) reessai = ocrSeulement.Remove(Path.GetFileName(f));
                if (reessai) source = "réessai OCR";
                string raison;
                using (var bmp = Charger(f))
                {
                    var lu = LecteurHdv.Lire(bmp, true);
                    if (lu.Ok)
                    {
                        var res = Resoudre(lu, d.Derniers(), DateFichier(f));
                        if (res.Ok)
                        {
                            bmp.Dispose();
                            Deplacer(f, traitees);
                            if (res.GrosChangement) Noter(res.Releve.Nom + " : prix très différent du dernier relevé, vérifie-le", Niveau.Alerte, source);
                            if (lu.Relu > 0) Noter(res.Releve.Nom + " : " + lu.Relu + " case" + (lu.Relu > 1 ? "s" : "") + " relue" + (lu.Relu > 1 ? "s" : "") + " autrement (chiffre isolé)", Niveau.Info, source);
                            Enregistrer(res.Releve, res.Avant, source + (reessai ? "" : " · OCR"), true);
                            if (reessai) lues.Add(res.Releve.Nom);
                            continue;
                        }
                        raison = res.Raison;
                    }
                    else raison = lu.Raison;
                }
                // Tout ce que l'OCR ne lit pas va en attente : il sera réessayé tout seul, et Claude ne le lira que sur demande.
                Deplacer(f, enAttente);
                Noter("OCR pas sûr (" + raison + ") : capture " + (reessai ? "remise" : "mise") + " en attente (réessayée automatiquement)", Niveau.Alerte, source);
                SignalerAttente();
            }
            if (lues.Count > 0)
                Notifier(lues.Count == 1 ? "Capture en attente lue" : lues.Count + " captures en attente lues", "L'OCR a fini par lire : " + string.Join(", ", lues) + ".");
        }

        void RelireAvecClaude(List<string> fichiers)
        {
            if (fichiers.Count == 0) return;
            ClaudeOccupe = true;
            SignalerAttente();
            try
            {
                var derniers = d.Derniers();
                string connus = string.Join("; ", derniers.Values.OrderBy(r => r.Nom).Select(r => r.Nom + " → " + r.Cat));
                Noter("Claude relit " + fichiers.Count + " capture" + (fichiers.Count > 1 ? "s" : "") + "…", Niveau.Info, "Claude");
                Conso conso;
                List<CaptureLue> lues;
                try { lues = Claude.Relire(fichiers, connus, d.Reglages.Modele, Path.GetDirectoryName(DossierCaptures), out conso); }
                catch (Exception ex)
                {
                    foreach (string f in fichiers) if (File.Exists(f) && Path.GetDirectoryName(f) != enAttente) Deplacer(f, enAttente);
                    Noter(ex.Message + " Les captures sont en attente.", Niveau.Erreur, "Claude");
                    return;
                }
                if (conso != null) { d.AjouterConso(conso); Noter(conso.Total.ToString("N0", CultureInfo.GetCultureInfo("fr-FR")) + " tokens utilisés", Niveau.Info, "Claude"); }
                foreach (string f in fichiers)
                {
                    var c = lues.FirstOrDefault(x => string.Equals(x.Fichier, Path.GetFileName(f), StringComparison.OrdinalIgnoreCase));
                    if (c == null || !c.Lisible || c.Ressources.Count == 0)
                    {
                        Deplacer(f, aVerifier);
                        Noter(Path.GetFileName(f) + " mise de côté dans a_verifier (" + (c != null && c.Remarque != "" ? c.Remarque : "aucun prix lisible") + ")", Niveau.Alerte, "Claude");
                        continue;
                    }
                    DateTime t = DateFichier(f);
                    foreach (var r in c.Ressources)
                    {
                        if (r.Nom == "" || LecteurHdv.Lots.All(l => !r.Prix(l).HasValue)) continue;
                        Releve avant;
                        derniers.TryGetValue(Ecran.Normaliser(r.Nom), out avant);
                        if (avant != null) { r.Nom = avant.Nom; if (r.Cat == "") r.Cat = avant.Cat; }
                        if (r.Cat == "") r.Cat = "Autre";
                        r.T = t;
                        Enregistrer(r, avant, "Claude", false);
                        derniers[Ecran.Normaliser(r.Nom)] = r;
                    }
                    if (c.Remarque != "") Noter(Path.GetFileName(f) + " : " + c.Remarque, Niveau.Info, "Claude");
                    Deplacer(f, traitees);
                }
            }
            finally { ClaudeOccupe = false; SignalerAttente(); }
        }
    }
}
