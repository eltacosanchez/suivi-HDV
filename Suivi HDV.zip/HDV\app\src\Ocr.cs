using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace SuiviHDV
{
    public class MotOcr
    {
        public string T;
        public double X, Y, L, H;
        public double CentreY { get { return Y + H / 2; } }
        public double Fin { get { return X + L; } }
    }

    public class LigneOcr
    {
        public string Texte;
        public double X, Y, L, H;
        public List<MotOcr> Mots = new List<MotOcr>();
        public double CentreY { get { return Y + H / 2; } }
        public override string ToString() { return string.Format("[{0}] x={1:0} y={2:0} l={3:0} h={4:0}", Texte, X, Y, L, H); }
    }

    /// <summary>
    /// Reconnaissance de texte intégrée à Windows (Windows.Media.Ocr), gratuite et sans internet — même méthode
    /// que le Compteur XP. Les types WinRT sont chargés par réflexion : le code se compile sans les fichiers .winmd.
    /// </summary>
    public static class Ocr
    {
        static object moteur;
        static MethodInfo reconnaitre, versTache, versTampon, copier;
        static PropertyInfo pLignes, pTexteLigne, pMots, pTexteMot, pCadre, pResultat;
        static object formatBgra;
        static readonly object verrou = new object();

        public static string Erreur { get; private set; }

        static Type WinRT(string nom)
        {
            return Type.GetType(nom + ", Windows.Foundation, ContentType=WindowsRuntime", true);
        }

        public static bool Initialiser()
        {
            lock (verrou)
            {
                if (moteur != null) return true;
                try
                {
                    Type tMoteur = WinRT("Windows.Media.Ocr.OcrEngine");
                    Type tLangue = WinRT("Windows.Globalization.Language");
                    Type tImage = WinRT("Windows.Graphics.Imaging.SoftwareBitmap");
                    Type tFormat = WinRT("Windows.Graphics.Imaging.BitmapPixelFormat");
                    Type tResultat = WinRT("Windows.Media.Ocr.OcrResult");
                    Type tLigne = WinRT("Windows.Media.Ocr.OcrLine");
                    Type tMot = WinRT("Windows.Media.Ocr.OcrWord");

                    var langue = Activator.CreateInstance(tLangue, "fr-FR");
                    moteur = tMoteur.GetMethod("TryCreateFromLanguage").Invoke(null, new[] { langue });
                    if (moteur == null) moteur = tMoteur.GetMethod("TryCreateFromUserProfileLanguages").Invoke(null, null);
                    if (moteur == null)
                    {
                        Erreur = "La reconnaissance de texte de Windows n'est pas disponible. Ajoute la langue Français dans Paramètres > Heure et langue > Langue.";
                        return false;
                    }

                    var wrt = Assembly.Load("System.Runtime.WindowsRuntime, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089");
                    versTampon = wrt.GetType("System.Runtime.InteropServices.WindowsRuntime.WindowsRuntimeBufferExtensions")
                        .GetMethod("AsBuffer", new[] { typeof(byte[]) });
                    versTache = wrt.GetType("System.WindowsRuntimeSystemExtensions").GetMethods()
                        .First(m => m.Name == "AsTask" && m.GetParameters().Length == 1 && m.GetParameters()[0].ParameterType.Name == "IAsyncOperation`1")
                        .MakeGenericMethod(tResultat);
                    copier = tImage.GetMethod("CreateCopyFromBuffer", new[] { versTampon.ReturnType, tFormat, typeof(int), typeof(int) });
                    formatBgra = Enum.Parse(tFormat, "Bgra8");
                    reconnaitre = tMoteur.GetMethod("RecognizeAsync");
                    pLignes = tResultat.GetProperty("Lines");
                    pTexteLigne = tLigne.GetProperty("Text");
                    pMots = tLigne.GetProperty("Words");
                    pTexteMot = tMot.GetProperty("Text");
                    pCadre = tMot.GetProperty("BoundingRect");
                    pResultat = typeof(Task<>).MakeGenericType(tResultat).GetProperty("Result");
                    return true;
                }
                catch (Exception e)
                {
                    moteur = null;
                    Erreur = "Impossible de démarrer la reconnaissance de texte : " + (e.InnerException ?? e).Message;
                    return false;
                }
            }
        }

        /// <summary>Lit le texte de l'image, mot par mot. Les positions sont ramenées à l'image d'origine (échelle).</summary>
        public static List<LigneOcr> Lire(Bitmap bmp, double echelle = 1)
        {
            var res = new List<LigneOcr>();
            if (!Initialiser()) return res;
            // L'OCR de Windows refuse les images de plus de 10 000 pixels de côté.
            if (bmp.Width > 9999 || bmp.Height > 9999) return res;
            object tampon = versTampon.Invoke(null, new object[] { Pixels(bmp) });
            object image = copier.Invoke(null, new[] { tampon, formatBgra, bmp.Width, bmp.Height });
            try
            {
                object resultat;
                lock (verrou)
                {
                    var tache = (Task)versTache.Invoke(null, new[] { reconnaitre.Invoke(moteur, new[] { image }) });
                    tache.Wait();
                    resultat = pResultat.GetValue(tache);
                }
                foreach (object ligne in (IEnumerable)pLignes.GetValue(resultat))
                {
                    var l = new LigneOcr { Texte = (string)pTexteLigne.GetValue(ligne) };
                    double x1 = double.MaxValue, y1 = double.MaxValue, x2 = 0, y2 = 0;
                    foreach (object mot in (IEnumerable)pMots.GetValue(ligne))
                    {
                        object r = pCadre.GetValue(mot);
                        Type t = r.GetType();
                        double x = Convert.ToDouble(t.GetProperty("X").GetValue(r)) / echelle, y = Convert.ToDouble(t.GetProperty("Y").GetValue(r)) / echelle;
                        double w = Convert.ToDouble(t.GetProperty("Width").GetValue(r)) / echelle, h = Convert.ToDouble(t.GetProperty("Height").GetValue(r)) / echelle;
                        l.Mots.Add(new MotOcr { T = (string)pTexteMot.GetValue(mot), X = x, Y = y, L = w, H = h });
                        x1 = Math.Min(x1, x); y1 = Math.Min(y1, y); x2 = Math.Max(x2, x + w); y2 = Math.Max(y2, y + h);
                    }
                    if (x1 == double.MaxValue) continue;
                    l.X = x1; l.Y = y1; l.L = x2 - x1; l.H = y2 - y1;
                    res.Add(l);
                }
            }
            finally
            {
                var d = image as IDisposable;
                if (d != null) d.Dispose();
            }
            return res;
        }

        // Pixels BGRA bruts, pour créer l'image de l'OCR sans passer par un fichier.
        static byte[] Pixels(Bitmap b)
        {
            var d = b.LockBits(new Rectangle(0, 0, b.Width, b.Height), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                var octets = new byte[b.Width * b.Height * 4];
                for (int y = 0; y < b.Height; y++)
                    Marshal.Copy(d.Scan0 + y * d.Stride, octets, y * b.Width * 4, b.Width * 4);
                return octets;
            }
            finally { b.UnlockBits(d); }
        }
    }
}
