using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

namespace SuiviHDV
{
    /// <summary>Un relevé de prix d'une ressource à un moment donné.</summary>
    public class Releve
    {
        public DateTime T;
        public string Nom = "", Cat = "";
        public long? P1, P10, P100, P1000, Moy;
        public long[] Offres;   // équipement : les 5 offres les moins chères à l'unité (P1 = la première) ; null pour une ressource
        public string Serveur;  // serveur de jeu du relevé
        public string Ligne;    // la ligne du fichier prix.js (pour pouvoir supprimer un relevé faux)

        public long? Prix(int lot)
        {
            switch (lot) { case 1: return P1; case 10: return P10; case 100: return P100; case 1000: return P1000; }
            return null;
        }

        /// <summary>Prix par unité du lot donné (null si ce lot n'a pas de prix).</summary>
        public double? ParUnite(int lot)
        {
            var p = Prix(lot);
            return p.HasValue ? p.Value / (double)lot : (double?)null;
        }

        public string ClePrix { get { return P1 + "|" + P10 + "|" + P100 + "|" + P1000 + "|" + Moy + (Offres != null ? "|" + string.Join(",", Offres) : ""); } }
    }

    /// <summary>Une ressource suivie et tous ses relevés, du plus ancien au plus récent.</summary>
    public class Ressource
    {
        public string Cle, Nom, Cat, Icone;
        public List<Releve> Releves = new List<Releve>();
        public Releve Dernier { get { return Releves[Releves.Count - 1]; } }
    }

    /// <summary>Consommation d'un passage : tokens de Claude, ou captures lues gratuitement par l'OCR.</summary>
    public class Conso
    {
        public DateTime T;
        public int Captures;
        public long Entree, CacheEcrit, CacheLu, Sortie;
        public double Usd;
        public string Modele = "";
        public bool EstOcr { get { return Modele == "ocr"; } }
        public long Total { get { return Entree + CacheEcrit + CacheLu + Sortie; } }
    }

    /// <summary>Un achat (kamas dépensés) ou une vente (kamas gagnés) à l'HDV, lu dans le chat.</summary>
    public class Achat
    {
        public DateTime T;
        public string Nom = "";
        public long Quantite, Prix;
        public bool Vente;     // vrai : une vente (gain) ; faux : un achat (dépense)
        public string Ligne;   // la ligne du fichier achats.js (pour pouvoir la supprimer)
        public string Serveur; // serveur de jeu de l'achat
        public double ParUnite { get { return Quantite > 0 ? Prix / (double)Quantite : 0; } }
        /// <summary>Même sens, même ressource, même quantité, même prix (sans l'heure).</summary>
        public string Cle { get { return (Vente ? "V|" : "A|") + Ecran.Normaliser(Nom) + "|" + Quantite + "|" + Prix; } }
    }

    public class Reglages
    {
        public bool Auto = true;            // analyse automatique de l'écran
        public bool Claude;                 // (ancien réglage, plus utilisé : Claude ne lit que sur demande)
        public bool Notifs = true;          // musique à chaque prix relevé
        public int Volume = 2;              // volume de la musique, en %
        public string Modele = "sonnet";
        public string Touche = "F9";
        public int Intervalle = 2;          // secondes entre deux analyses
        public int ReReleve = 30;           // minutes avant de relever à nouveau une ressource inchangée
        public int Lot = 100;               // lot de référence pour les variations
        public int Periode = 30;            // jours (0 = tout)
        public bool Son = true;
        public bool Grouper = true;
        public bool Epingle;
        public int FenX = int.MinValue, FenY, FenL, FenH;
        public int CalcX = int.MinValue, CalcY, CalcL, CalcH;   // fenêtre du calculateur de recette
        public List<string> Serveurs = new List<string>();   // serveurs de jeu (onglets) ; les anciens relevés sont au premier
        public string Serveur = "";                          // serveur choisi : seuls ses relevés et achats sont montrés
        public string Tri = "nom";                           // colonne de tri du tableau des prix, gardée d'une fois sur l'autre
        public int Sens = 1;
    }

    /// <summary>
    /// Données de l'HDV, dans les mêmes fichiers que la page web (donnees\prix.js, tokens.js, icones.js) :
    /// une ligne par relevé, faciles à lire et à corriger à la main.
    /// </summary>
    public class Donnees
    {
        public readonly string Dossier;
        readonly string fPrix, fTokens, fIcones, fReglages, fAchats;
        static readonly UTF8Encoding Utf8 = new UTF8Encoding(false);
        readonly object verrou = new object();

        readonly List<Releve> releves = new List<Releve>();
        readonly List<Achat> achats = new List<Achat>();
        readonly List<Conso> consos = new List<Conso>();
        readonly Dictionary<string, string> icones = new Dictionary<string, string>();   // nom normalisé -> chemin de l'image (ou "" si introuvable)
        public Reglages Reglages = new Reglages();
        public event Action Change;

        static readonly Regex rxChaine = new Regex(@"\b(\w+)\s*:\s*""((?:[^""\\]|\\.)*)""");
        static readonly Regex rxNombre = new Regex(@"\b(\w+)\s*:\s*(-?\d+(?:\.\d+)?|null)\b");
        static readonly Regex rxIcone = new Regex(@"^\s*I\(\s*""((?:[^""\\]|\\.)*)""\s*,\s*(null|""((?:[^""\\]|\\.)*)"")\s*\)");

        public Donnees(string dossierHdv)
        {
            Dossier = Path.Combine(dossierHdv, "donnees");
            Directory.CreateDirectory(Dossier);
            Directory.CreateDirectory(Path.Combine(Dossier, "icones"));
            fPrix = Path.Combine(Dossier, "prix.js");
            fTokens = Path.Combine(Dossier, "tokens.js");
            fIcones = Path.Combine(Dossier, "icones.js");
            fReglages = Path.Combine(Dossier, "reglages.json");
            fAchats = Path.Combine(Dossier, "achats.js");
            Charger();
            Sauvegarder();
        }

        // ---- Lecture ------------------------------------------------------------------------------

        static string Deseq(string s) { return Regex.Replace(s, @"\\(.)", "$1"); }
        static string Js(string s) { return "\"" + (s ?? "").Trim().Replace("\\", "\\\\").Replace("\"", "\\\"") + "\""; }
        static string Js(long? v) { return v.HasValue ? v.Value.ToString(CultureInfo.InvariantCulture) : "null"; }

        static DateTime Date(string s)
        {
            DateTime d;
            if (DateTime.TryParseExact(s, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) return d;
            if (DateTime.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out d)) return d.AddHours(12);
            return DateTime.MinValue;
        }

        static Dictionary<string, string> Champs(string ligne)
        {
            var c = new Dictionary<string, string>();
            foreach (Match m in rxChaine.Matches(ligne)) c[m.Groups[1].Value] = Deseq(m.Groups[2].Value);
            foreach (Match m in rxNombre.Matches(ligne)) if (!c.ContainsKey(m.Groups[1].Value)) c[m.Groups[1].Value] = m.Groups[2].Value;
            return c;
        }

        static long? L(Dictionary<string, string> c, string k)
        {
            string v; long n;
            if (!c.TryGetValue(k, out v) || v == "null") return null;
            if (!long.TryParse(v.Split('.')[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out n) || n <= 0) return null;
            return n;
        }

        static IEnumerable<string> Lignes(string f)
        {
            return File.Exists(f) ? File.ReadAllLines(f, Encoding.UTF8) : new string[0];
        }

        public void Charger()
        {
            lock (verrou)
            {
                releves.Clear(); consos.Clear(); icones.Clear();
                foreach (string l in Lignes(fPrix))
                {
                    if (!Regex.IsMatch(l, @"^\s*R\(")) continue;
                    var c = Champs(l);
                    string d, n, cat;
                    if (!c.TryGetValue("d", out d) || !c.TryGetValue("n", out n) || n.Trim() == "") continue;
                    var t = Date(d);
                    if (t == DateTime.MinValue) continue;
                    c.TryGetValue("c", out cat);
                    string o; long[] offres = null;
                    if (c.TryGetValue("o", out o))
                    {
                        long v;
                        offres = o.Split(' ').Where(x => long.TryParse(x, out v)).Select(long.Parse).ToArray();
                        if (offres.Length == 0) offres = null;
                    }
                    releves.Add(new Releve { T = t, Nom = n.Trim(), Cat = (cat ?? "").Trim(), P1 = L(c, "p1"), P10 = L(c, "p10"), P100 = L(c, "p100"), P1000 = L(c, "p1000"), Moy = L(c, "moy"), Offres = offres, Serveur = S(c), Ligne = l });
                }
                foreach (string l in Lignes(fTokens))
                {
                    if (!Regex.IsMatch(l, @"^\s*T\(")) continue;
                    var c = Champs(l);
                    string d, mod, usd;
                    if (!c.TryGetValue("d", out d)) continue;
                    c.TryGetValue("modele", out mod);
                    double u = 0;
                    if (c.TryGetValue("usd", out usd)) double.TryParse(usd, NumberStyles.Float, CultureInfo.InvariantCulture, out u);
                    consos.Add(new Conso
                    {
                        T = Date(d), Captures = (int)(L(c, "captures") ?? 0), Entree = L(c, "entree") ?? 0, CacheEcrit = L(c, "cacheEcrit") ?? 0,
                        CacheLu = L(c, "cacheLu") ?? 0, Sortie = L(c, "sortie") ?? 0, Usd = u, Modele = mod ?? ""
                    });
                }
                achats.Clear();
                foreach (string l in Lignes(fAchats))
                {
                    bool vente = Regex.IsMatch(l, @"^\s*V\(");
                    if (!vente && !Regex.IsMatch(l, @"^\s*A\(")) continue;
                    var c = Champs(l);
                    string d, n;
                    if (!c.TryGetValue("d", out d) || !c.TryGetValue("n", out n)) continue;
                    var t = Date(d);
                    long? q = L(c, "q"), k = L(c, "k");
                    if (t == DateTime.MinValue || q == null || k == null) continue;
                    achats.Add(new Achat { T = t, Nom = n.Trim(), Quantite = q.Value, Prix = k.Value, Vente = vente, Ligne = l, Serveur = S(c) });
                }
                foreach (string l in Lignes(fIcones))
                {
                    var m = rxIcone.Match(l);
                    if (!m.Success) continue;
                    string chemin = m.Groups[3].Success ? Path.Combine(Dossier, Deseq(m.Groups[3].Value).Replace('/', '\\')) : "";
                    icones[Ecran.Normaliser(Deseq(m.Groups[1].Value))] = chemin;
                }
                try
                {
                    if (File.Exists(fReglages))
                        Reglages = new JavaScriptSerializer().Deserialize<Reglages>(File.ReadAllText(fReglages, Encoding.UTF8)) ?? new Reglages();
                }
                catch { Reglages = new Reglages(); }
                // Serveurs : il y en a toujours au moins un, et ce qui a été relevé avant les onglets est au premier.
                if (Reglages.Serveurs == null) Reglages.Serveurs = new List<string>();
                if (Reglages.Serveurs.Count == 0) Reglages.Serveurs.Add("Serveur 1");
                if (!Reglages.Serveurs.Contains(Reglages.Serveur)) Reglages.Serveur = Reglages.Serveurs[0];
                foreach (var r in releves) if (!Reglages.Serveurs.Contains(r.Serveur)) r.Serveur = Reglages.Serveurs[0];
                foreach (var a in achats) if (!Reglages.Serveurs.Contains(a.Serveur)) a.Serveur = Reglages.Serveurs[0];
            }
        }

        // Le serveur écrit sur la ligne (champ s), ou null pour une ligne d'avant les onglets de serveurs.
        static string S(Dictionary<string, string> c) { string s; return c.TryGetValue("s", out s) ? s.Trim() : null; }

        // ---- Serveurs -----------------------------------------------------------------------------

        public void ChoisirServeur(string nom)
        {
            lock (verrou) { if (!Reglages.Serveurs.Contains(nom) || Reglages.Serveur == nom) return; Reglages.Serveur = nom; }
            SauverReglages();
            Signaler();
        }

        /// <summary>Ajoute un serveur et le choisit. Faux si le nom est vide ou déjà pris.</summary>
        public bool AjouterServeur(string nom)
        {
            nom = (nom ?? "").Trim();
            lock (verrou)
            {
                if (nom == "" || Reglages.Serveurs.Contains(nom)) return false;
                Reglages.Serveurs.Add(nom);
                Reglages.Serveur = nom;
            }
            SauverReglages();
            Signaler();
            return true;
        }

        /// <summary>Renomme le serveur choisi, dans les réglages et sur les lignes des fichiers. Faux si le nom est vide ou déjà pris.</summary>
        public bool RenommerServeur(string nouveau)
        {
            nouveau = (nouveau ?? "").Trim();
            lock (verrou)
            {
                string ancien = Reglages.Serveur;
                if (nouveau == "" || Reglages.Serveurs.Contains(nouveau)) return false;
                string avant = ", s: " + Js(ancien) + "});", apres = ", s: " + Js(nouveau) + "});";
                foreach (string f in new[] { fPrix, fAchats })
                    if (File.Exists(f)) File.WriteAllText(f, File.ReadAllText(f, Encoding.UTF8).Replace(avant, apres), Utf8);
                foreach (var r in releves) if (r.Serveur == ancien) { r.Serveur = nouveau; if (r.Ligne != null) r.Ligne = r.Ligne.Replace(avant, apres); }
                foreach (var a in achats) if (a.Serveur == ancien) { a.Serveur = nouveau; if (a.Ligne != null) a.Ligne = a.Ligne.Replace(avant, apres); }
                Reglages.Serveurs[Reglages.Serveurs.IndexOf(ancien)] = nouveau;
                Reglages.Serveur = nouveau;
            }
            SauverReglages();
            Signaler();
            return true;
        }

        // ---- Requêtes -----------------------------------------------------------------------------

        public List<Ressource> Ressources()
        {
            lock (verrou)
            {
                var res = new Dictionary<string, Ressource>();
                foreach (var r in releves.Where(x => x.Serveur == Reglages.Serveur).OrderBy(x => x.T))
                {
                    string cle = Ecran.Normaliser(r.Nom);
                    Ressource x;
                    if (!res.TryGetValue(cle, out x)) { x = new Ressource { Cle = cle, Nom = r.Nom }; res[cle] = x; }
                    x.Releves.Add(r);
                    if (r.Cat != "") x.Cat = r.Cat;
                }
                foreach (var x in res.Values)
                {
                    if (string.IsNullOrEmpty(x.Cat)) x.Cat = "Autre";
                    string ic;
                    if (icones.TryGetValue(x.Cle, out ic) && ic != "" && File.Exists(ic)) x.Icone = ic;
                }
                return res.Values.ToList();
            }
        }

        /// <summary>Dernier relevé de chaque ressource, par nom normalisé.</summary>
        public Dictionary<string, Releve> Derniers()
        {
            lock (verrou)
            {
                var d = new Dictionary<string, Releve>();
                foreach (var r in releves.Where(x => x.Serveur == Reglages.Serveur).OrderBy(x => x.T)) d[Ecran.Normaliser(r.Nom)] = r;
                return d;
            }
        }

        public List<Conso> Consos() { lock (verrou) return consos.ToList(); }
        public List<Achat> Achats() { lock (verrou) return achats.Where(a => a.Serveur == Reglages.Serveur).ToList(); }

        /// <summary>Icône d'une ressource (chemin du fichier), ou null.</summary>
        public string IconeDe(string nom)
        {
            lock (verrou)
            {
                string ic;
                return icones.TryGetValue(Ecran.Normaliser(nom), out ic) && ic != "" && File.Exists(ic) ? ic : null;
            }
        }
        public int NbReleves { get { lock (verrou) return releves.Count(r => r.Serveur == Reglages.Serveur); } }
        public bool AIcone(string nom) { lock (verrou) return icones.ContainsKey(Ecran.Normaliser(nom)); }

        // ---- Écriture -----------------------------------------------------------------------------

        void Ajouter(string fichier, string ligne, string entete)
        {
            if (!File.Exists(fichier)) File.WriteAllText(fichier, entete + "\r\n", Utf8);
            string existant = File.ReadAllText(fichier, Encoding.UTF8);
            string prefixe = existant.Length > 0 && !existant.EndsWith("\n") ? "\r\n" : "";
            File.AppendAllText(fichier, prefixe + ligne + "\r\n", Utf8);
        }

        void Signaler() { var c = Change; if (c != null) c(); }

        public void AjouterReleve(Releve r)
        {
            string ligne = "R({d: \"" + r.T.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) + "\", n: " + Js(r.Nom) + ", c: " + Js(r.Cat) +
                ", p1: " + Js(r.P1) + ", p10: " + Js(r.P10) + ", p100: " + Js(r.P100) + ", p1000: " + Js(r.P1000) + ", moy: " + Js(r.Moy) +
                (r.Offres != null ? ", o: \"" + string.Join(" ", r.Offres) + "\"" : "") + ", s: " + Js(r.Serveur = Reglages.Serveur) + "});";
            lock (verrou)
            {
                r.Ligne = ligne;
                Ajouter(fPrix, ligne, "// Relevés de l'HDV — une ligne par ressource relevée (rempli par l'appli Suivi HDV).");
                releves.Add(r);
            }
            Signaler();
        }

        public void AjouterConso(Conso c)
        {
            string ligne = "T({d: \"" + c.T.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) + "\", captures: " + c.Captures +
                ", entree: " + c.Entree + ", cacheEcrit: " + c.CacheEcrit + ", cacheLu: " + c.CacheLu + ", sortie: " + c.Sortie +
                ", usd: " + c.Usd.ToString("0.####", CultureInfo.InvariantCulture) + ", modele: " + Js(c.Modele) + "});";
            lock (verrou)
            {
                Ajouter(fTokens, ligne, "// Tokens consommés par chaque lecture des captures (rempli par l'appli Suivi HDV).");
                consos.Add(c);
            }
            Signaler();
        }

        /// <summary>Note l'icône d'une ressource (chemin relatif à donnees, ou null si elle n'existe pas sur DofusDB).</summary>
        public void AjouterIcone(string nom, string cheminRelatif)
        {
            string ligne = "I(" + Js(nom) + ", " + (cheminRelatif == null ? "null" : Js(cheminRelatif)) + ");";
            lock (verrou)
            {
                Ajouter(fIcones, ligne, "// Icône de chaque ressource (téléchargée depuis DofusDB). null = introuvable.");
                icones[Ecran.Normaliser(nom)] = cheminRelatif == null ? "" : Path.Combine(Dossier, cheminRelatif.Replace('/', '\\'));
            }
            Signaler();
        }

        public void AjouterAchat(Achat a)
        {
            a.Ligne = (a.Vente ? "V" : "A") + "({d: \"" + a.T.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) + "\", n: " + Js(a.Nom) +
                ", q: " + a.Quantite + ", k: " + a.Prix + ", s: " + Js(a.Serveur = Reglages.Serveur) + "});";
            lock (verrou)
            {
                Ajouter(fAchats, a.Ligne, "// Achats (A) et ventes (V) à l'HDV lus dans le chat : d = date, n = ressource, q = quantité, k = kamas (payés ou gagnés).");
                achats.Add(a);
            }
            Signaler();
        }

        /// <summary>Retire un achat (mal lu, par exemple) : sa ligne est enlevée du fichier.</summary>
        public void SupprimerAchat(Achat a)
        {
            lock (verrou)
            {
                if (!achats.Remove(a)) return;
                var lignes = Lignes(fAchats).ToList();
                int i = lignes.IndexOf(a.Ligne);
                if (i >= 0) lignes.RemoveAt(i);
                File.WriteAllText(fAchats, string.Join("\r\n", lignes) + "\r\n", Utf8);
            }
            Signaler();
        }

        /// <summary>Retire un relevé faux : sa ligne est enlevée de prix.js.</summary>
        public void SupprimerReleve(Releve r)
        {
            lock (verrou)
            {
                if (!releves.Remove(r)) return;
                var lignes = Lignes(fPrix).ToList();
                int i = lignes.IndexOf(r.Ligne);
                if (i >= 0) { lignes.RemoveAt(i); File.WriteAllText(fPrix, string.Join("\r\n", lignes) + "\r\n", Utf8); }
            }
            Signaler();
        }

        /// <summary>
        /// Une copie par jour des prix, des achats et des réglages dans donnees\sauvegardes\AAAA-MM-JJ (faite au premier
        /// lancement du jour) ; les 7 dernières sont gardées.
        /// </summary>
        void Sauvegarder()
        {
            try
            {
                string racine = Path.Combine(Dossier, "sauvegardes"), jour = Path.Combine(racine, DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
                if (Directory.Exists(jour)) return;
                Directory.CreateDirectory(jour);
                foreach (string f in new[] { fPrix, fAchats, fReglages })
                    if (File.Exists(f)) File.Copy(f, Path.Combine(jour, Path.GetFileName(f)), true);
                foreach (string vieux in Directory.GetDirectories(racine).OrderByDescending(x => x).Skip(7)) Directory.Delete(vieux, true);
            }
            catch { }
        }

        public void SauverReglages()
        {
            lock (verrou)
                try { File.WriteAllText(fReglages, new JavaScriptSerializer().Serialize(Reglages), Utf8); } catch { }
        }
    }
}
