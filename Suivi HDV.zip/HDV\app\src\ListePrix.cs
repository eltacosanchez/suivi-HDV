using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace SuiviHDV
{
    /// <summary>Images des icônes, chargées une fois (sans garder le fichier ouvert).</summary>
    public static class Images
    {
        static readonly Dictionary<string, Image> cache = new Dictionary<string, Image>();

        public static Image Charger(string chemin)
        {
            if (string.IsNullOrEmpty(chemin)) return null;
            Image img;
            if (cache.TryGetValue(chemin, out img)) return img;
            try { using (var ms = new MemoryStream(File.ReadAllBytes(chemin))) img = new Bitmap(Image.FromStream(ms)); }
            catch { img = null; }
            cache[chemin] = img;
            return img;
        }

        /// <summary>Icône de la ressource, ou une pastille avec son initiale.</summary>
        public static void Dessiner(Graphics g, Ressource r, RectangleF zone)
        {
            var img = Charger(r.Icone);
            if (img != null)
            {
                var old = g.InterpolationMode;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(img, zone);
                g.InterpolationMode = old;
                return;
            }
            Theme.Remplir(g, Theme.Card2, zone, zone.Width / 4);
            TextRenderer.DrawText(g, r.Nom.Substring(0, 1).ToUpper(), Theme.F(Math.Max(7f, zone.Height / Theme.Dpi * 0.36f), true), Rectangle.Round(zone), Theme.Dim,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.PreserveGraphicsClipping);
        }
    }

    /// <summary>
    /// Le tableau des prix : icône, nom, prix de chaque lot, prix par unité, variations et petite courbe.
    /// Groupé par catégorie si demandé ; clic sur un en-tête pour trier, clic sur une ligne pour le détail.
    /// </summary>
    public class ListePrix : Surface
    {
        class Element { public string Groupe; public int Nb; public Vue V; public bool Recente; }
        public const int MinutesRecentes = 10;

        /// <summary>Remonte tout en haut du tableau (après un nouveau relevé).</summary>
        public void HautDePage() { decalage = 0; Invalidate(); }
        class Col { public string Titre, Tri; public float Poids; public bool Droite; public int Lot; }

        public event Action<Ressource> Ouvrir;
        public string Vide = "";
        public bool Grouper = true;
        public int LotRef = 100;
        public string Tri = "nom";
        public int Sens = 1;

        List<Element> elements = new List<Element>();
        int decalage, survol = -1, survolEntete = -1;
        readonly List<Col> colonnes = new List<Col>
        {
            new Col { Titre = "Ressource", Tri = "nom", Poids = 3.4f },
            new Col { Titre = "x1", Poids = 1.1f, Droite = true, Lot = 1 },
            new Col { Titre = "x10", Poids = 1.1f, Droite = true, Lot = 10 },
            new Col { Titre = "x100", Poids = 1.2f, Droite = true, Lot = 100 },
            new Col { Titre = "x1000", Poids = 1.3f, Droite = true, Lot = 1000 },
            new Col { Titre = "Prix/u", Tri = "prix", Poids = 1f, Droite = true },
            new Col { Titre = "Veille", Tri = "veille", Poids = 1.1f, Droite = true },
            new Col { Titre = "Période", Tri = "periode", Poids = 1.1f, Droite = true },
            new Col { Titre = "Tendance", Poids = 1.3f },
            new Col { Titre = "Relevé", Tri = "date", Poids = 1.4f, Droite = true },
        };

        int HEntete { get { return Theme.S(30); } }
        int HLigne { get { return Theme.S(48); } }
        int HGroupe { get { return Theme.S(30); } }
        int H(Element e) { return e.Groupe != null ? HGroupe : HLigne; }
        int HTotal { get { return elements.Sum(e => H(e)); } }

        public ListePrix() { BackColor = Theme.Card; }

        public string TitrePeriode { set { colonnes[7].Titre = value; Invalidate(); } }

        public void Remplir(List<Vue> vues)
        {
            Func<Vue, object> cle;
            switch (Tri)
            {
                case "prix": cle = v => v.PrixU; break;
                case "veille": cle = v => v.Veille; break;
                case "periode": cle = v => v.Periode; break;
                case "date": cle = v => v.R.Dernier.T; break;
                default: cle = v => v.R.Nom; break;
            }
            var avec = vues.Where(v => cle(v) != null).ToList();
            var sans = vues.Where(v => cle(v) == null).OrderBy(v => v.R.Nom, StringComparer.Create(Calculs.Fr, true)).ToList();
            IOrderedEnumerable<Vue> tries;
            if (Tri == "nom") tries = Sens > 0 ? avec.OrderBy(v => v.R.Nom, StringComparer.Create(Calculs.Fr, true)) : avec.OrderByDescending(v => v.R.Nom, StringComparer.Create(Calculs.Fr, true));
            else tries = Sens > 0 ? avec.OrderBy(cle) : avec.OrderByDescending(cle);
            var liste = tries.Concat(sans).ToList();

            elements = new List<Element>();
            // Tout en haut : ce qui vient d'être relevé (10 dernières minutes), le plus récent en premier.
            var recentes = liste.Where(v => v.R.Dernier.T >= DateTime.Now.AddMinutes(-MinutesRecentes))
                .OrderByDescending(v => v.R.Dernier.T).Take(8).ToList();
            if (recentes.Count > 0)
            {
                elements.Add(new Element { Groupe = "Relevées à l'instant", Nb = recentes.Count, Recente = true });
                elements.AddRange(recentes.Select(v => new Element { V = v, Recente = true }));
                liste = liste.Except(recentes).ToList();
            }
            if (Grouper)
                foreach (var g in liste.GroupBy(v => v.R.Cat).OrderBy(g => g.Key, StringComparer.Create(Calculs.Fr, true)))
                {
                    elements.Add(new Element { Groupe = g.Key, Nb = g.Count() });
                    elements.AddRange(g.Select(v => new Element { V = v }));
                }
            else elements.AddRange(liste.Select(v => new Element { V = v }));
            decalage = Math.Max(0, Math.Min(decalage, HTotal - (Height - HEntete)));
            Invalidate();
        }

        float[] Bords()
        {
            float total = colonnes.Sum(c => c.Poids);
            float largeur = Width - Theme.S(24);
            var b = new float[colonnes.Count + 1];
            b[0] = Theme.S(10);
            for (int i = 0; i < colonnes.Count; i++) b[i + 1] = b[i] + largeur * colonnes[i].Poids / total;
            return b;
        }

        int ElementSous(int y)
        {
            if (y < HEntete) return -1;
            int yy = HEntete - decalage;
            for (int i = 0; i < elements.Count; i++) { int h = H(elements[i]); if (y >= yy && y < yy + h) return i; yy += h; }
            return -1;
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            int max = Math.Max(0, HTotal - (Height - HEntete));
            decalage = Math.Max(0, Math.Min(max, decalage - Math.Sign(e.Delta) * HLigne * 2));
            Invalidate();
            base.OnMouseWheel(e);
        }

        protected override void OnMouseEnter(EventArgs e) { Focus(); base.OnMouseEnter(e); }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = ElementSous(e.Y);
            if (s >= 0 && elements[s].V == null) s = -1;
            int se = -1;
            if (e.Y < HEntete)
            {
                var b = Bords();
                for (int i = 0; i < colonnes.Count; i++) if (e.X >= b[i] && e.X < b[i + 1] && colonnes[i].Tri != null) se = i;
            }
            if (s != survol || se != survolEntete) { survol = s; survolEntete = se; Invalidate(); }
            Cursor = s >= 0 || se >= 0 ? Cursors.Hand : Cursors.Default;
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { survol = -1; survolEntete = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (survolEntete >= 0)
            {
                string t = colonnes[survolEntete].Tri;
                if (Tri == t) Sens = -Sens; else { Tri = t; Sens = t == "nom" ? 1 : -1; }
                var v = elements.Where(x => x.V != null).Select(x => x.V).ToList();
                Remplir(v);
            }
            else if (survol >= 0 && elements[survol].V != null) { var o = Ouvrir; if (o != null) o(elements[survol].V.R); }
            base.OnMouseClick(e);
        }

        protected override void OnResize(EventArgs e) { decalage = Math.Max(0, Math.Min(decalage, HTotal - (Height - HEntete))); base.OnResize(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var b = Bords();
            // PreserveGraphicsClipping : sans lui, le texte des lignes déborde sur l'en-tête quand on fait défiler.
            const TextFormatFlags f = TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine | TextFormatFlags.PreserveGraphicsClipping;

            // En-tête (le lot de référence est en doré, la colonne triée a sa flèche).
            for (int i = 0; i < colonnes.Count; i++)
            {
                var c = colonnes[i];
                var r = new Rectangle((int)b[i] + Theme.S(4), 0, (int)(b[i + 1] - b[i]) - Theme.S(8), HEntete);
                string titre = c.Titre + (c.Tri != null && c.Tri == Tri ? (Sens > 0 ? " ▲" : " ▼") : "");
                Color couleur = c.Lot == LotRef && c.Lot > 0 ? Theme.Accent : i == survolEntete ? Theme.Text : Theme.Faint;
                TextRenderer.DrawText(g, titre, Theme.F(8f, c.Lot == LotRef && c.Lot > 0), r, couleur, f | (c.Droite ? TextFormatFlags.Right : 0));
            }
            using (var pen = new Pen(Theme.Border)) g.DrawLine(pen, Theme.S(8), HEntete - 1, Width - Theme.S(8), HEntete - 1);

            if (elements.Count == 0)
            {
                TextRenderer.DrawText(g, Vide, Theme.F(9.5f), new Rectangle(Theme.S(16), HEntete + Theme.S(16), Width - Theme.S(32), Height - HEntete - Theme.S(32)),
                    Theme.Faint, TextFormatFlags.WordBreak | TextFormatFlags.NoPrefix | TextFormatFlags.HorizontalCenter);
                return;
            }

            g.SetClip(new Rectangle(0, HEntete, Width, Height - HEntete));
            int y = HEntete - decalage;
            for (int k = 0; k < elements.Count && y < Height; k++)
            {
                var el = elements[k];
                int h = H(el);
                if (y + h < HEntete) { y += h; continue; }
                if (el.Groupe != null)
                {
                    var zg = new Rectangle(Theme.S(10), y + Theme.S(4), Width - Theme.S(20), h - Theme.S(4));
                    TextRenderer.DrawText(g, el.Groupe.ToUpper(), Theme.F(8f, true), zg, el.Recente ? Theme.Accent : Theme.Dim, f);
                    int lt = TextRenderer.MeasureText(g, el.Groupe.ToUpper(), Theme.F(8f, true), Size.Empty, f).Width;
                    TextRenderer.DrawText(g, el.Nb.ToString(), Theme.F(8f), new Rectangle(zg.X + lt + Theme.S(4), zg.Y, Theme.S(40), zg.Height), Theme.Faint, f);
                    y += h;
                    continue;
                }
                var v = el.V;
                var fond = new RectangleF(Theme.S(4), y + 1, Width - Theme.S(8), h - 2);
                if (k == survol) Theme.Remplir(g, Theme.Hover, fond, Theme.Sf(7));
                else if (el.Recente) Theme.Remplir(g, Theme.Mix(Theme.Card, Theme.Accent, 0.10f), fond, Theme.Sf(7));
                var der = v.R.Dernier;
                for (int i = 0; i < colonnes.Count; i++)
                {
                    var c = colonnes[i];
                    var r = new Rectangle((int)b[i] + Theme.S(4), y, (int)(b[i + 1] - b[i]) - Theme.S(8), h);
                    var fl = f | (c.Droite ? TextFormatFlags.Right : 0);
                    if (i == 0)
                    {
                        float ti = Theme.Sf(34);
                        Images.Dessiner(g, v.R, new RectangleF(r.X, y + (h - ti) / 2, ti, ti));
                        var zn = new Rectangle(r.X + (int)ti + Theme.S(10), y, r.Width - (int)ti - Theme.S(10), h);
                        if (Grouper) TextRenderer.DrawText(g, v.R.Nom, Theme.F(9.5f, true), zn, Theme.Text, f);
                        else
                        {
                            TextRenderer.DrawText(g, v.R.Nom, Theme.F(9.5f, true), new Rectangle(zn.X, y + Theme.S(6), zn.Width, h / 2 - Theme.S(4)), Theme.Text, f | TextFormatFlags.Bottom);
                            TextRenderer.DrawText(g, v.R.Cat, Theme.F(8f), new Rectangle(zn.X, y + h / 2 + Theme.S(1), zn.Width, h / 2 - Theme.S(6)), Theme.Faint, f | TextFormatFlags.Top);
                        }
                    }
                    else if (c.Lot > 0)
                    {
                        var p = der.Prix(c.Lot);
                        bool reference = c.Lot == LotRef;
                        if (!p.HasValue) { TextRenderer.DrawText(g, "—", Theme.F(9f), r, Theme.Faint, fl); continue; }
                        if (c.Lot == 1) { TextRenderer.DrawText(g, Calculs.Kamas(p), Theme.F(9.5f, reference), r, reference ? Theme.Text : Theme.Dim, fl); continue; }
                        TextRenderer.DrawText(g, Calculs.Kamas(p), Theme.F(9.5f, reference), new Rectangle(r.X, y + Theme.S(5), r.Width, h / 2 - Theme.S(3)), reference ? Theme.Text : Theme.Dim, fl | TextFormatFlags.Bottom);
                        TextRenderer.DrawText(g, Calculs.Unitaire(p.Value / (double)c.Lot) + " /u", Theme.F(7.5f), new Rectangle(r.X, y + h / 2 + Theme.S(1), r.Width, h / 2 - Theme.S(6)), Theme.Faint, fl | TextFormatFlags.Top);
                    }
                    else if (c.Tri == "prix")
                        TextRenderer.DrawText(g, Calculs.Unitaire(v.PrixU) + (v.Substitue ? "*" : ""), Theme.F(9.5f, true), r, Theme.Kamas, fl);
                    else if (c.Tri == "veille" || c.Tri == "periode")
                    {
                        var val = c.Tri == "veille" ? v.Veille : v.Periode;
                        Color col = !val.HasValue || Math.Abs(val.Value) < 0.0005 ? Theme.Faint : val.Value > 0 ? Theme.Green : Theme.Red;
                        TextRenderer.DrawText(g, Calculs.Pourcent(val), Theme.F(9f, val.HasValue), r, col, fl);
                    }
                    else if (c.Titre == "Tendance") Courbe(g, v.Serie, new RectangleF(r.X, y + Theme.S(10), r.Width, h - Theme.S(20)));
                    else if (c.Tri == "date") TextRenderer.DrawText(g, Calculs.Date(der.T), Theme.F(8.5f), r, Theme.Faint, fl);
                }
                y += h;
            }
            g.ResetClip();

            int visible = Height - HEntete;
            if (HTotal > visible)
            {
                float hb = Height - HEntete - Theme.S(8);
                float lg = Math.Max(Theme.S(24), hb * visible / HTotal);
                float pos = HEntete + Theme.S(4) + (hb - lg) * decalage / Math.Max(1, HTotal - visible);
                Theme.Remplir(g, Theme.Border, new RectangleF(Width - Theme.S(6), pos, Theme.S(3), lg), Theme.Sf(1.5f));
            }
        }

        /// <summary>Petite courbe du prix par unité sur la période, avec un point sur le dernier relevé.</summary>
        public static void Courbe(Graphics g, List<KeyValuePair<DateTime, double>> serie, RectangleF r)
        {
            if (serie.Count < 2) { TextRenderer.DrawText(g, "—", Theme.F(9f), Rectangle.Round(r), Theme.Faint, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.PreserveGraphicsClipping); return; }
            double t0 = serie[0].Key.Ticks, t1 = serie[serie.Count - 1].Key.Ticks;
            double min = serie.Min(p => p.Value), max = serie.Max(p => p.Value);
            if (max == min) { max += 1; min -= 1; }
            var pts = serie.Select(p => new PointF(
                r.X + (float)((p.Key.Ticks - t0) / Math.Max(1, t1 - t0)) * r.Width,
                r.Bottom - (float)((p.Value - min) / (max - min)) * r.Height)).ToArray();
            Color c = serie[serie.Count - 1].Value >= serie[0].Value ? Theme.Green : Theme.Red;
            using (var pen = new Pen(Theme.Mix(c, Theme.Card, 0.15f), Theme.Sf(1.6f)) { LineJoin = LineJoin.Round })
                g.DrawLines(pen, pts);
            var der = pts[pts.Length - 1];
            float rr = Theme.Sf(2.6f);
            using (var b = new SolidBrush(c)) g.FillEllipse(b, der.X - rr, der.Y - rr, 2 * rr, 2 * rr);
        }
    }
}
