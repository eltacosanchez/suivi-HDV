using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;

namespace SuiviHDV
{
    /// <summary>
    /// Relit une case de prix que l'OCR n'a pas su lire, en plusieurs essais.
    ///
    /// La cause la plus fréquente : un prix d'un seul chiffre (« 5 » kamas). L'OCR de Windows ignore un caractère
    /// isolé — même agrandi, même en couleurs inversées. Mais placé juste après un nombre qu'il sait lire, de la même
    /// police (un autre prix de la même fiche), il le lit sans problème.
    ///
    /// Essais, dans l'ordre :
    ///  1. la case seule, agrandie (corrige aussi « i 228 » au lieu de « 1 228 ») ;
    ///  2. le chiffre collé après plusieurs prix lisibles de la fiche, à deux tailles : la valeur n'est gardée que si
    ///     au moins deux essais donnent la même et qu'aucun ne donne autre chose.
    /// </summary>
    public static class Relecture
    {
        // Le texte des prix est blanc / gris clair ; le symbole kamas, jaune, n'en fait pas partie.
        static bool Encre(int r, int g, int b)
        {
            int max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
            return min > 140 && max - min < 70;
        }

        /// <summary>Le rectangle qui contient tout le texte clair de la zone, ou null si elle est vide.</summary>
        static Rectangle? Texte(Bitmap bmp, Rectangle zone)
        {
            zone.Intersect(new Rectangle(0, 0, bmp.Width, bmp.Height));
            if (zone.Width < 3 || zone.Height < 3) return null;
            var d = bmp.LockBits(zone, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            try
            {
                var ligne = new byte[zone.Width * 4];
                int x1 = int.MaxValue, y1 = int.MaxValue, x2 = -1, y2 = -1, n = 0;
                for (int y = 0; y < zone.Height; y++)
                {
                    Marshal.Copy(d.Scan0 + y * d.Stride, ligne, 0, ligne.Length);
                    for (int x = 0; x < zone.Width; x++)
                    {
                        if (!Encre(ligne[x * 4 + 2], ligne[x * 4 + 1], ligne[x * 4])) continue;
                        n++;
                        x1 = Math.Min(x1, x); x2 = Math.Max(x2, x); y1 = Math.Min(y1, y); y2 = Math.Max(y2, y);
                    }
                }
                if (n < 4) return null;
                return new Rectangle(zone.X + x1, zone.Y + y1, x2 - x1 + 1, y2 - y1 + 1);
            }
            finally { bmp.UnlockBits(d); }
        }

        /// <summary>Colle des morceaux de l'image côte à côte, centrés en hauteur, sur le fond de la fiche, puis agrandit.
        /// « debuts » reçoit l'abscisse de départ de chaque morceau dans l'image obtenue.</summary>
        static Bitmap Assembler(Bitmap src, IList<Rectangle> morceaux, int ecart, double echelle, out List<double> debuts)
        {
            int h = morceaux.Max(m => m.Height) + 2 * ecart;
            int w = morceaux.Sum(m => m.Width) + ecart * (morceaux.Count + 1);
            var dst = new Bitmap(Math.Max(1, (int)(w * echelle)), Math.Max(1, (int)(h * echelle)), PixelFormat.Format32bppArgb);
            debuts = new List<double>();
            using (var g = Graphics.FromImage(dst))
            {
                var p = morceaux[0];
                g.Clear(src.GetPixel(Math.Max(0, p.X - 1), Math.Max(0, p.Y - 1)));
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                int x = ecart;
                foreach (var m in morceaux)
                {
                    debuts.Add(x * echelle);
                    int y = (h - m.Height) / 2;
                    g.DrawImage(src, new Rectangle((int)(x * echelle), (int)(y * echelle), (int)(m.Width * echelle), (int)(m.Height * echelle)),
                        m.X, m.Y, m.Width, m.Height, GraphicsUnit.Pixel);
                    x += m.Width + ecart;
                }
            }
            return dst;
        }

        static Rectangle Borner(Bitmap bmp, Rectangle r)
        {
            r.Intersect(new Rectangle(0, 0, bmp.Width, bmp.Height));
            return r;
        }

        /// <summary>
        /// Relit le prix d'une ligne. « voisins » : des prix lisibles d'autres lignes de la même fiche (mots de l'OCR).
        /// « dy » : décalage vertical habituel entre un prix et son bouton « ACHETER ». Null si rien de sûr.
        /// </summary>
        public static long? Prix(Bitmap bmp, MotOcr bouton, double limite, double u, double dy, List<MotOcr> voisins, Func<IEnumerable<string>, long?> nombre)
        {
            double cy = bouton.CentreY + dy;
            var zone = Rectangle.Round(RectangleF.FromLTRB((float)limite, (float)(cy - 1.9 * u), (float)(bouton.X - 0.3 * u), (float)(cy + 1.9 * u)));
            var encre = Texte(bmp, zone);
            if (encre == null) return null;
            var glyphe = Borner(bmp, Rectangle.Inflate(encre.Value, (int)Math.Ceiling(0.4 * u), (int)Math.Ceiling(0.4 * u)));
            int ecart = (int)Math.Ceiling(1.2 * u);
            List<double> debuts;

            // 1. La case seule, agrandie.
            using (var img = Assembler(bmp, new[] { glyphe }, ecart, 3, out debuts))
            {
                var v = nombre(Ocr.Lire(img).SelectMany(l => l.Mots).OrderBy(m => m.X).Select(m => m.T));
                if (v.HasValue) return v;
            }

            // 2. Collée après des prix lisibles, à deux tailles : on vote.
            var votes = new Dictionary<long, int>();
            foreach (var voisin in voisins.Take(3))
            {
                var rv = Borner(bmp, Rectangle.Inflate(Rectangle.Round(new RectangleF((float)voisin.X, (float)voisin.Y, (float)voisin.L, (float)voisin.H)),
                    (int)Math.Ceiling(0.3 * u), (int)Math.Ceiling(0.3 * u)));
                if (rv.Width < 3 || rv.Height < 3) continue;
                foreach (double echelle in new[] { 3.0, 2.0 })
                    using (var img = Assembler(bmp, new[] { rv, glyphe }, ecart, echelle, out debuts))
                    {
                        // Ce qui est lu à droite du voisin, c'est notre case.
                        var apres = Ocr.Lire(img).SelectMany(l => l.Mots).Where(m => m.X >= debuts[1] - 0.5 * u * echelle).OrderBy(m => m.X).Select(m => m.T);
                        var v = nombre(apres);
                        if (v.HasValue) { int n; votes.TryGetValue(v.Value, out n); votes[v.Value] = n + 1; }
                    }
            }
            if (votes.Count == 1 && votes.First().Value >= 2) return votes.First().Key;
            return null;
        }
    }
}
