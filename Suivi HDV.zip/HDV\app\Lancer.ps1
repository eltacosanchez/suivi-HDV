﻿# Lance Suivi HDV : compile le code source (src\*.cs) en mémoire puis ouvre la fenêtre.
# Comme pour Dofus Organizer et le Compteur XP, passer par PowerShell évite que Windows bloque un .exe non signé.
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
    $src = Get-ChildItem (Join-Path $dir 'src') -Filter *.cs | ForEach-Object { $_.FullName }
    Add-Type -Path $src -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Core, System.Web.Extensions, System.IO.Compression, System.IO.Compression.FileSystem
    [SuiviHDV.Program]::Run((Split-Path -Parent $dir))
}
catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Impossible de lancer Suivi HDV :`n`n" + $_.Exception.Message,
        'Suivi HDV', 'OK', 'Error') | Out-Null
}
