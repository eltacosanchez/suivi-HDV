using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace SuiviHdvWakfu
{
    public class CaptureLue
    {
        public string Fichier, Remarque = "";
        public bool Lisible;
        public List<Releve> Ressources = new List<Releve>();
    }

    /// <summary>
    /// Claude Code (ton abonnement) en secours : relit les captures que l'OCR n'a pas su lire.
    /// Il est réduit au strict nécessaire (lecture d'images, instructions courtes) pour consommer peu de tokens.
    /// </summary>
    public static class Claude
    {
        const string Schema = "{\"type\":\"object\",\"properties\":{\"captures\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"fichier\":{\"type\":\"string\"},\"lisible\":{\"type\":\"boolean\"},\"remarque\":{\"type\":\"string\"},\"ressources\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"n\":{\"type\":\"string\"},\"c\":{\"type\":\"string\"},\"p1\":{\"type\":[\"integer\",\"null\"]},\"p10\":{\"type\":[\"integer\",\"null\"]},\"p100\":{\"type\":[\"integer\",\"null\"]},\"p1000\":{\"type\":[\"integer\",\"null\"]},\"moy\":{\"type\":[\"integer\",\"null\"]}},\"required\":[\"n\",\"c\",\"p1\",\"p10\",\"p100\",\"p1000\",\"moy\"]}}},\"required\":[\"fichier\",\"lisible\",\"ressources\"]}}},\"required\":[\"captures\"]}";
        const string Systeme = "Tu es un assistant qui lit des captures d'écran du jeu Wakfu et relève les prix de l'hôtel de vente. Utilise l'outil Read pour ouvrir les images demandées, puis réponds uniquement avec les données structurées.";

        /// <summary>La commande claude : celle du PATH, sinon celle fournie avec l'application Claude (la plus récente).</summary>
        public static string Trouver()
        {
            var candidats = new List<FileInfo>();
            foreach (string dossier in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
                try { var f = new FileInfo(Path.Combine(dossier.Trim(), "claude.exe")); if (f.Exists) return f.FullName; } catch { }
            string appdata = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var dossiers = new List<string> { Path.Combine(appdata, @"Claude\claude-code") };
            // Application installée depuis le Microsoft Store : ses fichiers sont rangés dans le dossier du paquet.
            try { dossiers.AddRange(Directory.GetDirectories(Path.Combine(local, "Packages"), "Claude_*").Select(p => Path.Combine(p, @"LocalCache\Roaming\Claude\claude-code"))); } catch { }
            foreach (string d in dossiers)
                try { if (Directory.Exists(d)) candidats.AddRange(new DirectoryInfo(d).GetFiles("claude.exe", SearchOption.AllDirectories)); } catch { }
            var bin = new FileInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), @".local\bin\claude.exe"));
            if (bin.Exists) candidats.Add(bin);
            var meilleur = candidats.OrderByDescending(f => f.LastWriteTime).FirstOrDefault();
            return meilleur != null ? meilleur.FullName : null;
        }

        static object Champ(object o, string k)
        {
            var d = o as IDictionary;
            return d != null && d.Contains(k) ? d[k] : null;
        }

        static long? Prix(object o, string k)
        {
            var v = Champ(o, k);
            if (v == null) return null;
            try { long n = Convert.ToInt64(v); return n > 0 ? n : (long?)null; } catch { return null; }
        }

        static long N(object o, string k) { var v = Champ(o, k); try { return v == null ? 0 : Convert.ToInt64(v); } catch { return 0; } }

        /// <summary>Fait relire les captures par Claude. Renvoie une entrée par capture ; « conso » reçoit les tokens utilisés.</summary>
        public static List<CaptureLue> Relire(IList<string> fichiers, string connus, string modele, string dossierTravail, out Conso conso)
        {
            conso = null;
            string exe = Trouver();
            if (exe == null) throw new Exception("Commande claude introuvable : l'application Claude est-elle installée ?");

            var prompt = new StringBuilder();
            prompt.AppendLine("Tu relèves les prix des ressources sur des captures d'écran de l'hôtel de vente (HDV) de Wakfu.");
            prompt.AppendLine("Ouvre chacune de ces images avec l'outil Read :");
            foreach (string f in fichiers) prompt.AppendLine("- " + f);
            prompt.AppendLine();
            prompt.AppendLine("Pour chaque capture, relève chaque ressource dont les prix sont lisibles :");
            prompt.AppendLine("- n : le nom exact affiché en jeu, accents et majuscules compris. Si la ressource fait partie des noms déjà connus ci-dessous, réutilise exactement ce nom.");
            prompt.AppendLine("- c : la catégorie HDV au singulier (Minerai, Bois, Céréale, Plante, Fleur, Poisson, Viande, Peau, Laine, Plume, Os, Œuf, Poudre, Pierre précieuse, Essence, Alliage, Planche, Teinture…). Prends celle affichée en jeu si elle est visible, sinon celle déjà connue, sinon déduis-la.");
            prompt.AppendLine("- p1, p10, p100 : le prix le plus bas affiché pour chaque taille de lot (1, 10 ou 100 unités), en kamas, nombre entier sans espaces ; p1000 : toujours null. null si le lot est absent ou illisible.");
            prompt.AppendLine("- moy : le prix moyen par unité s'il est affiché, sinon null.");
            prompt.AppendLine("Ne devine jamais un chiffre : mets null en cas de doute et explique-le dans \"remarque\".");
            prompt.AppendLine("Si une capture ne montre pas l'HDV ou qu'aucun prix n'est lisible, mets \"lisible\": false et une liste \"ressources\" vide.");
            prompt.AppendLine("\"fichier\" est le nom du fichier, sans le dossier. Renvoie une entrée par capture.");
            prompt.AppendLine();
            prompt.AppendLine("Noms déjà connus (nom → catégorie) : " + (string.IsNullOrEmpty(connus) ? "(aucun pour l'instant)" : connus));

            var psi = new ProcessStartInfo(exe,
                "-p --model " + modele + " --output-format json --tools Read --allowedTools Read --strict-mcp-config --disable-slash-commands " +
                "--max-turns 40 --no-session-persistence --system-prompt \"" + Systeme + "\" --json-schema \"" + Schema.Replace("\"", "\\\"") + "\"")
            {
                UseShellExecute = false, CreateNoWindow = true,
                RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8,
                WorkingDirectory = dossierTravail
            };
            string sortie, erreurs;
            using (var p = Process.Start(psi))
            {
                var octets = new UTF8Encoding(false).GetBytes(prompt.ToString());
                p.StandardInput.BaseStream.Write(octets, 0, octets.Length);
                p.StandardInput.Close();
                var tSortie = p.StandardOutput.ReadToEndAsync();
                var tErreurs = p.StandardError.ReadToEndAsync();
                if (!p.WaitForExit(15 * 60 * 1000)) { try { p.Kill(); } catch { } throw new Exception("Claude n'a pas répondu en 15 minutes."); }
                p.WaitForExit();
                sortie = tSortie.Result; erreurs = tErreurs.Result;
            }
            if (string.IsNullOrWhiteSpace(sortie)) throw new Exception("Claude n'a rien renvoyé. " + (erreurs ?? "").Trim());

            var ser = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var json = ser.DeserializeObject(sortie);
            var usage = Champ(json, "usage");
            if (usage != null)
            {
                double usd = 0;
                try { usd = Convert.ToDouble(Champ(json, "total_cost_usd") ?? 0); } catch { }
                conso = new Conso
                {
                    T = DateTime.Now, Captures = fichiers.Count, Entree = N(usage, "input_tokens"), CacheEcrit = N(usage, "cache_creation_input_tokens"),
                    CacheLu = N(usage, "cache_read_input_tokens"), Sortie = N(usage, "output_tokens"), Usd = usd, Modele = modele
                };
                if (conso.Total == 0) conso = null;
            }
            if (Equals(Champ(json, "is_error"), true))
            {
                string msg = Convert.ToString(Champ(json, "result"));
                if (msg.IndexOf("login", StringComparison.OrdinalIgnoreCase) >= 0 || msg.IndexOf("log in", StringComparison.OrdinalIgnoreCase) >= 0)
                    throw new Exception("Claude n'est pas connecté : lance « Connexion Claude (une seule fois).bat » dans le dossier HDV (celui du Suivi HDV de Dofus : la connexion vaut pour les deux).");
                throw new Exception("Erreur de Claude : " + msg);
            }

            object res = Champ(json, "structured_output");
            if (res == null)
            {
                string texte = Convert.ToString(Champ(json, "result"));
                int a = texte.IndexOf('{'), b = texte.LastIndexOf('}');
                if (a < 0 || b <= a) throw new Exception("Réponse de Claude illisible.");
                res = ser.DeserializeObject(texte.Substring(a, b - a + 1));
            }

            var liste = new List<CaptureLue>();
            var caps = Champ(res, "captures") as IEnumerable;
            if (caps == null) return liste;
            foreach (object c in caps)
            {
                var cl = new CaptureLue
                {
                    Fichier = Path.GetFileName(Convert.ToString(Champ(c, "fichier"))),
                    Lisible = Equals(Champ(c, "lisible"), true),
                    Remarque = Convert.ToString(Champ(c, "remarque") ?? "")
                };
                var ress = Champ(c, "ressources") as IEnumerable;
                if (ress != null)
                    foreach (object r in ress)
                        cl.Ressources.Add(new Releve
                        {
                            Nom = Convert.ToString(Champ(r, "n") ?? "").Trim(), Cat = Convert.ToString(Champ(r, "c") ?? "").Trim(),
                            P1 = Prix(r, "p1"), P10 = Prix(r, "p10"), P100 = Prix(r, "p100"), P1000 = Prix(r, "p1000"), Moy = Prix(r, "moy")
                        });
                liste.Add(cl);
            }
            return liste;
        }
    }
}
