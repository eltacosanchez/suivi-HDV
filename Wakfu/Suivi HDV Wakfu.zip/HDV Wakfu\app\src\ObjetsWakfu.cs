using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace SuiviHdvWakfu
{
    public class ObjetWakfu { public string Nom, Categorie; public long Id, IconId; }

    /// <summary>
    /// Noms, catégories, icônes et recettes des objets de Wakfu, d'après les données publiques d'Ankama
    /// (wakfu.cdn.ankama.com, les mêmes que celles du Compteur Wakfu). Tout est téléchargé une fois (environ 25 Mo),
    /// réduit à l'essentiel dans donnees\wakfu\objets.txt et recettes.txt, et rafraîchi tous les 30 jours.
    /// Les icônes viennent de static.ankama.com, une par objet, téléchargées à la demande dans donnees\icones.
    /// </summary>
    public static class ObjetsWakfu
    {
        const string Cdn = "https://wakfu.cdn.ankama.com/gamedata/";
        const string Icones = "https://static.ankama.com/wakfu/portal/game/item/115/";

        class RecetteBrute
        {
            public long Resultat, Quantite, Metier; public int Niveau;
            public List<KeyValuePair<long, long>> Ingredients = new List<KeyValuePair<long, long>>();   // (objet, quantité)
        }

        static string dossier;
        static readonly object verrou = new object();
        static Dictionary<string, ObjetWakfu> parNom;      // nom normalisé -> objet
        static Dictionary<long, ObjetWakfu> parId;
        static Dictionary<long, RecetteBrute> recettes;    // objet fabriqué -> sa recette
        static Dictionary<long, string> metiers;
        static readonly Dictionary<string, ObjetWakfu> cache = new Dictionary<string, ObjetWakfu>();
        static readonly Dictionary<string, Recette> cacheRecettes = new Dictionary<string, Recette>();

        /// <summary>Pourquoi la liste n'a pas pu être téléchargée (null si tout va bien).</summary>
        public static string Erreur { get; private set; }
        public static bool Prete { get { lock (verrou) return parNom != null; } }
        public static int Nombre { get { lock (verrou) return parNom == null ? 0 : parNom.Count; } }

        public static void Demarrer(string dossierDonnees)
        {
            dossier = Path.Combine(dossierDonnees, "wakfu");
            new Thread(() => { try { Charger(); } catch (Exception ex) { Erreur = ex.Message; } }) { IsBackground = true, Priority = ThreadPriority.Lowest, Name = "Objets Wakfu" }.Start();
        }

        /// <summary>Même chose sans fil à part (pour les tests) : attend que tout soit chargé.</summary>
        public static void ChargerMaintenant(string dossierDonnees)
        {
            dossier = Path.Combine(dossierDonnees, "wakfu");
            Charger();
        }

        static void Charger()
        {
            Directory.CreateDirectory(dossier);
            string fObjets = Path.Combine(dossier, "objets.txt"), fRecettes = Path.Combine(dossier, "recettes.txt");
            bool vieux = !File.Exists(fObjets) || !File.Exists(fRecettes) || DateTime.Now - File.GetLastWriteTime(fObjets) > TimeSpan.FromDays(30);
            if (vieux)
            {
                try { Telecharger(fObjets, fRecettes); Erreur = null; }
                catch (Exception ex) { Erreur = "Téléchargement des données Wakfu impossible : " + ex.Message; }
            }
            if (!File.Exists(fObjets)) return;
            Lire(fObjets, fRecettes);
        }

        static WebClient Client()
        {
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
            var wc = new WebClient { Encoding = Encoding.UTF8 };
            wc.Headers[HttpRequestHeader.UserAgent] = "SuiviHdvWakfu";
            return wc;
        }

        // Les titres d'Ankama contiennent la marque du pluriel : « Hache{[~1]?s:} (Deux mains) » -> « Hache (Deux mains) ».
        static string Titre(string brut)
        {
            string s = Regex.Unescape(brut);
            s = Regex.Replace(s, @"\{\[~1\]\?[^:}]*:([^}]*)\}", "$1");
            return s.Replace('\t', ' ').Replace('\n', ' ').Replace('\r', ' ').Trim();
        }

        static readonly Regex rxTitre = new Regex("\"title\":\\{\"fr\":\"((?:[^\"\\\\]|\\\\.)*)\"");
        static readonly Regex rxGfx = new Regex("\"gfxId\":(\\d+)");
        static readonly Regex rxType = new Regex("\"itemTypeId\":(\\d+)");
        static readonly Regex rxDebut = new Regex("^(\\d+)");

        /// <summary>Les objets d'un fichier d'Ankama : id, type, icône et nom, en texte tabulé.</summary>
        static int Objets(string json, string separateur, Dictionary<long, string> types, StringBuilder sb, HashSet<long> vus)
        {
            int n = 0;
            foreach (string bloc in json.Split(new[] { separateur }, StringSplitOptions.RemoveEmptyEntries))
            {
                var id = rxDebut.Match(bloc);
                var g = rxGfx.Match(bloc);
                var t = rxTitre.Match(bloc);
                if (!id.Success || !g.Success || !t.Success) continue;
                long i = long.Parse(id.Groups[1].Value);
                if (!vus.Add(i)) continue;
                string nom = Titre(t.Groups[1].Value);
                if (nom == "") continue;
                var ty = rxType.Match(bloc);
                string cat;
                if (!ty.Success || !types.TryGetValue(long.Parse(ty.Groups[1].Value), out cat)) cat = "";
                sb.Append(i).Append('\t').Append(g.Groups[1].Value).Append('\t').Append(cat).Append('\t').Append(nom).Append('\n');
                n++;
            }
            return n;
        }

        static Dictionary<long, string> Titres(string json)
        {
            var d = new Dictionary<long, string>();
            foreach (string bloc in json.Split(new[] { "{\"definition\":{\"id\":" }, StringSplitOptions.RemoveEmptyEntries))
            {
                var id = rxDebut.Match(bloc);
                var t = rxTitre.Match(bloc);
                if (id.Success && t.Success) d[long.Parse(id.Groups[1].Value)] = Titre(t.Groups[1].Value);
            }
            return d;
        }

        static void Telecharger(string fObjets, string fRecettes)
        {
            using (var wc = Client())
            {
                string version = Regex.Match(wc.DownloadString(Cdn + "config.json"), "\"version\"\\s*:\\s*\"([^\"]+)\"").Groups[1].Value;
                if (version == "") throw new Exception("version du jeu introuvable");
                string b = Cdn + version + "/";

                // 1. Objets : équipements et consommables (items.json), ressources de récolte (jobsItems.json).
                var types = Titres(wc.DownloadString(b + "itemTypes.json"));
                var sb = new StringBuilder();
                var vus = new HashSet<long>();
                int n = Objets(wc.DownloadString(b + "items.json"), "{\"definition\":{\"item\":{\"id\":", types, sb, vus);
                n += Objets(wc.DownloadString(b + "jobsItems.json"), "{\"definition\":{\"id\":", types, sb, vus);
                if (n < 1000) throw new Exception("liste des objets incomplète (" + n + ")");

                // 2. Recettes : métier et niveau, ingrédients, objet fabriqué.
                var categories = Titres(wc.DownloadString(b + "recipeCategories.json"));
                var rec = new Dictionary<long, RecetteBrute>();   // par id de recette
                foreach (Match m in Regex.Matches(wc.DownloadString(b + "recipes.json"), "\\{\"id\":(\\d+),\"categoryId\":(\\d+),\"level\":(\\d+),\"xpRatio\":\\d+,\"isUpgrade\":(true|false)"))
                {
                    if (m.Groups[4].Value == "true") continue;   // amélioration d'un objet existant, pas une fabrication
                    long cat = long.Parse(m.Groups[2].Value);
                    rec[long.Parse(m.Groups[1].Value)] = new RecetteBrute { Metier = cat, Niveau = int.Parse(m.Groups[3].Value) };
                }
                foreach (Match m in Regex.Matches(wc.DownloadString(b + "recipeIngredients.json"), "\\{\"recipeId\":(\\d+),\"itemId\":(\\d+),\"quantity\":(\\d+)"))
                {
                    RecetteBrute r;
                    if (rec.TryGetValue(long.Parse(m.Groups[1].Value), out r))
                        r.Ingredients.Add(new KeyValuePair<long, long>(long.Parse(m.Groups[2].Value), long.Parse(m.Groups[3].Value)));
                }
                foreach (Match m in Regex.Matches(wc.DownloadString(b + "recipeResults.json"), "\\{\"recipeId\":(\\d+),\"productedItemId\":(\\d+),\"productOrder\":\\d+,\"productedItemQuantity\":(\\d+)"))
                {
                    RecetteBrute r;
                    if (rec.TryGetValue(long.Parse(m.Groups[1].Value), out r) && r.Resultat == 0)
                    {
                        r.Resultat = long.Parse(m.Groups[2].Value);
                        r.Quantite = long.Parse(m.Groups[3].Value);
                    }
                }
                var sr = new StringBuilder();
                foreach (var r in rec.Values.Where(r => r.Resultat > 0 && r.Ingredients.Count > 0).OrderBy(r => r.Resultat).ThenBy(r => r.Niveau))
                {
                    string metier;
                    if (!categories.TryGetValue(r.Metier, out metier)) metier = "";
                    sr.Append(r.Resultat).Append('\t').Append(r.Quantite).Append('\t').Append(metier).Append('\t').Append(r.Niveau).Append('\t')
                      .Append(string.Join(" ", r.Ingredients.Select(i => i.Key + ":" + i.Value))).Append('\n');
                }

                File.WriteAllText(fObjets + ".tmp", sb.ToString(), new UTF8Encoding(false));
                File.WriteAllText(fRecettes + ".tmp", sr.ToString(), new UTF8Encoding(false));
            }
            if (File.Exists(fObjets)) File.Delete(fObjets);
            File.Move(fObjets + ".tmp", fObjets);
            if (File.Exists(fRecettes)) File.Delete(fRecettes);
            File.Move(fRecettes + ".tmp", fRecettes);
        }

        static void Lire(string fObjets, string fRecettes)
        {
            var n = new Dictionary<string, ObjetWakfu>();
            var i = new Dictionary<long, ObjetWakfu>();
            foreach (string l in File.ReadAllLines(fObjets, Encoding.UTF8))
            {
                var c = l.Split('\t');
                long id, gfx;
                if (c.Length < 4 || !long.TryParse(c[0], out id) || !long.TryParse(c[1], out gfx)) continue;
                var o = new ObjetWakfu { Id = id, IconId = gfx, Categorie = c[2], Nom = c[3] };
                i[id] = o;
                string cle = Ecran.Normaliser(o.Nom);
                if (cle.Length > 0 && !n.ContainsKey(cle)) n[cle] = o;
            }
            var r = new Dictionary<long, RecetteBrute>();
            var m = new Dictionary<long, string>();
            if (File.Exists(fRecettes))
                foreach (string l in File.ReadAllLines(fRecettes, Encoding.UTF8))
                {
                    var c = l.Split('\t');
                    long res, q; int niv;
                    if (c.Length < 5 || !long.TryParse(c[0], out res) || !long.TryParse(c[1], out q) || !int.TryParse(c[3], out niv)) continue;
                    if (r.ContainsKey(res)) continue;   // la première (niveau le plus bas) suffit
                    var rb = new RecetteBrute { Resultat = res, Quantite = q, Niveau = niv, Metier = r.Count + 1 };
                    m[rb.Metier] = c[2];
                    foreach (string ing in c[4].Split(' '))
                    {
                        var p = ing.Split(':');
                        long a, b;
                        if (p.Length == 2 && long.TryParse(p[0], out a) && long.TryParse(p[1], out b)) rb.Ingredients.Add(new KeyValuePair<long, long>(a, b));
                    }
                    if (rb.Ingredients.Count > 0) r[res] = rb;
                }
            lock (verrou) { parNom = n; parId = i; recettes = r; metiers = m; cache.Clear(); cacheRecettes.Clear(); }
        }

        /// <summary>
        /// Cherche un objet par son nom (tel que l'OCR l'a lu : à une lettre près si le résultat est sans ambiguïté).
        /// Null s'il n'existe pas. Lève une exception tant que la liste n'est pas chargée (téléchargement en cours,
        /// ou impossible) : on réessaiera plus tard.
        /// </summary>
        public static ObjetWakfu Chercher(string nom)
        {
            nom = (nom ?? "").Trim();
            if (nom == "") return null;
            Dictionary<string, ObjetWakfu> d;
            lock (verrou)
            {
                d = parNom;
                if (d == null) throw new Exception(Erreur ?? "les données Wakfu sont en cours de chargement");
                ObjetWakfu deja; if (cache.TryGetValue(nom, out deja)) return deja;
            }
            string cle = Ecran.Normaliser(nom);
            ObjetWakfu trouve;
            if (!d.TryGetValue(cle, out trouve) && cle.Length >= 5)
            {
                int tol = cle.Length >= 10 ? 2 : 1;
                var proches = d.Where(x => Math.Abs(x.Key.Length - cle.Length) <= tol && Ecran.Distance(x.Key, cle) <= tol).Take(2).ToList();
                if (proches.Count == 1) trouve = proches[0].Value;
            }
            lock (verrou) cache[nom] = trouve;
            return trouve;
        }

        /// <summary>L'objet dont on connaît le numéro (ingrédient d'une recette), ou null.</summary>
        public static ObjetWakfu ParId(long id)
        {
            ObjetWakfu o;
            lock (verrou) return parId != null && parId.TryGetValue(id, out o) ? o : null;
        }

        /// <summary>
        /// La recette d'un objet, d'après son nom (à une lettre près). Null si l'objet n'existe pas ou ne se fabrique pas.
        /// Lève une exception tant que la liste n'est pas chargée.
        /// </summary>
        public static Recette Recette(string nom)
        {
            nom = (nom ?? "").Trim();
            if (nom == "") return null;
            string cle = Ecran.Normaliser(nom);
            lock (verrou) { Recette deja; if (cacheRecettes.TryGetValue(cle, out deja)) return deja; }
            var o = Chercher(nom);
            Recette res = null;
            RecetteBrute rb = null;
            if (o != null) lock (verrou) recettes.TryGetValue(o.Id, out rb);
            if (rb != null)
            {
                string metier;
                lock (verrou) if (!metiers.TryGetValue(rb.Metier, out metier)) metier = "";
                res = new Recette { Nom = o.Nom, Categorie = o.Categorie, IconId = o.IconId, Metier = metier, Niveau = rb.Niveau, Quantite = rb.Quantite };
                foreach (var ing in rb.Ingredients)
                {
                    var oi = ParId(ing.Key);
                    if (oi == null) continue;
                    res.Ingredients.Add(new Ingredient { Nom = oi.Nom, Categorie = oi.Categorie, IconId = oi.IconId, Quantite = ing.Value });
                }
                if (res.Ingredients.Count == 0) res = null;
            }
            lock (verrou) cacheRecettes[cle] = res;
            return res;
        }

        /// <summary>Télécharge l'icône d'un objet (une seule fois) et la note dans les données.</summary>
        public static void Icone(Donnees d, string nom)
        {
            if (d.AIcone(nom)) return;
            ObjetWakfu o;
            try { o = Chercher(nom); } catch { return; }   // liste pas encore chargée : on réessaiera plus tard
            Icone(d, nom, o == null ? 0 : o.IconId);
        }

        /// <summary>Même chose quand on connaît déjà le numéro de l'icône (ingrédients d'une recette).</summary>
        public static void Icone(Donnees d, string nom, long iconId)
        {
            if (d.AIcone(nom)) return;
            if (iconId <= 0) { d.AjouterIcone(nom, null); return; }
            string fichier = iconId + ".png";
            string dest = Path.Combine(d.Dossier, "icones", fichier);
            try
            {
                if (!File.Exists(dest))
                {
                    byte[] octets;
                    using (var wc = Client()) octets = wc.DownloadData(Icones + fichier);
                    // On ne garde que de vraies images PNG.
                    if (octets.Length < 8 || octets[0] != 137 || octets[1] != 80 || octets[2] != 78 || octets[3] != 71) return;
                    File.WriteAllBytes(dest, octets);
                }
                d.AjouterIcone(nom, "icones/" + fichier);
            }
            catch { }
        }
    }
}
