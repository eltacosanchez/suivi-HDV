using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;

namespace SuiviHdvWakfu
{
    /// <summary>
    /// Ce qu'une capture montre de l'Hôtel de vente de Wakfu. Contrairement à Dofus, il n'y a pas de fiche par objet :
    /// l'onglet « Rechercher » montre une liste d'offres (une par vendeur) avec le nom de l'objet, son niveau, la quantité
    /// disponible et le prix à l'unité. Une même liste peut montrer plusieurs objets différents : « Toutes » contient une
    /// fiche par objet (la première est aussi recopiée dans cet objet-ci, pour les anciens usages).
    /// </summary>
    public class Fiche
    {
        public bool Ok;
        public bool Visible;        // une liste d'offres est à l'écran (en-tête Nom / Niv. / Quantité / Prix), même si elle n'a pas pu être lue
        public bool HdvOuvert;      // la fenêtre « Hôtel de vente » semble ouverte
        public string Raison = "";
        public string Nom, Categorie;
        public int Niveau;
        public long? P1, P10, P100, P1000, Moy;
        public long? Quantite;      // quantité disponible (toutes les offres visibles de cet objet)
        public RectangleF Zone;     // où se trouve la liste dans l'image (quand elle est visible)
        public int Relu;            // nombre de cases qu'il a fallu relire autrement (chiffre isolé…)
        public List<LigneOcr> Lignes;   // tout le texte lu à l'écran (sert aussi à repérer les achats dans le chat)
        // Plusieurs offres : les 5 moins chères (prix à l'unité) ; P1 est la moins chère. Null s'il n'y a qu'une offre.
        public bool Equipement;
        public List<long> Offres;
        public List<Fiche> Toutes;  // une fiche par objet de la liste (null pour une fiche d'objet)

        /// <summary>Les fiches d'objet à enregistrer : « Toutes », ou cette fiche seule.</summary>
        public List<Fiche> Fiches { get { return Toutes != null && Toutes.Count > 0 ? Toutes : new List<Fiche> { this }; } }

        public long? Prix(int lot)
        {
            switch (lot) { case 1: return P1; case 10: return P10; case 100: return P100; case 1000: return P1000; }
            return null;
        }

        public void DefinirPrix(int lot, long v)
        {
            switch (lot) { case 1: P1 = v; break; case 10: P10 = v; break; case 100: P100 = v; break; case 1000: P1000 = v; break; }
        }

        /// <summary>Clé qui change dès qu'un nom ou un prix change : sert à confirmer une lecture vue deux fois pareil.</summary>
        public string Cle
        {
            get
            {
                if (Toutes != null && Toutes.Count > 0) return string.Join("/", Toutes.Select(x => x.Cle));
                return Ecran.Normaliser(Nom) + "|" + P1 + "|" + Moy + (Offres != null ? "|" + string.Join(",", Offres) : "") + (Ok ? "" : "|?");
            }
        }
    }

    /// <summary>
    /// Lit la liste des offres de l'Hôtel de vente de Wakfu (onglet « Rechercher », sous-onglet « Objets mis en vente ») :
    /// l'en-tête « Nom · Niv. · Enchantement · Quantité · Prix » donne les colonnes, puis chaque ligne est une offre.
    /// Pour chaque objet, on garde le prix à l'unité le moins cher, les 5 offres les moins chères et la quantité disponible.
    /// Au moindre doute, la lecture est refusée : mieux vaut ne rien enregistrer que d'inventer un prix.
    /// </summary>
    public static class LecteurHdv
    {
        /// <summary>Dans Wakfu, tout se vend à l'unité : un seul « lot ».</summary>
        public static readonly int[] Lots = { 1 };

        static readonly Regex rxHdv = new Regex(@"h[ôo]tel\s*$|^de\s+vente|mis\s+en\s+vente|offres\s+d.achat|mes\s+offres|retirer\s+tous\s+les\s+filtres", RegexOptions.IgnoreCase);
        static readonly Regex rxObjets = new Regex(@"^objets\s+mis\s+en\s+vente", RegexOptions.IgnoreCase);
        static readonly Regex rxOffresAchat = new Regex(@"^offres\s+d.achat", RegexOptions.IgnoreCase);

        /// <summary>
        /// Lit la liste. Si elle n'est pas entièrement lisible, relit l'image agrandie quand une liste est visible ou
        /// quand « insister » est vrai (capture F9 : on sait qu'une liste est censée être à l'écran).
        /// « dejaLues » : le texte de l'image, si l'OCR l'a déjà lu. « zoneConnue » : où était la liste la dernière fois
        /// dans cette fenêtre, pour n'agrandir que là si elle n'est pas repérée.
        /// </summary>
        public static Fiche Lire(Bitmap bmp, bool insister = false, List<LigneOcr> dejaLues = null, RectangleF zoneConnue = default(RectangleF))
        {
            var lignes = dejaLues ?? Ocr.Lire(bmp);
            var f = Analyser(lignes, bmp);
            f.Lignes = lignes;
            if (f.Ok && f.Fiches.All(x => x.Ok)) return f;
            if (!f.Visible && !insister) return f;
            // Deuxième essai avec l'image agrandie : plus lent, mais lit mieux les petits nombres. Quand la liste est
            // repérée (ou sa place connue), seule sa zone est agrandie.
            var zone = new Rectangle(0, 0, bmp.Width, bmp.Height);
            var connue = f.Visible ? f.Zone : zoneConnue;
            if (!connue.IsEmpty)
            {
                var z = Rectangle.Round(RectangleF.Inflate(connue, 20, 20));
                z.Intersect(zone);
                if (z.Width > 50 && z.Height > 50) zone = z;
            }
            using (var morceau = zone.Size == bmp.Size ? null : bmp.Clone(zone, bmp.PixelFormat))
            using (var grand = Ecran.Agrandir(morceau ?? bmp, 2))
            {
                var f2 = Analyser(Ocr.Lire(grand, 2, zone.Location), bmp);   // positions ramenées à l'image d'origine
                f2.Lignes = lignes;
                f2.HdvOuvert |= f.HdvOuvert;
                // On garde la lecture qui a le plus d'objets lisibles (à égalité, l'agrandie si elle a lu quelque chose).
                int n1 = f.Toutes == null ? 0 : f.Toutes.Count(x => x.Ok), n2 = f2.Toutes == null ? 0 : f2.Toutes.Count(x => x.Ok);
                if (n2 > n1 || (n2 == n1 && f2.Visible && !f.Visible)) return f2;
                if (n2 == n1 && f2.Ok) return f2;
                return f;
            }
        }

        /// <summary>Montant en kamas écrit en groupes de chiffres (« 321 233 », « 2995 », « 1 952K »). Null si douteux.</summary>
        public static long? Nombre(IEnumerable<string> mots)
        {
            var groupes = new List<string>();
            foreach (string m in mots)
            {
                string t = m.Trim().TrimEnd('*', '✱', ',', '.', ':');
                // Le symbole kamas collé au nombre est parfois lu « K » (« 1952K »).
                if (t.Length > 1 && (t.EndsWith("K") || t.EndsWith("k")) && char.IsDigit(t[t.Length - 2])) t = t.Substring(0, t.Length - 1);
                if (t.Length == 0 || !t.All(char.IsDigit)) break;
                groupes.Add(t);
                if (t != m.Trim()) break;
            }
            if (groupes.Count == 0) return null;
            if (groupes.Count > 1)
            {
                if (groupes[0].Length > 3) return null;
                for (int i = 1; i < groupes.Count; i++) if (groupes[i].Length != 3) return null;
            }
            long v;
            return long.TryParse(string.Concat(groupes), out v) && v > 0 ? v : (long?)null;
        }

        static bool Numerique(string t)
        {
            t = t.Trim().TrimEnd('*', '✱');
            return t.Length > 0 && t.All(char.IsDigit);
        }

        /// <summary>Une ligne de la liste : une offre.</summary>
        public class Offre
        {
            public string Nom; public int Niveau; public long? Quantite, Prix;
            public double Y, H; public List<MotOcr> MotsPrix, Nombres; public RectangleF ZonePrix;
        }

        /// <summary>Luminosité moyenne d'un petit carré de l'image (0 si hors de l'image).</summary>
        static double Clarte(Bitmap b, double x, double y)
        {
            int n = 0; double s = 0;
            for (int dy = -2; dy <= 2; dy++)
                for (int dx = -2; dx <= 2; dx++)
                {
                    int px = (int)x + dx, py = (int)y + dy;
                    if (px < 0 || py < 0 || px >= b.Width || py >= b.Height) continue;
                    var c = b.GetPixel(px, py);
                    s += c.R + c.G + c.B; n++;
                }
            return n == 0 ? 0 : s / n;
        }

        /// <summary>« image » (facultative) : l'image d'origine, pour vérifier l'onglet actif et relire les cases illisibles.</summary>
        public static Fiche Analyser(List<LigneOcr> lignes, Bitmap image = null)
        {
            var f = new Fiche();
            var mots = lignes.SelectMany(l => l.Mots).ToList();
            f.HdvOuvert = lignes.Any(l => rxHdv.IsMatch(l.Texte.Trim()));

            // 1. L'en-tête du tableau : « Nom », puis « Niv. », « Quantité » et « Prix » à la même hauteur (« Enchantement » facultatif).
            MotOcr nom = null, niv = null, ench = null, quant = null, prix = null;
            foreach (var n in mots.Where(m => m.T == "Nom" || m.T == "Norn").OrderBy(m => m.Y))
            {
                double tol = Math.Max(4, n.H * 0.8);
                var bande = mots.Where(m => m != n && Math.Abs(m.CentreY - n.CentreY) < tol && m.X > n.X).OrderBy(m => m.X).ToList();
                var vNiv = bande.FirstOrDefault(m => m.T.StartsWith("Niv", StringComparison.OrdinalIgnoreCase));
                var vQ = bande.FirstOrDefault(m => m.T.StartsWith("Quantit", StringComparison.OrdinalIgnoreCase));
                var vP = bande.FirstOrDefault(m => m.T.StartsWith("Prix", StringComparison.OrdinalIgnoreCase));
                if (vNiv == null || vQ == null || vP == null || !(vNiv.X < vQ.X && vQ.X < vP.X)) continue;
                nom = n; niv = vNiv; quant = vQ; prix = vP;
                ench = bande.FirstOrDefault(m => m.T.StartsWith("Enchant", StringComparison.OrdinalIgnoreCase) && m.X > vNiv.X && m.X < vQ.X);
                break;
            }
            if (nom == null) { f.Raison = "aucune liste d'offres à l'écran"; return f; }
            f.Visible = true;
            f.HdvOuvert = true;
            double u = Math.Max(6, new[] { nom.H, niv.H, quant.H, prix.H }.OrderBy(h => h).ElementAt(1));

            // 2. Le sous-onglet actif : « Objets mis en vente » (fond clair) ou « Offres d'achat » (demandes d'achat : pas des prix de vente).
            var lObjets = lignes.FirstOrDefault(l => rxObjets.IsMatch(l.Texte.Trim()) && l.Y < nom.Y);
            var lAchat = lignes.FirstOrDefault(l => rxOffresAchat.IsMatch(l.Texte.Trim()) && l.Y < nom.Y);
            if (image != null && lObjets != null && lAchat != null)
            {
                double cObjets = Clarte(image, lObjets.X - 0.8 * u, lObjets.CentreY) + Clarte(image, lObjets.X + lObjets.L + 0.8 * u, lObjets.CentreY);
                double cAchat = Clarte(image, lAchat.X - 0.8 * u, lAchat.CentreY) + Clarte(image, lAchat.X + lAchat.L + 0.8 * u, lAchat.CentreY);
                if (cAchat > cObjets + 60) { f.Visible = false; f.Raison = "onglet « Offres d'achat » ouvert : ce sont des demandes d'achat, pas des prix de vente"; return f; }
            }

            // 3. Les colonnes, d'après la place des titres.
            double cNiv = niv.X + niv.L / 2, cQ = quant.X + quant.L / 2, cP = prix.X + prix.L / 2;
            double bNom = niv.X - 1.5 * u;                                  // fin de la colonne du nom
            double bNiv = ench != null ? (cNiv + ench.X + ench.L / 2) / 2 : cNiv + 5 * u;
            double bQ = cQ - (cP - cQ) / 2;                                 // début de la colonne quantité
            double bP = (cQ + cP) / 2;                                      // début de la colonne prix
            double finP = prix.X + prix.L + 6 * u;                          // le bouton d'achat est juste après le prix
            double gauche = nom.X - 1.5 * u;

            // 4. Les lignes : les mots sous l'en-tête, regroupés par hauteur.
            var sous = mots.Where(m => m.CentreY > nom.CentreY + 1.2 * u && m.X >= gauche && m.X < finP).OrderBy(m => m.CentreY).ToList();
            var bandes = new List<List<MotOcr>>();
            foreach (var m in sous)
            {
                var b = bandes.LastOrDefault();
                if (b != null && Math.Abs(b.Average(x => x.CentreY) - m.CentreY) < 0.7 * u) b.Add(m); else bandes.Add(new List<MotOcr> { m });
            }
            var offres = new List<Offre>();
            foreach (var b in bandes)
            {
                var tri = b.OrderBy(m => m.X).ToList();
                // Le nom : les mots de la première colonne, sans le nombre du badge de l'icône (« 113 » collé à l'image).
                var mNom = tri.Where(m => m.X < bNom).ToList();
                while (mNom.Count > 0 && Numerique(mNom[0].T)) mNom.RemoveAt(0);
                string texte = string.Join(" ", mNom.Select(m => m.T)).Trim();
                if (texte.Length < 2 || !texte.Any(char.IsLetter)) continue;
                if (Regex.IsMatch(texte, @"^(page|objets?)\b", RegexOptions.IgnoreCase)) continue;
                var o = new Offre { Nom = texte, Y = tri.Min(m => m.Y), H = tri.Max(m => m.H) };
                var vNiv = Nombre(tri.Where(m => m.X >= bNom && m.X < bNiv).Select(m => m.T));
                if (vNiv.HasValue && vNiv.Value <= 245) o.Niveau = (int)vNiv.Value;
                o.Quantite = Nombre(tri.Where(m => m.X >= bQ && m.X < bP).Select(m => m.T));
                o.MotsPrix = tri.Where(m => m.X >= bP).ToList();
                o.Prix = Nombre(o.MotsPrix.Select(m => m.T));
                o.Nombres = tri.Where(m => m.X >= bNom && Numerique(m.T)).ToList();   // niveau, quantité, prix : même police
                double cy = b.Average(x => x.CentreY);
                o.ZonePrix = RectangleF.FromLTRB((float)bP, (float)(cy - 0.9 * u), (float)(prix.X + prix.L + 0.5 * u), (float)(cy + 0.9 * u));
                offres.Add(o);
            }
            if (offres.Count == 0) { f.Visible = false; f.Raison = "aucune offre affichée"; return f; }
            f.Zone = RectangleF.FromLTRB((float)gauche, (float)(nom.Y - u), (float)finP, (float)(offres.Max(o => o.Y + o.H) + u));

            // 5. Les prix que l'OCR n'a pas lus (souvent un seul chiffre : « 3 ») : relus autrement, à côté d'autres nombres de la liste.
            if (image != null && offres.Any(o => o.Prix == null))
            {
                // D'abord les prix lisibles des autres lignes, sinon n'importe quel nombre de la liste (niveau, quantité) : même police.
                var voisins = offres.Where(o => o.Prix != null).SelectMany(o => o.MotsPrix.Where(m => Numerique(m.T)))
                    .Concat(offres.SelectMany(o => o.Nombres).OrderByDescending(m => m.T.Length)).Distinct().ToList();
                foreach (var o in offres.Where(o => o.Prix == null))
                {
                    o.Prix = Relecture.Prix(image, o.ZonePrix, u, voisins, Nombre);
                    if (o.Prix != null) f.Relu++;
                }
            }

            // 6. Une fiche par objet : prix le moins cher, offres les moins chères, quantité totale.
            f.Toutes = new List<Fiche>();
            foreach (var g in offres.GroupBy(o => Ecran.Normaliser(o.Nom)))
            {
                var liste = g.ToList();
                var fiche = new Fiche
                {
                    Visible = true, HdvOuvert = true,
                    Nom = liste.GroupBy(o => o.Nom).OrderByDescending(x => x.Count()).First().Key,
                    Niveau = liste.Select(o => o.Niveau).FirstOrDefault(n => n > 0)
                };
                if (liste.Any(o => o.Prix == null)) { fiche.Raison = "un prix est illisible"; f.Toutes.Add(fiche); continue; }
                var prixTries = liste.Select(o => o.Prix.Value).OrderBy(p => p).ToList();
                fiche.P1 = prixTries[0];
                if (prixTries.Count > 1) fiche.Offres = prixTries.Take(5).ToList();
                var quantites = liste.Where(o => o.Quantite.HasValue).Select(o => o.Quantite.Value).ToList();
                if (quantites.Count > 0) fiche.Quantite = quantites.Sum();
                fiche.Ok = true;
                f.Toutes.Add(fiche);
            }
            var premiere = f.Toutes.FirstOrDefault(x => x.Ok) ?? f.Toutes[0];
            f.Nom = premiere.Nom; f.Niveau = premiere.Niveau; f.P1 = premiere.P1; f.Offres = premiere.Offres; f.Quantite = premiere.Quantite;
            f.Ok = premiere.Ok;
            f.Raison = f.Ok ? "" : premiere.Raison;
            return f;
        }
    }
}
