using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace SuiviHdvWakfu
{
    /// <summary>Couleurs et polices du Suivi HDV Wakfu : le turquoise de Wakfu sur fond bleu nuit, comme le Compteur Wakfu.</summary>
    public static class Theme
    {
        public static float Dpi = 1f;
        public static int S(int v) { return (int)Math.Round(v * Dpi); }
        public static float Sf(float v) { return v * Dpi; }

        public static readonly Color Bg = Color.FromArgb(9, 22, 33);
        public static readonly Color Card = Color.FromArgb(17, 37, 53);
        public static readonly Color Card2 = Color.FromArgb(25, 51, 70);
        public static readonly Color Hover = Color.FromArgb(33, 63, 85);
        public static readonly Color Border = Color.FromArgb(38, 82, 106);
        public static readonly Color Text = Color.FromArgb(234, 242, 246);
        public static readonly Color Dim = Color.FromArgb(150, 178, 192);
        public static readonly Color Faint = Color.FromArgb(94, 124, 140);
        public static readonly Color Accent = Color.FromArgb(52, 196, 222);       // turquoise Wakfu
        public static readonly Color OnAccent = Color.FromArgb(7, 28, 40);
        public static readonly Color Clair = Color.FromArgb(150, 232, 245);
        public static readonly Color Nuit = Color.FromArgb(12, 30, 46);           // creux des jauges, champs
        public static readonly Color Bandeau = Color.FromArgb(18, 96, 124);       // fin du dégradé du bandeau
        public static readonly Color Kamas = Color.FromArgb(246, 208, 72);
        public static readonly Color Green = Color.FromArgb(62, 212, 140);
        public static readonly Color Red = Color.FromArgb(239, 92, 92);

        // Couleurs des courbes, une par taille de lot (toujours la même pour un lot donné).
        public static readonly Color[] Series = {
            Color.FromArgb(52, 196, 222),   // x1 (turquoise)
            Color.FromArgb(255, 170, 60),   // x10
            Color.FromArgb(62, 212, 140),   // x100
            Color.FromArgb(201, 133, 0),    // x1000
            Color.FromArgb(213, 81, 129),   // prix moyen
        };

        // Glyphes Segoe MDL2 Assets
        public const string GFermer = "", GRetour = "", GCamera = "", GDossier = "",
            GRecherche = "", GWeb = "", GSon = "", GMuet = "", GPin = "", GUnpin = "", GCalcul = "";

        static readonly Dictionary<string, Font> polices = new Dictionary<string, Font>();

        public static Font F(float taille, bool gras = false)
        {
            string cle = (gras ? "b" : "r") + taille;
            Font f;
            if (!polices.TryGetValue(cle, out f))
            {
                f = new Font(gras ? "Segoe UI Semibold" : "Segoe UI", taille);
                polices[cle] = f;
            }
            return f;
        }

        public static Font Icones(float taille)
        {
            string cle = "i" + taille;
            Font f;
            if (!polices.TryGetValue(cle, out f))
            {
                f = new Font("Segoe MDL2 Assets", taille);
                polices[cle] = f;
            }
            return f;
        }

        public static GraphicsPath Arrondi(RectangleF r, float rayon)
        {
            var p = new GraphicsPath();
            float d = Math.Min(rayon * 2, Math.Min(r.Width, r.Height));
            if (d <= 0.5f) { p.AddRectangle(r); return p; }
            p.AddArc(r.X, r.Y, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }

        public static void Remplir(Graphics g, Color c, RectangleF r, float rayon)
        {
            if (r.Width <= 0 || r.Height <= 0) return;
            using (var b = new SolidBrush(c))
            using (var p = Arrondi(r, rayon))
                g.FillPath(b, p);
        }

        public static void Contour(Graphics g, Color c, RectangleF r, float rayon)
        {
            if (r.Width <= 0 || r.Height <= 0) return;
            using (var pen = new Pen(c, 1f))
            using (var p = Arrondi(r, rayon))
                g.DrawPath(pen, p);
        }

        public static Color Mix(Color a, Color b, float t)
        {
            return Color.FromArgb(
                (int)(a.A + (b.A - a.A) * t), (int)(a.R + (b.R - a.R) * t),
                (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
        }
    }
}
