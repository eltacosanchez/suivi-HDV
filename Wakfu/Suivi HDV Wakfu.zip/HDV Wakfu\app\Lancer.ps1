# Lance Suivi HDV Wakfu : compile le code source (src\*.cs) en mémoire puis ouvre la fenêtre.
# Comme pour le Compteur Wakfu, passer par PowerShell évite que Windows bloque un .exe non signé.
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$racine = Split-Path -Parent $dir
try {
    New-Item -ItemType Directory -Force (Join-Path $racine 'donnees') | Out-Null
    $src = Get-ChildItem (Join-Path $dir 'src') -Filter *.cs | ForEach-Object { $_.FullName }
    Add-Type -Path $src -ReferencedAssemblies System.Windows.Forms, System.Drawing, System.Core, System.Web.Extensions, System.IO.Compression, System.IO.Compression.FileSystem
    [SuiviHdvWakfu.Program]::Run($racine)
}
catch {
    # L'erreur est aussi notée dans donnees\erreurs.log, pour pouvoir la retrouver après avoir fermé le message.
    $detail = $_.Exception.ToString()
    if ($_.ErrorDetails) { $detail = $_.ErrorDetails.Message + "`n" + $detail }
    try { Add-Content (Join-Path $racine 'donnees\erreurs.log') ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + "  Lancement impossible :`n" + $detail + "`n") -Encoding UTF8 } catch {}
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Impossible de lancer Suivi HDV Wakfu :`n`n" + $_.Exception.Message,
        'Suivi HDV Wakfu', 'OK', 'Error') | Out-Null
}
