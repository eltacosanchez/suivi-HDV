using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace SuiviHdvWakfu
{
    /// <summary>
    /// Icône de l'application : la pastille turquoise « W » du Compteur Wakfu, avec une courbe de prix dorée qui monte
    /// en bas à droite pour la distinguer du compteur. Dessinée (aucune ressource externe).
    /// </summary>
    public static class Icone
    {
        public static Bitmap Rendu(int taille)
        {
            var bmp = new Bitmap(taille, taille, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.Transparent);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = TextRenderingHint.AntiAlias;
                float m = taille * 0.04f;
                var r = new RectangleF(m, m, taille - 2 * m, taille - 2 * m);
                using (var p = Theme.Arrondi(r, taille * 0.22f))
                {
                    using (var br = new LinearGradientBrush(r, Color.FromArgb(150, 236, 248), Color.FromArgb(18, 110, 150), 70f))
                        g.FillPath(br, p);
                    using (var pen = new Pen(Color.FromArgb(10, 52, 74), Math.Max(1f, taille / 22f)))
                        g.DrawPath(pen, p);
                }
                using (var f = new Font("Segoe UI Black", taille * 0.5f, FontStyle.Bold, GraphicsUnit.Pixel))
                using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                {
                    var t = new RectangleF(-taille * 0.08f, -taille * 0.06f, taille, taille);
                    using (var ombre = new SolidBrush(Color.FromArgb(120, 4, 40, 60)))
                        g.DrawString("W", f, ombre, new RectangleF(t.X + taille * 0.03f, t.Y + taille * 0.04f, t.Width, t.Height), sf);
                    g.DrawString("W", f, Brushes.White, t, sf);
                }
                // Courbe de prix dorée, en bas à droite.
                float b = r.Bottom - taille * 0.14f;
                var pts = new[] {
                    new PointF(r.X + taille * 0.44f, b), new PointF(r.X + taille * 0.58f, b - taille * 0.12f),
                    new PointF(r.X + taille * 0.70f, b - taille * 0.06f), new PointF(r.X + taille * 0.86f, b - taille * 0.26f) };
                using (var pen = new Pen(Color.FromArgb(255, 222, 120), Math.Max(1.4f, taille * 0.075f)) { LineJoin = LineJoin.Round, StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawLines(pen, pts);
                float rp = Math.Max(1.5f, taille * 0.065f);
                using (var br = new SolidBrush(Color.White)) g.FillEllipse(br, pts[3].X - rp, pts[3].Y - rp, 2 * rp, 2 * rp);
            }
            return bmp;
        }

        public static Icon Charger(string fichier, int taille)
        {
            try { if (File.Exists(fichier)) return new Icon(fichier, taille, taille); } catch { }
            return Icon.FromHandle(Rendu(taille).GetHicon());
        }

        /// <summary>Écrit le fichier .ico (tailles 16 à 256), utilisé par le raccourci.</summary>
        public static void Ecrire(string sortie)
        {
            int[] tailles = { 16, 20, 24, 32, 40, 48, 64, 256 };
            var images = new List<byte[]>();
            foreach (int s in tailles)
                using (var bmp = Rendu(s))
                    images.Add(s >= 256 ? Png(bmp) : Dib(bmp));

            using (var fs = File.Create(sortie))
            using (var w = new BinaryWriter(fs))
            {
                w.Write((short)0); w.Write((short)1); w.Write((short)tailles.Length);
                int decalage = 6 + 16 * tailles.Length;
                for (int i = 0; i < tailles.Length; i++)
                {
                    int s = tailles[i];
                    w.Write((byte)(s >= 256 ? 0 : s)); w.Write((byte)(s >= 256 ? 0 : s));
                    w.Write((byte)0); w.Write((byte)0);
                    w.Write((short)1); w.Write((short)32);
                    w.Write(images[i].Length); w.Write(decalage);
                    decalage += images[i].Length;
                }
                foreach (var img in images) w.Write(img);
            }
        }

        static byte[] Png(Bitmap bmp)
        {
            using (var ms = new MemoryStream()) { bmp.Save(ms, ImageFormat.Png); return ms.ToArray(); }
        }

        static byte[] Dib(Bitmap bmp)
        {
            int s = bmp.Width;
            int ligneMasque = ((s + 31) / 32) * 4;
            using (var ms = new MemoryStream())
            using (var w = new BinaryWriter(ms))
            {
                w.Write(40); w.Write(s); w.Write(s * 2); w.Write((short)1); w.Write((short)32);
                w.Write(0); w.Write(s * s * 4 + ligneMasque * s); w.Write(0); w.Write(0); w.Write(0); w.Write(0);
                var d = bmp.LockBits(new Rectangle(0, 0, s, s), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
                var ligne = new byte[s * 4];
                for (int y = s - 1; y >= 0; y--)
                {
                    Marshal.Copy(d.Scan0 + y * d.Stride, ligne, 0, ligne.Length);
                    w.Write(ligne);
                }
                bmp.UnlockBits(d);
                w.Write(new byte[ligneMasque * s]);
                return ms.ToArray();
            }
        }
    }
}
