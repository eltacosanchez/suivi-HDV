using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SuiviHdvWakfu
{
    public class FenetreWakfu { public IntPtr Hwnd; public string Perso; }

    /// <summary>Fenêtres Wakfu : liste et capture (même méthode que le Compteur Wakfu), plus quelques outils de texte.</summary>
    public static class Ecran
    {
        delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc cb, IntPtr l);
        [DllImport("user32.dll")] static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] static extern IntPtr GetWindow(IntPtr h, uint cmd);
        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
        [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }

        // Wakfu est un programme Java : fenêtre « SunAwtFrame », titre « Perso - WAKFU » (juste « WAKFU » à la connexion).
        static readonly Regex titre = new Regex(@"^(?<name>.+?) - WAKFU$");

        static FenetreWakfu Identifier(IntPtr h)
        {
            if (h == IntPtr.Zero) return null;
            var sb = new StringBuilder(256);
            GetClassName(h, sb, sb.Capacity);
            if (sb.ToString() != "SunAwtFrame") return null;
            var t = new StringBuilder(512);
            GetWindowText(h, t, t.Capacity);
            var m = titre.Match(t.ToString());
            if (!m.Success) return null;
            return new FenetreWakfu { Hwnd = h, Perso = m.Groups["name"].Value.Trim() };
        }

        public static List<FenetreWakfu> Fenetres()
        {
            var liste = new List<FenetreWakfu>();
            EnumWindows(delegate (IntPtr h, IntPtr l)
            {
                if (!IsWindowVisible(h) || GetWindow(h, 4) != IntPtr.Zero) return true;
                var f = Identifier(h);
                if (f != null) liste.Add(f);
                return true;
            }, IntPtr.Zero);
            return liste;
        }

        /// <summary>La fenêtre Wakfu au premier plan, ou null.</summary>
        public static FenetreWakfu WakfuAuPremierPlan()
        {
            return Identifier(GetForegroundWindow());
        }

        // Capture le contenu de la fenêtre même si une autre fenêtre est par-dessus (mais pas si elle est réduite).
        public static Bitmap Capturer(IntPtr h)
        {
            Bitmap b = null;
            var res = Capturer(h, ref b);
            if (res == null && b != null) b.Dispose();
            return res;
        }

        /// <summary>
        /// Même chose en réutilisant l'image du tour précédent quand la fenêtre n'a pas changé de taille : pas de nouvelle
        /// image de plusieurs Mo à chaque seconde. L'image rendue est « reutilisable » (à ne pas libérer), ou null si la
        /// capture a échoué.
        /// </summary>
        public static Bitmap Capturer(IntPtr h, ref Bitmap reutilisable)
        {
            if (IsIconic(h)) return null;
            RECT r;
            if (!GetClientRect(h, out r)) return null;
            int w = r.Right - r.Left, ht = r.Bottom - r.Top;
            if (w < 300 || ht < 200) return null;
            if (reutilisable == null || reutilisable.Width != w || reutilisable.Height != ht)
            {
                if (reutilisable != null) reutilisable.Dispose();
                reutilisable = new Bitmap(w, ht, PixelFormat.Format32bppArgb);
            }
            var bmp = reutilisable;
            bool ok;
            using (var g = Graphics.FromImage(bmp))
            {
                IntPtr hdc = g.GetHdc();
                ok = PrintWindow(h, hdc, 3); // PW_CLIENTONLY | PW_RENDERFULLCONTENT
                g.ReleaseHdc(hdc);
            }
            return ok && !Noire(bmp) ? bmp : null;
        }

        /// <summary>Capture pour F9 : la fenêtre Wakfu au premier plan, sinon la fenêtre active, sinon l'écran principal.</summary>
        public static Bitmap CapturerPremierPlan()
        {
            var d = WakfuAuPremierPlan();
            if (d != null)
            {
                var b = Capturer(d.Hwnd);
                if (b != null) return b;
            }
            Rectangle zone = Screen.PrimaryScreen.Bounds;
            RECT r;
            if (GetWindowRect(GetForegroundWindow(), out r))
            {
                var f = Rectangle.FromLTRB(r.Left, r.Top, r.Right, r.Bottom);
                f.Intersect(SystemInformation.VirtualScreen);
                if (f.Width >= 400 && f.Height >= 300) zone = f;
            }
            var bmp = new Bitmap(zone.Width, zone.Height, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(bmp)) g.CopyFromScreen(zone.Location, Point.Empty, zone.Size);
            return bmp;
        }

        static bool Noire(Bitmap b)
        {
            for (int y = 0; y < b.Height; y += b.Height / 12 + 1)
                for (int x = 0; x < b.Width; x += b.Width / 12 + 1)
                {
                    Color c = b.GetPixel(x, y);
                    if (c.R + c.G + c.B > 30) return false;
                }
            return true;
        }

        /// <summary>Copie agrandie (l'OCR de Windows rate parfois les nombres d'un seul chiffre en petit).</summary>
        public static Bitmap Agrandir(Bitmap src, double echelle)
        {
            int w = Math.Min(9999, (int)(src.Width * echelle)), h = Math.Min(9999, (int)(src.Height * echelle));
            var dst = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            using (var g = Graphics.FromImage(dst))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(src, new Rectangle(0, 0, w, h), 0, 0, src.Width, src.Height, GraphicsUnit.Pixel);
            }
            return dst;
        }

        /// <summary>Nom simplifié pour comparer : sans accents, majuscules, espaces ni ponctuation.</summary>
        public static string Normaliser(string s)
        {
            var sb = new StringBuilder();
            foreach (char ch in (s ?? "").Normalize(NormalizationForm.FormD))
            {
                if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue;
                if (char.IsLetterOrDigit(ch)) sb.Append(char.ToLowerInvariant(ch));
            }
            return sb.ToString();
        }

        public static int Distance(string a, string b)
        {
            var p = new int[b.Length + 1];
            var c = new int[b.Length + 1];
            for (int j = 0; j <= b.Length; j++) p[j] = j;
            for (int i = 1; i <= a.Length; i++)
            {
                c[0] = i;
                for (int j = 1; j <= b.Length; j++)
                    c[j] = Math.Min(Math.Min(c[j - 1] + 1, p[j] + 1), p[j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
                var t = p; p = c; c = t;
            }
            return p[b.Length];
        }
    }
}
