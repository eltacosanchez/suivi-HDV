using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace SuiviHdvWakfu
{
    /// <summary>
    /// Miniatures des captures en attente. Clic : choisir / ne plus choisir ; double-clic : ouvrir l'image en grand.
    /// Les captures déjà envoyées à Claude sont grisées en attendant sa réponse.
    /// </summary>
    public class Galerie : Surface
    {
        public List<string> Fichiers = new List<string>();
        public readonly HashSet<string> Choisis = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public readonly HashSet<string> Envoyes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        public string Vide = "";
        public event Action Change;
        public event Action<string> Agrandir;

        readonly Dictionary<string, Image> miniatures = new Dictionary<string, Image>(StringComparer.OrdinalIgnoreCase);
        List<RectangleF> cases = new List<RectangleF>();
        int decalage, survol = -1;

        public Galerie() { BackColor = Theme.Bg; }

        public void Remplir(List<string> fichiers)
        {
            Fichiers = fichiers;
            Choisis.IntersectWith(fichiers);
            Envoyes.IntersectWith(fichiers);
            foreach (var k in miniatures.Keys.Where(k => !fichiers.Contains(k, StringComparer.OrdinalIgnoreCase)).ToList())
            {
                if (miniatures[k] != null) miniatures[k].Dispose();
                miniatures.Remove(k);
            }
            Invalidate();
        }

        Image Miniature(string f)
        {
            Image img;
            if (miniatures.TryGetValue(f, out img)) return img;
            try
            {
                using (var ms = new MemoryStream(File.ReadAllBytes(f)))
                using (var src = Image.FromStream(ms))
                {
                    double e = Math.Min(1.0, Math.Min(Theme.S(420) / (double)src.Width, Theme.S(320) / (double)src.Height));
                    var b = new Bitmap(Math.Max(1, (int)(src.Width * e)), Math.Max(1, (int)(src.Height * e)));
                    using (var g = Graphics.FromImage(b)) { g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.DrawImage(src, 0, 0, b.Width, b.Height); }
                    img = b;
                }
            }
            catch { img = null; }
            miniatures[f] = img;
            return img;
        }

        static string Legende(string f)
        {
            var m = Regex.Match(Path.GetFileName(f), @"(\d{4}-\d{2}-\d{2})_(\d{2})-(\d{2})-(\d{2})");
            DateTime t;
            string quand = m.Success && DateTime.TryParseExact(m.Groups[1].Value + " " + m.Groups[2].Value + ":" + m.Groups[3].Value, "yyyy-MM-dd HH:mm",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out t) ? Calculs.Date(t) : Path.GetFileNameWithoutExtension(f);
            string nom = Moteur.NomDansFichier(f);
            return (nom != null ? nom + " · " : "") + quand + (f.IndexOf("_auto", StringComparison.OrdinalIgnoreCase) >= 0 ? "" : " · capture F9");
        }

        void Disposer()
        {
            cases = new List<RectangleF>();
            float lc = Theme.Sf(250), hc = Theme.Sf(230), gap = Theme.Sf(12);
            int parLigne = Math.Max(1, (int)((Width + gap) / (lc + gap)));
            lc = (Width - gap * (parLigne - 1)) / parLigne;
            for (int i = 0; i < Fichiers.Count; i++)
                cases.Add(new RectangleF((i % parLigne) * (lc + gap), (i / parLigne) * (hc + gap) - decalage, lc, hc));
        }

        int HTotal { get { return cases.Count == 0 ? 0 : (int)(cases.Max(c => c.Bottom) + decalage); } }

        int Sous(Point p)
        {
            for (int i = 0; i < cases.Count; i++) if (cases[i].Contains(p)) return i;
            return -1;
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            decalage = Math.Max(0, Math.Min(Math.Max(0, HTotal - Height), decalage - Math.Sign(e.Delta) * Theme.S(120)));
            Invalidate();
            base.OnMouseWheel(e);
        }

        protected override void OnMouseEnter(EventArgs e) { Focus(); base.OnMouseEnter(e); }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            int s = Sous(e.Location);
            if (s != survol) { survol = s; Invalidate(); }
            Cursor = s >= 0 ? Cursors.Hand : Cursors.Default;
            base.OnMouseMove(e);
        }

        protected override void OnMouseLeave(EventArgs e) { survol = -1; Invalidate(); base.OnMouseLeave(e); }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            int s = Sous(e.Location);
            if (s >= 0 && !Envoyes.Contains(Fichiers[s]))
            {
                if (!Choisis.Remove(Fichiers[s])) Choisis.Add(Fichiers[s]);
                Invalidate();
                var c = Change; if (c != null) c();
            }
            base.OnMouseClick(e);
        }

        protected override void OnMouseDoubleClick(MouseEventArgs e)
        {
            int s = Sous(e.Location);
            if (s >= 0)
            {
                // Le double-clic ne doit pas changer la sélection : on annule le second clic.
                if (!Envoyes.Contains(Fichiers[s])) { if (!Choisis.Remove(Fichiers[s])) Choisis.Add(Fichiers[s]); var c = Change; if (c != null) c(); }
                var a = Agrandir; if (a != null) a(Fichiers[s]);
            }
            base.OnMouseDoubleClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            const TextFormatFlags f = TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter;
            Disposer();
            if (Fichiers.Count == 0)
            {
                TextRenderer.DrawText(g, Vide, Theme.F(9.5f), new Rectangle(0, Theme.S(30), Width, Theme.S(60)), Theme.Faint,
                    TextFormatFlags.NoPrefix | TextFormatFlags.WordBreak | TextFormatFlags.HorizontalCenter);
                return;
            }
            for (int i = 0; i < cases.Count; i++)
            {
                var r = cases[i];
                if (r.Bottom < 0 || r.Top > Height) continue;
                string fi = Fichiers[i];
                bool choisi = Choisis.Contains(fi), envoye = Envoyes.Contains(fi);
                Theme.Remplir(g, i == survol && !envoye ? Theme.Hover : Theme.Card, r, Theme.Sf(10));
                var zi = new RectangleF(r.X + Theme.Sf(8), r.Y + Theme.Sf(8), r.Width - Theme.Sf(16), r.Height - Theme.Sf(48));
                var img = Miniature(fi);
                if (img != null)
                {
                    float e2 = Math.Min(zi.Width / img.Width, zi.Height / img.Height);
                    var zd = new RectangleF(zi.X + (zi.Width - img.Width * e2) / 2, zi.Y + (zi.Height - img.Height * e2) / 2, img.Width * e2, img.Height * e2);
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.DrawImage(img, zd);
                    if (envoye) using (var voile = new SolidBrush(Color.FromArgb(170, Theme.Card))) g.FillRectangle(voile, zd);
                }
                string bas = envoye ? "Claude lit cette capture…" : Legende(fi);
                TextRenderer.DrawText(g, bas, Theme.F(8.5f, choisi), new Rectangle((int)r.X + Theme.S(40), (int)r.Bottom - Theme.S(38), (int)r.Width - Theme.S(48), Theme.S(30)),
                    envoye ? Theme.Accent : choisi ? Theme.Text : Theme.Dim, f);
                // Case à cocher.
                var cc = new RectangleF(r.X + Theme.Sf(12), r.Bottom - Theme.Sf(32), Theme.Sf(20), Theme.Sf(20));
                if (choisi)
                {
                    Theme.Remplir(g, Theme.Accent, cc, Theme.Sf(5));
                    using (var pen = new Pen(Theme.OnAccent, Theme.Sf(2.2f)) { StartCap = LineCap.Round, EndCap = LineCap.Round, LineJoin = LineJoin.Round })
                        g.DrawLines(pen, new[] { new PointF(cc.X + cc.Width * 0.25f, cc.Y + cc.Height * 0.52f), new PointF(cc.X + cc.Width * 0.43f, cc.Y + cc.Height * 0.7f), new PointF(cc.X + cc.Width * 0.76f, cc.Y + cc.Height * 0.32f) });
                }
                else if (!envoye) Theme.Contour(g, Theme.Faint, cc, Theme.Sf(5));
                if (choisi)
                    using (var pen = new Pen(Theme.Accent, Theme.Sf(2))) using (var p = Theme.Arrondi(RectangleF.Inflate(r, -1, -1), Theme.Sf(10))) g.DrawPath(pen, p);
            }
            if (HTotal > Height)
            {
                float lg = Math.Max(Theme.S(24), Height * (float)Height / HTotal);
                float pos = (Height - lg) * decalage / Math.Max(1, HTotal - Height);
                Theme.Remplir(g, Theme.Border, new RectangleF(Width - Theme.S(4), pos, Theme.S(3), lg), Theme.Sf(1.5f));
            }
        }
    }
}
