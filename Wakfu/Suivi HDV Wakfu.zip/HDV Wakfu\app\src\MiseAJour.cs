using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;

namespace SuiviHdvWakfu
{
    /// <summary>
    /// Mises à jour depuis GitHub (même principe que le Compteur XP) : le dépôt contient « version.txt » (le numéro de
    /// la dernière version) et « Suivi HDV Wakfu.zip » (le programme). Au démarrage, le Suivi HDV Wakfu compare les numéros ; si une
    /// version plus récente existe, il propose de l'installer : seul le programme est remplacé, les relevés restent.
    /// </summary>
    public class MiseAJour
    {
        public const string Depot = "eltacosanchez/suivi-HDV";

        /// <summary>Où lire version.txt et Suivi HDV Wakfu.zip (modifiable pour les tests : un dossier en file:///).</summary>
        public static string Adresse = "https://raw.githubusercontent.com/" + Depot + "/main/Wakfu/";   // rangé dans le dossier Wakfu du dépôt du Suivi HDV

        // Paramètre anti-cache pour GitHub (inutile, et gênant, pour un fichier local).
        static string Frais() { return Adresse.StartsWith("http") ? "?t=" + DateTime.UtcNow.Ticks : ""; }

        readonly string dossier;
        public readonly string Locale;
        public string Distante { get; private set; }

        public MiseAJour(string dossierHdv, string versionLocale)
        {
            dossier = dossierHdv;
            Locale = versionLocale;
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; } catch { }
        }

        /// <summary>
        /// Le dossier de développement (avec ses outils) ne se met jamais à jour tout seul : c'est lui qui sert à
        /// fabriquer les versions envoyées sur GitHub.
        /// </summary>
        public bool Active { get { return !Directory.Exists(Path.Combine(dossier, "outils")); } }

        static WebClient Client()
        {
            var wc = new WebClient { Encoding = Encoding.UTF8 };
            wc.Headers[HttpRequestHeader.UserAgent] = "SuiviHdvWakfu";
            wc.Headers[HttpRequestHeader.CacheControl] = "no-cache";
            return wc;
        }

        /// <summary>Numéro de la dernière version publiée, ou null si GitHub ne répond pas.</summary>
        public string Verifier()
        {
            try
            {
                using (var wc = Client())
                    Distante = wc.DownloadString(Adresse + "version.txt" + Frais()).Trim();
            }
            catch { Distante = null; }
            return Distante;
        }

        public bool Disponible { get { return Distante != null && PlusRecente(Distante, Locale); } }

        /// <summary>« 1.10 » est plus récent que « 1.9 » : on compare chaque nombre.</summary>
        public static bool PlusRecente(string a, string b)
        {
            var pa = (a ?? "").Split('.').Select(x => { int n; return int.TryParse(x.Trim(), out n) ? n : 0; }).ToArray();
            var pb = (b ?? "").Split('.').Select(x => { int n; return int.TryParse(x.Trim(), out n) ? n : 0; }).ToArray();
            for (int i = 0; i < Math.Max(pa.Length, pb.Length); i++)
            {
                int x = i < pa.Length ? pa[i] : 0, y = i < pb.Length ? pb[i] : 0;
                if (x != y) return x > y;
            }
            return false;
        }

        /// <summary>Télécharge et installe la nouvelle version. Renvoie le numéro installé (exception si échec).</summary>
        public string Installer()
        {
            string temp = Path.Combine(Path.GetTempPath(), "SuiviHdvWakfu-maj-" + DateTime.Now.Ticks);
            Directory.CreateDirectory(temp);
            try
            {
                string zip = Path.Combine(temp, "maj.zip");
                using (var wc = Client()) wc.DownloadFile(Adresse + "Suivi%20HDV%20Wakfu.zip" + Frais(), zip);
                string extrait = Path.Combine(temp, "x");
                ZipFile.ExtractToDirectory(zip, extrait);

                // Le programme est dans le dossier qui contient « Suivi HDV Wakfu.vbs » et app\src.
                string source = Directory.GetFiles(extrait, "Suivi HDV Wakfu.vbs", SearchOption.AllDirectories)
                    .Select(Path.GetDirectoryName)
                    .FirstOrDefault(d => Directory.Exists(Path.Combine(d, "app", "src")));
                if (source == null) throw new InvalidDataException("le zip de GitHub ne contient pas le programme");
                var nouveaux = Directory.GetFiles(Path.Combine(source, "app", "src"), "*.cs");
                if (nouveaux.Length == 0) throw new InvalidDataException("le zip de GitHub ne contient pas le code du programme");

                // Programme : remplacé en entier. Relevés, réglages, captures et son : jamais touchés.
                string src = Path.Combine(dossier, "app", "src");
                Directory.CreateDirectory(src);
                foreach (var f in Directory.GetFiles(src, "*.cs")) File.Delete(f);
                foreach (var f in nouveaux) File.Copy(f, Path.Combine(src, Path.GetFileName(f)), true);
                foreach (var nom in new[] { @"app\Lancer.ps1", @"app\app.ico", "Suivi HDV Wakfu.vbs", "LISEZ-MOI.txt", "NOUVEAUTES.txt", "version.txt" })
                {
                    string f = Path.Combine(source, nom);
                    if (File.Exists(f)) File.Copy(f, Path.Combine(dossier, nom), true);
                }
                // Icônes des ressources : on ajoute seulement celles qui manquent.
                string icones = Path.Combine(source, "donnees", "icones"), mesIcones = Path.Combine(dossier, "donnees", "icones");
                if (Directory.Exists(icones))
                {
                    Directory.CreateDirectory(mesIcones);
                    foreach (var f in Directory.GetFiles(icones, "*.png"))
                    {
                        string d = Path.Combine(mesIcones, Path.GetFileName(f));
                        if (!File.Exists(d)) File.Copy(f, d);
                    }
                }
                string v = Path.Combine(dossier, "version.txt");
                return File.Exists(v) ? File.ReadAllText(v).Trim() : Distante;
            }
            finally
            {
                try { Directory.Delete(temp, true); } catch { }
            }
        }
    }
}
