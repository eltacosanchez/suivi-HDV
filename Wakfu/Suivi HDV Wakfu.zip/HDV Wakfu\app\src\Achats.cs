using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace SuiviHdvWakfu
{
    /// <summary>
    /// Un mouvement de kamas lu dans le chat :
    ///  - un achat à l'HDV : « [23:18] 100 x [Pièce de Koffrefor] (321 223 kamas) » ;
    ///  - une vente à l'HDV : « [23:37] Banque : + 11 Kamas (vente : 1 [Moustache précieuse]). »
    /// </summary>
    public class AchatLu
    {
        public int Heure, Minute;
        public long Quantite, Prix;
        public string Nom;
        public bool Vente;
        /// <summary>Même ressource, même quantité, même prix, même sens (sans l'heure, que l'OCR lit parfois mal).</summary>
        public string Cle { get { return (Vente ? "V|" : "A|") + Ecran.Normaliser(Nom) + "|" + Quantite + "|" + Prix; } }
    }

    /// <summary>
    /// Repère dans le chat les achats et les ventes à l'HDV. L'OCR lit parfois les crochets de l'heure « 1 » ou « ) »
    /// (« 123:181 » pour « [23:18] ») et parfois un 3 pour un 6 (« 23:61 ») : le motif en tient compte, et une heure
    /// impossible est rejetée. Chaque ligne repérée est relue agrandie, plus fiable pour les chiffres.
    /// </summary>
    public static class Achats
    {
        const string Nombre = @"\d{1,3}(?:[\s  ]?\d{3})*";
        const string Heure = @"(?:^|\s)[\[\(1lI|]?\s*(?<h>\d{1,2})\s*[:.;]\s*(?<m>\d{2})\s*[\]\)1lI|]?\s+";
        const string NomObjet = @"[\[\(]?\s*(?<n>[^\[\]()]+?)\s*[\]\)]?";
        static readonly Regex rxAchat = new Regex(Heure + @"(?<q>" + Nombre + @")\s*[xX×]\s*" + NomObjet + @"\s*\(\s*(?<k>" + Nombre + @")\s*kamas?\b");
        static readonly Regex rxVente = new Regex(Heure + @"Banque\s*:\s*\+\s*(?<k>" + Nombre + @")\s*kamas?\s*\(\s*vente\s*:\s*(?<q>" + Nombre + @")\s*" + NomObjet + @"\s*\)", RegexOptions.IgnoreCase);
        // À la connexion : « [00:55] 1 lot vendu. Montant total : 546 Kamas » (ventes faites pendant l'absence).
        static readonly Regex rxResume = new Regex(Heure + @"(?<q>" + Nombre + @")\s*lots?\s*vendus?\W*Montant\s*total\s*:?\s*(?<k>" + Nombre + @")\s*kamas?", RegexOptions.IgnoreCase);
        public const string VentesAbsence = "Ventes pendant ton absence";
        static readonly Regex rxIndice = new Regex(@"\d\s*[xX×]\s*[\[\(]?.+kamas|Banque.+vente|lots?\s*vendu", RegexOptions.IgnoreCase);

        static long Valeur(string s)
        {
            long v;
            return long.TryParse(Regex.Replace(s, @"\D", ""), NumberStyles.Integer, CultureInfo.InvariantCulture, out v) ? v : 0;
        }

        static AchatLu Analyser(string texte)
        {
            // Résumé des ventes faites hors ligne : seul le montant total compte ; le nombre de lots est gardé pour info.
            var r = rxResume.Match(texte);
            if (r.Success)
            {
                int hr = int.Parse(r.Groups["h"].Value), mr = int.Parse(r.Groups["m"].Value);
                long lots = Valeur(r.Groups["q"].Value), total = Valeur(r.Groups["k"].Value);
                if (hr > 23 || mr > 59 || lots <= 0 || total <= 0) return null;
                return new AchatLu { Heure = hr, Minute = mr, Quantite = lots, Prix = total, Nom = VentesAbsence, Vente = true };
            }
            bool vente = true;
            var m = rxVente.Match(texte);
            if (!m.Success)
            {
                if (texte.IndexOf("vendu", StringComparison.OrdinalIgnoreCase) >= 0) return null;
                m = rxAchat.Match(texte);
                vente = false;
            }
            if (!m.Success) return null;
            int h = int.Parse(m.Groups["h"].Value), mi = int.Parse(m.Groups["m"].Value);
            long q = Valeur(m.Groups["q"].Value), k = Valeur(m.Groups["k"].Value);
            string nom = m.Groups["n"].Value.Trim().TrimEnd(']', ')').Trim();
            // Crochet ouvrant lu comme une lettre collée au nom : « tWakfu Emeraude » pour « [Wakfu Émeraude ».
            if (nom.Length > 3 && "tfl1|[".IndexOf(nom[0]) >= 0 && char.IsUpper(nom[1])) nom = nom.Substring(1);
            if (h > 23 || mi > 59 || q <= 0 || k <= 0 || nom.Length < 2) return null;
            return new AchatLu { Heure = h, Minute = mi, Quantite = q, Prix = k, Nom = nom, Vente = vente };
        }

        /// <summary>Les achats et ventes visibles dans le chat de cette capture (une entrée par ligne affichée).</summary>
        public static List<AchatLu> Lire(Bitmap bmp, List<LigneOcr> lignes)
        {
            var res = new List<AchatLu>();
            foreach (var l in lignes)
            {
                if (!rxIndice.IsMatch(l.Texte)) continue;
                AchatLu a = null;
                // Relecture de la ligne agrandie : le texte du chat est petit.
                double h = Math.Min(Math.Max(l.H, 10), 24);
                var zone = Rectangle.Round(new RectangleF((float)(l.X - 2 * h), (float)(l.Y - 0.6 * h), (float)(l.L + 6 * h), (float)(l.H + 1.2 * h)));
                zone.Intersect(new Rectangle(0, 0, bmp.Width, bmp.Height));
                if (zone.Width > 10 && zone.Height > 5)
                    using (var morceau = bmp.Clone(zone, bmp.PixelFormat))
                    using (var grand = Ecran.Agrandir(morceau, 2.5))
                        foreach (var zl in Ocr.Lire(grand, 2.5))
                        {
                            a = Analyser(zl.Texte);
                            if (a != null) break;
                        }
                if (a == null) a = Analyser(l.Texte);
                if (a != null) res.Add(a);
            }
            return res;
        }

        /// <summary>Le texte des lignes du chat qui parlent d'achats ou de ventes : s'il n'a pas changé, rien de nouveau à lire.</summary>
        public static string Signature(List<LigneOcr> lignes)
        {
            return string.Join("\n", lignes.Where(l => rxIndice.IsMatch(l.Texte)).Select(l => l.Texte));
        }

        // Lettres que l'OCR confond dans les noms : « XL111 », « XLII » et « XLIII » se ressemblent ainsi.
        static string Squelette(string nom)
        {
            var sb = new System.Text.StringBuilder();
            foreach (char c in Ecran.Normaliser(nom))
                sb.Append(c == '1' || c == 'l' || c == 'j' ? 'i' : c == '0' ? 'o' : c == '5' ? 's' : c);
            return sb.ToString();
        }

        /// <summary>Même nom à quelques fautes de lecture près (lettre en trop, crochet lu comme une lettre…).</summary>
        public static bool MemeNom(string a, string b)
        {
            string x = Squelette(a), y = Squelette(b);
            if (x == y) return true;
            if (Math.Min(x.Length, y.Length) < 5) return false;
            if (x.Contains(y) || y.Contains(x)) return Math.Abs(x.Length - y.Length) <= 2;
            return Ecran.Distance(x, y) <= Math.Max(2, Math.Min(x.Length, y.Length) / 6);
        }

        /// <summary>Même mouvement de kamas : même sens, même quantité, même prix et même nom à peu près.</summary>
        public static bool Meme(AchatLu a, bool vente, string nom, long quantite, long prix)
        {
            return a.Vente == vente && a.Quantite == quantite && a.Prix == prix && MemeNom(a.Nom, nom);
        }

        /// <summary>Date complète lue à « HH:MM » : aujourd'hui, ou hier si l'heure est encore à venir (minuit passé).</summary>
        public static DateTime Date(AchatLu a, DateTime maintenant)
        {
            var t = maintenant.Date.AddHours(a.Heure).AddMinutes(a.Minute);
            if (t > maintenant.AddMinutes(5)) t = t.AddDays(-1);
            return t;
        }
    }
}
