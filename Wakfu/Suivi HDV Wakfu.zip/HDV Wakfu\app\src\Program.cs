using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace SuiviHdvWakfu
{
    public static class Program
    {
        [DllImport("user32.dll")] static extern bool PostMessage(IntPtr h, int msg, IntPtr w, IntPtr l);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)] static extern int SetCurrentProcessExplicitAppUserModelID(string id);

        static string dossier;

        /// <summary>dossierHdv : le dossier « HDV Wakfu » (données, captures, sons).</summary>
        public static void Run(string dossierHdv)
        {
            dossier = dossierHdv;
            Diag.Activer(dossierHdv); Diag.T("Run");
            bool cree;
            using (var unique = new Mutex(true, "SuiviHdvWakfu_InstanceUnique", out cree))
            {
                if (!cree)
                {
                    // Déjà ouvert : on demande à la fenêtre existante de revenir devant.
                    PostMessage((IntPtr)0xFFFF, Fenetre.MsgAfficher, IntPtr.Zero, IntPtr.Zero);
                    return;
                }
                Ecran.SetProcessDPIAware();
                // Priorité basse : le jeu, la souris et le reste de Windows passent avant le suivi.
                try { System.Diagnostics.Process.GetCurrentProcess().PriorityClass = System.Diagnostics.ProcessPriorityClass.BelowNormal; } catch { }
                try { SetCurrentProcessExplicitAppUserModelID("SuiviHdvWakfu.Wakfu"); } catch { }
                Application.EnableVisualStyles();
                try { Application.SetCompatibleTextRenderingDefault(false); } catch { }
                using (var g = Graphics.FromHwnd(IntPtr.Zero)) Theme.Dpi = Math.Max(1f, g.DpiX / 96f);
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += (s, e) => Signaler(e.Exception);
                AppDomain.CurrentDomain.UnhandledException += (s, e) => Signaler(e.ExceptionObject as Exception);

                string ico = Path.Combine(dossier, "app", "app.ico");
                if (!File.Exists(ico)) try { Icone.Ecrire(ico); } catch { }

                Diag.T("avant Application.Run");
                Application.Run(new Fenetre(dossier));
                Diag.T("après Application.Run");
                GC.KeepAlive(unique);
            }
        }

        static void Signaler(Exception ex)
        {
            if (ex == null) return;
            try
            {
                File.AppendAllText(Path.Combine(dossier, "donnees", "erreurs.log"),
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + ex + Environment.NewLine + Environment.NewLine);
            }
            catch { }
        }
    }
}

namespace SuiviHdvWakfu
{
    /// <summary>Diagnostic du démarrage : si donnees\trace.on existe, chaque étape est datée dans donnees\demarrage.log.</summary>
    public static class Diag
    {
        public static string Fichier;
        public static void Activer(string dossierHdv)
        {
            string on = System.IO.Path.Combine(dossierHdv, "donnees", "trace.on");
            Fichier = System.IO.File.Exists(on) ? System.IO.Path.Combine(dossierHdv, "donnees", "demarrage.log") : null;
        }
        public static void T(string etape)
        {
            if (Fichier == null) return;
            try { System.IO.File.AppendAllText(Fichier, DateTime.Now.ToString("HH:mm:ss.fff") + "  [" + System.Threading.Thread.CurrentThread.ManagedThreadId + "] " + etape + "\r\n"); } catch { }
        }
    }
}
